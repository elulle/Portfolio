/**
  This file will get autoloaded using
  VTCore Assets management
  **/
(function($) {
  // Put custom js here
})(jQuery);