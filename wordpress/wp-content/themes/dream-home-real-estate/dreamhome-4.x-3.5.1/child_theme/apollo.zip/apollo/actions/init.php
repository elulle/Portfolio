<?php
/**
 * Implement hook action init
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Apollo_Actions_Init
  extends VTCore_Wordpress_Models_Hook {

  public function hook() {
    // Example of hook action init
  }
}