<?php
// This is just an example !
// It probably wont work in your theme
// Just a place holder