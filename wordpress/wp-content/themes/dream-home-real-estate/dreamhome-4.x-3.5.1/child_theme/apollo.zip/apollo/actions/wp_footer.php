<?php
/**
 * Action wp_footer for VTCore_Wordpress
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Apollo_Actions_Wp__Footer
extends VTCore_Wordpress_Models_Hook {

  public function hook() {
    // Insert code for footer
  }

}