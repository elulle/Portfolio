<?php
/**
 * Implement hook filter request
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Apollo_Filters_Request
extends VTCore_Wordpress_Models_Hook {

  public function hook($qv = NULL) {
    // Modify requests
    return $qv;
  }
}