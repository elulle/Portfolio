<?php
/**
 * Encapsulate the child theme booting sequence
 * This must be done this way to ensure the parent theme booting
 * init process run first.
 *
 * @param $core
 */
function apolloChildThemeInit($core) {

  // Load autoloader
  $autoloader = new VTCore_Autoloader('VTCore_Apollo', dirname(__FILE__));
  $autoloader->setRemovePath('vtcore' . DIRECTORY_SEPARATOR . 'apollo' . DIRECTORY_SEPARATOR);
  $autoloader->register();

  // Registering assets, The assets has not been enqueued yet!
  // @see apollo/assets
  VTCore_Wordpress_Init::getFactory('assets')
    ->get('library')
    ->detect(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'assets', get_stylesheet_directory_uri() . '/assets');

  // Registering actions
  $actions = array(
    // @see apollo/actions/init.php
    'init',
    // @see apollo/actions/wp_footer.php
    // Notice that _ is equal to __ in class name
    'wp_footer',
  );

  if (!empty($actions)) {
    VTCore_Wordpress_Init::getFactory('actions')
      ->addPrefix('VTCore_Apollo_Actions_')
      ->addHooks($actions)
      ->register();
  }


  // Registering filters
  $filters = array(
    // @see apollo/filters/request.php
    'request',
  );

  if (!empty($filters)) {
    VTCore_Wordpress_Init::getFactory('filters')
      ->addPrefix('VTCore_Apollo_Filters_')
      ->addHooks($filters)
      ->register();
  }

  // Registering template folders
  VTCore_Wordpress_Init::getFactory('template')
    ->register(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'templates', 'templates');

}


// Remember to encapsulate anything that is related to VTCore after the parent
// theme initializes! not before like normal child theme would.
add_action('vtcore_zeus_after_theme_init', 'apolloChildThemeInit');


// You can inject normal wordpress hook actions and filter after this.