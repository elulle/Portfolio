<?php
/**
 * Dsidx listing page template
 *
 * @author jason.xie@victheme.com
 */

VTCore_Wordpress_Utility::loadAsset('jquery-imgliquid');
VTCore_Wordpress_Utility::loadAsset('theme-dsidx');

$object = new VTCore_Bootstrap_Grid_Column(VTCore_Zeus_Init::getFactory('features')->get('options.dsidx.grids'));
?>
<?php get_header(); ?>

  <div id="maincontent" class="area clearfix">
    <div class="container-fluid">
      <div class="row">

        <div id="content"
             class="region
			     <?php if (VTCore_Zeus_Utility::getSidebar('dsidx-listing')) {
               echo VTCore_Zeus_Utility::getColumnSize('content');
             } ?>
			     with-sidebar-<?php echo VTCore_Zeus_Utility::getSidebar('dsidx-listing'); ?>
			     template-dsidx-<?php echo VTCore_Zeus_Init::getFactory('features')->get('options.dsidx.mode'); ?>"
             data-grids="<?php echo esc_attr($object->getClass()); ?>">

          <?php

          while (have_posts()) {
            the_post();
            get_template_part('templates/dsidx/listing');
          }
          ?>
        </div>

        <?php
        // Build sidebar.
        if (VTCore_Zeus_Utility::getSidebar('dsidx-listing') == 'right'
          || VTCore_Zeus_Utility::getSidebar('dsidx-listing') == 'left'
        ) {
          get_sidebar('sidebar');
        }
        ?>

      </div>
    </div>
  </div>


<?php get_footer(); ?>