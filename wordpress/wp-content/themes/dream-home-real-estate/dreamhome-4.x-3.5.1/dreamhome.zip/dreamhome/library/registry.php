<?php
/**
 * Simple class for integrating with TGMP script
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Library_Registry {

  private $plugins = array();
  private $config;
  private $defaultPath;



  /**
   * Automatic booting
   */
  public function registerPlugin() {

    if (is_admin() && !defined('DOING_AJAX')) {
      $this->defaultPath = VTCORE_ZEUS_PLUGIN_SOURCE_PATH . DIRECTORY_SEPARATOR;
      $this->loadPlugin();
      $this->loadConfig();
      $this->activate();
    }
  }


  /**
   * Load the plugin configuration data
   */
  private function loadPlugin() {
    
    $this->plugins = array(

      // VicTheme Core
      array(
        'name'               => 'VicTheme Core',
        'slug'               => 'victheme_core',
        'source'             => $this->defaultPath . 'victheme_core.zip',
        'required'           => true,
        'version'            => '1.7.60',
        'force_activation'   => false,
      ),

      // VicTheme Demo
      array(
        'name'               => 'VicTheme Demo',
        'slug'               => 'victheme_demo',
        'source'             => $this->defaultPath . 'victheme_demo.zip',
        'required'           => false,
        'version'            => '1.3.12',
        'force_activation'   => false,
        'force_deactivation' => false,
      ),

      // VicTheme Headline
      array(
        'name'               => 'VicTheme Headline',
        'slug'               => 'victheme_headline',
        'source'             => $this->defaultPath . 'victheme_headline.zip',
        'required'           => false,
        'version'            => '1.8.13',
        'force_activation'   => false,
      ),

      // Visual Composer
      array(
        'name'               => 'Visual Composer',
        'slug'               => 'js_composer',
        'source'             => $this->defaultPath .  'js_composer.zip',
        'required'           => false,
        'version'            => '4.12.1',
        'force_activation'   => false,
      ),

      // VicTheme Property
      array(
        'name'               => 'VicTheme Property',
        'slug'               => 'victheme_property',
        'source'             => $this->defaultPath . 'victheme_property.zip',
        'required'           => false,
        'version'            => '1.6.1',
        'force_activation'   => false,
      ),

      // VicTheme Agents
      array(
        'name'               => 'VicTheme Agents',
        'slug'               => 'victheme_agents',
        'source'             => $this->defaultPath . 'victheme_agents.zip',
        'required'           => false,
        'version'            => '1.6.0',
        'force_activation'   => false,
        'force_deactivation' => false,
      ),

      // VicTheme Maps
      array(
        'name'               => 'VicTheme Maps',
        'slug'               => 'victheme_maps',
        'source'             => $this->defaultPath . 'victheme_maps.zip',
        'required'           => false,
        'version'            => '1.8.7',
        'force_activation'   => false,
        'force_deactivation' => false,
      ),


      // VicTheme Visual Candy
      array(
        'name'               => 'VicTheme Visual Candy',
        'slug'               => 'victheme_visualcandy',
        'source'             => $this->defaultPath . 'victheme_visualcandy.zip',
        'required'           => false,
        'version'            => '1.8.4',
        'force_activation'   => false,
      ),

      // VicTheme Visual Bootstrap
      array(
        'name'               => 'VicTheme Visual Bootstrap',
        'slug'               => 'victheme_visualbootstrap',
        'source'             => $this->defaultPath . 'victheme_visualbootstrap.zip',
        'required'           => false,
        'version'            => '1.8.4',
        'force_activation'   => false,
      ),


      // VicTheme Visualplus
      array(
        'name'               => 'VicTheme VisualPlus',
        'slug'               => 'victheme_visualplus',
        'source'             => $this->defaultPath . 'victheme_visualplus.zip',
        'required'           => false,
        'version'            => '1.5.4',
        'force_activation'   => false,
      ),

      // VicTheme Slick
      array(
        'name'               => 'VicTheme Slick',
        'slug'               => 'victheme_slick',
        'source'             => $this->defaultPath . 'victheme_slick.zip',
        'required'           => false,
        'version'            => '1.3.0',
        'force_activation'   => false,
      ),

      // VicTheme Slick
      array(
        'name'               => 'VicTheme Icons',
        'slug'               => 'victheme_icons',
        'source'             => $this->defaultPath . 'victheme_icons.zip',
        'required'           => false,
        'version'            => '1.1.6',
        'force_activation'   => false,
      ),

      // VicTheme Visualloop
      array(
        'name'               => 'VicTheme VisualLoop',
        'slug'               => 'victheme_visualloop',
        'source'             => $this->defaultPath . 'victheme_visualloop.zip',
        'required'           => false,
        'version'            => '1.0.4',
        'force_activation'   => false,
      ),

      // Revolution slider
      array(
        'name'               => 'Revolution Slider',
        'slug'               => 'revslider',
        'source'             => $this->defaultPath . 'revslider.zip',
        'required'           => false,
        'version'            => '5.2.6',
        'force_activation'   => false,
      ),


      // Display Widget
      array(
        'name'               => 'Display Widgets',
        'slug'               => 'display-widgets',
        'source'             => $this->defaultPath . 'display-widgets.zip',
        'required'           => false,
        'force_activation'   => false,
      ),


      // Contact Form 7
      array(
        'name'               => 'Contact Form 7',
        'slug'               => 'contact-form-7',
        'source'             => $this->defaultPath . 'contact-form-7.zip',
        'required'           => false,
        'force_activation'   => false,
      ),

      // Easy Theme Upgrade
      array(
        'name'               => 'Easy Theme And Plugin Upgrade',
        'slug'               => 'easy-theme-and-plugin-upgrades',
        'source'             => $this->defaultPath . 'easy-theme-and-plugin-upgrades.zip',
        'required'           => false,
        'force_activation'   => false,
      ),

      // Breadcrumb navigation
      array(
        'name'               => 'Breadcrumb Navigation',
        'slug'               => 'breadcrumb-navxt',
        'source'             => $this->defaultPath . 'breadcrumb-navxt.zip',
        'required'           => false,
        'force_activation'   => false,
      ),

      // dsIDXpress
      array(
        'name'               => 'DsIDXpress Property IDX',
        'slug'               => 'dsidxpress',
        'source'             => $this->defaultPath . 'dsidxpress.zip',
        'required'           => false,
        'force_activation'   => false,
      ),

      // Image Widget
      array(
        'name'               => 'Image Widget',
        'slug'               => 'image-widget',
        'source'             => $this->defaultPath . 'image-widget.zip',
        'required'           => false,
        'force_activation'   => false,
      ),


      // Popular Widget
      array(
        'name'               => 'Popular Post Widget',
        'slug'               => 'popular-widget',
        'source'             => $this->defaultPath . 'popular-widget.zip',
        'required'           => false,
        'force_activation'   => false,
      ),

      // Recent Post Widget
      array(
        'name'               => 'Recent Post Widget Extended',
        'slug'               => 'recent-posts-widget-extended',
        'source'             => $this->defaultPath . 'recent-posts-widget-extended.zip',
        'required'           => false,
        'force_activation'   => false,
      ),

    );
  }




  /**
   * Load all the configuration data
   */
  private function loadConfig() {

    $this->config = array(
      'id'           => 'dreamhome',
      'default_path' => '',
      'menu'         => 'tgmpa-install-plugins',
      'has_notices'  => true,
      'dismissable'  => true,
      'dismiss_msg'  => '',
      'is_automatic' => true,
      'message'      => '',
      'strings'      => array(
        'page_title'                      => __( 'Install Required Plugins', 'dreamhome' ),
        'menu_title'                      => __( 'Install Plugins', 'dreamhome' ),
        'installing'                      => __( 'Installing Plugin: %s', 'dreamhome' ), // %s = plugin name.
        'oops'                            => __( 'Something went wrong with the plugin API.', 'dreamhome' ),
        'notice_can_install_required'     => _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.', 'dreamhome' ), // %1$s = plugin name(s).
        'notice_can_install_recommended'  => _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.', 'dreamhome' ), // %1$s = plugin name(s).
        'notice_cannot_install'           => _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', 'dreamhome' ), // %1$s = plugin name(s).
        'notice_can_activate_required'    => _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', 'dreamhome' ), // %1$s = plugin name(s).
        'notice_can_activate_recommended' => _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', 'dreamhome' ), // %1$s = plugin name(s).
        'notice_cannot_activate'          => _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'dreamhome' ), // %1$s = plugin name(s).
        'notice_ask_to_update'            => _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'dreamhome' ), // %1$s = plugin name(s).
        'notice_cannot_update'            => _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'dreamhome' ), // %1$s = plugin name(s).
        'install_link'                    => _n_noop( 'Begin installing plugin', 'Begin installing plugins', 'dreamhome' ),
        'activate_link'                   => _n_noop( 'Begin activating plugin', 'Begin activating plugins', 'dreamhome' ),
        'return'                          => __( 'Return to Required Plugins Installer', 'dreamhome' ),
        'plugin_activated'                => __( 'Plugin activated successfully.', 'dreamhome' ),
        'complete'                        => __( 'All plugins installed and activated successfully. %s', 'dreamhome' ), // %s = dashboard link.
        'nag_type'                        => 'updated' // Determines admin notice type - can only be 'updated', 'update-nag' or 'error'.
      )
    );
  }



  /**
   * Activates the plugin dependencies
   */
  private function activate() {
    tgmpa( $this->plugins, $this->config );
  }

}