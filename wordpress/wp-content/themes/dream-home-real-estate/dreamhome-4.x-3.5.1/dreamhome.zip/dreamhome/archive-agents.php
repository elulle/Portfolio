<?php
/**
 * Main template for building
 * the agents archive page
 *
 * The main loop can be configured
 * via victheme_agents configuration
 * page GUI.
 *
 * @author jason.xie@victheme.com
 */
?>
<?php get_header(); ?>

  <div id="maincontent" class="area clearfix">
    <div class="container-fluid">
      <div class="row">

        <div id="content"
             class="region
			      <?php
                  if (VTCore_Zeus_Utility::getSidebar('agents_archive')) {
                    echo VTCore_Zeus_Utility::getColumnSize('content');
                  }

                  echo ' with-sidebar-' . VTCore_Zeus_Utility::getSidebar('agents_archive');

                  ?>
              ">


          <?php

          // Overriding the default property loop
          // pager arguments
          $pagerArgs = array(
            'prev_text' => __('&larr; Previous', 'dreamhome'),
            'next_text' => __('Next &rarr;', 'dreamhome'),
            'attributes' => array(
              'class' => array(
                'text-center',
              ),
            ),
          );

          // Simply call the victheme_property defaultloop template
          include VTCore_Wordpress_Utility::locateTemplate('agents-loop.php');

          ?>

        </div>


        <?php
        // Build sidebar
        if (VTCore_Zeus_Utility::getSidebar('agents_archive') == 'right'
          || VTCore_Zeus_Utility::getSidebar('agents_archive') == 'left'
        ) {
          get_sidebar('sidebar');
        }
        ?>


      </div>
    </div>
  </div>

<?php get_footer(); ?>