<?php
/**
 * Panel section for configuring property options
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Panels_Post
extends VTCore_Zeus_Panels_Model {

  /**
   * Overriding parent method
   * @see VTCore_Bootstrap_Element_BsElement::buildElement()
   */
  public function buildElement() {


    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Single Post', 'dreamhome'),
      'id' => 'vtcore-zeus-post-page-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' => __('The single post setting will be applied to blog post type single post page and other page that use the single.php as the template for rendering the element.', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][full][title]',
        'text' => __('Show Title', 'dreamhome'),
        'description' => __('Show / hide the single post main title.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('full', 'title'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][full][image]',
        'text' => __('Show Featured Image', 'dreamhome'),
        'description' => __('Show / hide the single post featured image.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('full', 'image'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][full][content]',
        'text' => __('Show Content', 'dreamhome'),
        'description' => __('Show / hide the single post main content', 'dreamhome'),
        'checked' => (boolean) $this->getShow('full', 'content'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][full][byline]',
        'text' => __('Show Tags', 'dreamhome'),
        'description' => __('Show / hide the by line element', 'dreamhome'),
        'checked' => (boolean) $this->getShow('full', 'byline'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][full][author]',
        'text' => __('Show Author Information Box', 'dreamhome'),
        'description' => __('Show / hide the single post author information box.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('full', 'author'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][full][comments]',
        'text' => __('Show Comments Entries', 'dreamhome'),
        'description' => __('Show / hide single page comment entries element.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('full', 'comments'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][full][comment_form]',
        'text' => __('Show Comment Form', 'dreamhome'),
        'description' => __('Show / hide the single post comment form element.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('full', 'comment_form'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][full][social]',
        'text' => __('Show Social Share Links', 'dreamhome'),
        'description' => __('Show / hide the single post social sharing button links.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('full', 'social'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));

    $this->processPanel();


    // Archives Page Configurations
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Archives Page', 'dreamhome'),
      'id' => 'vtcore-zeus-archives-page-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' =>  __('This setting will be applied to the archives pages including blog archive page, search archive page, category archive page and tags archive page', 'dreamhome'),
      ))
      ->BsSelect(array(
        'text' => __('Teaser Template', 'dreamhome'),
        'name' => 'theme[features][options][blog][teaser]',
        'description' => __('Define the template mode for the archive page', 'dreamhome'),
        'value' => $this->getOption('blog', 'teaser'),
        'options' => array(
          'blog-list' => __('List', 'dreamhome'),
          'blog-grid' => __('Grid', 'dreamhome'),
        ),
      ))
      ->BsGrids(array(
        'columns' => array(
          'text' => __('Teaser Columns', 'dreamhome'),
          'description' => __('Set the teaser items column grids', 'dreamhome'),
        ),
        'name' => 'theme[features][options][blog][grids]',
        'value' => $this->getOption('blog', 'grids'),
      ));

    $this->processPanel();



    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Teaser Sticky', 'dreamhome'),
      'id' => 'vtcore-zeus-post-teaser-sticky-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' => __('The excerpt setting will be applied to blog post type teasers that uses the theme default template for rendering the element.', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_sticky][title]',
        'text' => __('Show Title', 'dreamhome'),
        'description' => __('Show / hide the excerpt title element', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_sticky', 'title'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_sticky][image]',
        'text' => __('Show Image', 'dreamhome'),
        'description' => __('Show / hide the excerpt attached thumbnail image', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_sticky', 'image'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_sticky][byline]',
        'text' => __('Show Post By Line', 'dreamhome'),
        'description' => __('Show / hide the excerpt text line showing the post information.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_sticky', 'byline'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_sticky][excerpt]',
        'text' => __('Show Content', 'dreamhome'),
        'description' => __('Show / hide the excerpt content.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_sticky', 'excerpt'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_sticky][readmore]',
        'text' => __('Show Readmore Button', 'dreamhome'),
        'description' => __('Show / hide the excerpt readmore button.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_sticky', 'readmore'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));

    $this->processPanel();


    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Teaser List', 'dreamhome'),
      'id' => 'vtcore-zeus-post-teaser-list-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' => __('The excerpt setting will be applied to blog post type teasers that uses the theme default template for rendering the element.', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_list][title]',
        'text' => __('Show Title', 'dreamhome'),
        'description' => __('Show / hide the excerpt title element', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_list', 'title'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_list][image]',
        'text' => __('Show Image', 'dreamhome'),
        'description' => __('Show / hide the excerpt attached thumbnail image', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_list', 'image'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_list][byline]',
        'text' => __('Show Post By Line', 'dreamhome'),
        'description' => __('Show / hide the excerpt text line showing the post information.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_list', 'byline'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_list][excerpt]',
        'text' => __('Show Content', 'dreamhome'),
        'description' => __('Show / hide the excerpt content.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_list', 'excerpt'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_list][readmore]',
        'text' => __('Show Readmore Button', 'dreamhome'),
        'description' => __('Show / hide the excerpt readmore button.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_list', 'readmore'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));



    $this->processPanel();


    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Teaser Grid', 'dreamhome'),
      'id' => 'vtcore-zeus-post-teaser-grid-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' => __('The excerpt setting will be applied to blog post type teasers that uses the theme default template for rendering the element.', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_grid][title]',
        'text' => __('Show Title', 'dreamhome'),
        'description' => __('Show / hide the excerpt title element', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_grid', 'title'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_grid][image]',
        'text' => __('Show Image', 'dreamhome'),
        'description' => __('Show / hide the excerpt attached thumbnail image', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_grid', 'image'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_grid][byline]',
        'text' => __('Show Post By Line', 'dreamhome'),
        'description' => __('Show / hide the excerpt text line showing the post information.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_grid', 'byline'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_grid][excerpt]',
        'text' => __('Show Content', 'dreamhome'),
        'description' => __('Show / hide the excerpt content.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_grid', 'excerpt'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][teaser_grid][readmore]',
        'text' => __('Show Readmore Button', 'dreamhome'),
        'description' => __('Show / hide the excerpt readmore button.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('teaser_grid', 'readmore'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));

    $this->processPanel();
  }

}