<?php
/**
 * Class for storing visual composer templates
 *
 * Example entry :
 *
 * array_unshift($templates, array(
 *    'name' => 'Translated String for template name',
 *    'custom_class' => 'custom css class for the preview',
 *    'content' => 'The actual shortcode content use <<<CONTENT CONTENT',
 * ));
 *
 * @author jason.xie@victheme.com
 */
class VTCore_Zeus_VisualComposer_Template {

  /**
   * Storing the theme default templates,
   * it can be a whole page templates of
   * per block templates.
   */
  public function themeTemplates($templates) {

    // Inject the templates here

    return $templates;
  }

}