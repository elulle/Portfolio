<?php
/**
 * Class for filtering pre_get_posts
 * and adding extra class to it.
 *
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Actions_Pre__Get__Posts
extends VTCore_Wordpress_Models_Hook {

  public function hook($query = null) {

    // This is a work around to let WordPress main query knows
    // about the custom query url that getPager() method use.
    // Any pager that wish to use main query as the query
    // must use "main" as its unique pager id.
    if (isset($_GET['paged_main']) && is_numeric($_GET['paged_main']) && $query->is_main_query()) {
      $page = isset($_GET['paged_main']) ? strip_tags($_GET['paged_main']) : 1;
      $query->set('paged', $page);
    }

  }
}