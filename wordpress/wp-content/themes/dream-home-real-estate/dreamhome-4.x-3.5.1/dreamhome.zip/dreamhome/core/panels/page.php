<?php
/**
 * Panel section for configuring property options
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Panels_Page
extends VTCore_Zeus_Panels_Model {

  /**
   * Overriding parent method
   * @see VTCore_Bootstrap_Element_BsElement::buildElement()
   */
  public function buildElement() {


    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Single Page', 'dreamhome'),
      'id' => 'vtcore-zeus-page-page-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' => __('The single page setting will be applied to post type page single post and other page that use the page.php as the template for rendering the element.', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][page][image]',
        'text' => __('Show Image', 'dreamhome'),
        'description' => __('Show / hide the single page featured image element.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('page', 'image'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][page][title]',
        'text' => __('Show Title', 'dreamhome'),
        'description' => __('Show / hide the single page title element.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('page', 'title'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][page][content]',
        'text' => __('Show Content', 'dreamhome'),
        'description' => __('Show / hide the single page content element.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('page', 'content'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][page][comments]',
        'text' => __('Show Comments Entries', 'dreamhome'),
        'description' => __('Show / hide the single page comment entries element.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('page', 'comments'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][page][comment_form]',
        'text' => __('Show Comment Form', 'dreamhome'),
        'description' => __('Show / hide the single page comment form element.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('page', 'comment_form'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][page][social]',
        'text' => __('Show Social Share Links', 'dreamhome'),
        'description' => __('Show / hide the single page social sharing button links.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('page', 'social'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));

    $this->processPanel();
  }

}