<?php
/**
 * Class for generating customizer array
 *
 * @author jason.xie@victheme.com
 */
class VTCore_Zeus_Customizer_Page
extends VTCore_Zeus_Customizer_Model {

  protected $panelKey = 'zeus_page';
  protected $key = 'page';

  public function register() {

    if (!$this->getCache()) {
      $this->object = new VTCore_Zeus_Panels_Page(array(
        'features' => VTCore_Zeus_Init::getFactory('features'),
        'process' => false,
        'build' => 'object',
      ));

      $this->context[$this->key]['panels'][$this->panelKey] = array(
        'title' => __('Single Page', 'dreamhome'),
        'priority' => 403,
        'capability' => 'edit_theme_options',
        'description' => __('Configure the theme single page options.', 'dreamhome'),
        'active_callback' => array($this, 'active_callback'),
      );

      $this->buildContext();
      $this->setCache();
    }

    $this->insert();


    return $this;
  }

  public function active_callback() {

    $active = false;

    if (is_singular('page')) {
      // Detect Custom template;
      $template = VTCore_Zeus_Utility::getCustomTemplate();
      if (empty($template)) {
        $active = true;
      }
      elseif (strpos($template, 'page-sidebar') !== FALSE) {
        $active = TRUE;
      }
    }

    return $active;
  }

}
