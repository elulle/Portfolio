<?php
/**
 * Panel section for configuring layout options
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Panels_Layout
extends VTCore_Zeus_Panels_Model {

  /**
   * Panel content
   */
  public function buildElement() {

    $assistance = new VTCore_Zeus_Assistance();

    // Page width and style
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
        'id' => 'vtcore-zeus-layout-panel',
        'text' => __('Page Layout', 'dreamhome'),
      ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsRow()
      ->lastChild()
      ->BsSelect(array(
        'text' => __('Maximum Width', 'dreamhome'),
        'description' => __('Define the maximum page width for the theme.', 'dreamhome'),
        'name' =>  'theme[features][options][page][maxwidth]',
        'value' => $this->getOption('page', 'maxwidth'),
        'options' => array(
          'max-960' => '960px',
          'max-1170' => '1170px',
          'max-1340' => '1340px',
          'max-fluid' => __('Fluid', 'dreamhome'),
        ),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ))
      ->BsSelect(array(
        'text' => __('Page Style', 'dreamhome'),
        'description' => __('Define the main styling for the theme page.', 'dreamhome'),
        'name' =>  'theme[features][options][page][style]',
        'value' => $this->getOption('page', 'style'),
        'options' => array('style-normal' => __('Normal', 'dreamhome'),  'style-boxed' => __('Boxed', 'dreamhome')),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ))
      ->BsSelect(array(
        'text' => __('Responsive', 'dreamhome'),
        'description' => __('Define the if the page should be responsive or not.', 'dreamhome'),
        'name' =>  'theme[features][options][page][responsive]',
        'value' => $this->getOption('page', 'responsive'),
        'options' => array('bs-responsive' => __('Responsive', 'dreamhome'),  'bs-fixed' => __('Non Responsive', 'dreamhome')),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ));

    $this->processPanel();

    // Building the sidebar configuration
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
        'id' => 'vtcore-zeus-sidebar-panel',
        'text' => __('Sidebar Position', 'dreamhome'),
      ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsRow()
      ->lastChild()
      ->BsSelect(array(
        'text' => __('Teaser Listing Page', 'dreamhome'),
        'description' => __('This settings will be applied to all teasers listing pages', 'dreamhome'),
        'name' =>  'theme[features][sidebars][teaser]',
        'value' => $this->getSidebar('teaser'),
        'options' => array(
          'none' => __('No Sidebar', 'dreamhome'),
          'left' => __('Left', 'dreamhome'),
          'right' => __('Right', 'dreamhome'),
        ),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ))
      ->BsSelect(array(
        'text' => __('Single Post', 'dreamhome'),
        'description' => __('This settings will be applied to post single page', 'dreamhome'),
        'name' =>  'theme[features][sidebars][full]',
        'value' => $this->getSidebar('full'),
        'options' => array(
          'none' => __('No Sidebar', 'dreamhome'),
          'left' => __('Left', 'dreamhome'),
          'right' => __('Right', 'dreamhome'),
        ),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ))
      ->BsSelect(array(
        'text' => __('Page 404', 'dreamhome'),
        'description' => __('This settings will be applied to page 404 only.', 'dreamhome'),
        'name' =>  'theme[features][sidebars][notfound]',
        'value' => $this->getSidebar('notfound'),
        'options' => array(
          'none' => __('No Sidebar', 'dreamhome'),
          'left' => __('Left', 'dreamhome'),
          'right' => __('Right', 'dreamhome'),
        ),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ))
      ->BsSelect(array(
        'text' => __('Single Page', 'dreamhome'),
        'description' => __('This settings will be applied to single page only.', 'dreamhome'),
        'name' =>  'theme[features][sidebars][page]',
        'value' => $this->getSidebar('page'),
        'options' => array(
          'none' => __('No Sidebar', 'dreamhome'),
          'left' => __('Left', 'dreamhome'),
          'right' => __('Right', 'dreamhome'),
        ),
        'attributes' => array(
          'class' => array(
            'clearboth',
            'clear'
          ),
        ),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ))
      ->BsSelect(array(
        'text' => __('Property Teasers Listing Page', 'dreamhome'),
        'description' => __('This settings will be applied to property listing page and property category taxonomy page.', 'dreamhome'),
        'name' =>  'theme[features][sidebars][property_archive]',
        'value' => $this->getSidebar('property_archive'),
        'options' => array(
          'none' => __('No Sidebar', 'dreamhome'),
          'left' => __('Left', 'dreamhome'),
          'right' => __('Right', 'dreamhome'),
        ),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ))
      ->BsSelect(array(
        'text' => __('Property Single Page', 'dreamhome'),
        'description' => __('This settings will be applied to property single page only.', 'dreamhome'),
        'name' =>  'theme[features][sidebars][property_single]',
        'value' => $this->getSidebar('property_single'),
        'options' => array(
          'none' => __('No Sidebar', 'dreamhome'),
          'left' => __('Left', 'dreamhome'),
          'right' => __('Right', 'dreamhome'),
        ),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ))
      ->BsSelect(array(
        'text' => __('Agents Listing Page', 'dreamhome'),
        'description' => __('This settings will be applied to agents listing page only.', 'dreamhome'),
        'name' =>  'theme[features][sidebars][agents_archive]',
        'value' => $this->getSidebar('agents_archive'),
        'options' => array(
          'none' => __('No Sidebar', 'dreamhome'),
          'left' => __('Left', 'dreamhome'),
          'right' => __('Right', 'dreamhome'),
        ),
        'attributes' => array(
          'class' => array(
            'clearboth',
            'clear'
          ),
        ),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ))
      ->BsSelect(array(
        'text' => __('Agents Profile Page', 'dreamhome'),
        'description' => __('This settings will be applied to agents profile page only.', 'dreamhome'),
        'name' =>  'theme[features][sidebars][agents_profile]',
        'value' => $this->getSidebar('agents_profile'),
        'options' => array(
          'none' => __('No Sidebar', 'dreamhome'),
          'left' => __('Left', 'dreamhome'),
          'right' => __('Right', 'dreamhome'),
        ),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ));


    $this->processPanel();

    // Building the header
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'id' => 'vtcore-zeus-sidebar-panel',
      'text' => __('Header Styling', 'dreamhome'),
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->addChildren(new VTCore_Bootstrap_Form_BsSelect(array(
        'text' => __('Header Template', 'dreamhome'),
        'description' => __('Select the template for the theme header.', 'dreamhome'),
        'name' => 'theme[features][options][header][template]',
        'value' => $this->getOption('header', 'template'),
        'options' => array(
          'one' => __('Logo and navigation', 'dreamhome'),
          'two' => __('Logo, navigation and header right', 'dreamhome'),
          'three' => __('Centered logo, header left, navigation and header right', 'dreamhome'),
          'four' => __('Header left, navigation with centered logo and header right', 'dreamhome'),
          'five' => __('Header left, navigation and header right', 'dreamhome'),
        ),
        'input_elements' => array(
          'attributes' => array(
            'class' => array('btn-ajax-change'),
          ),
          'data' => array(
            'nonce' => wp_create_nonce('vtcore-ajax-nonce-admin'),
            'ajax-mode' => 'change',
            'ajax-target' => '#vtcore-grid-form-target',
            'ajax-loading-text' => __('Rebuilding theme grid options', 'dreamhome'),
            'ajax-object' => 'VTCore_Zeus_Pages_Layout',
            'ajax-action' => 'vtcore_ajax_framework',
            'ajax-queue' => array('change-header'),
          ),
        ),
      )));

    $this->processPanel();

    // Build the grid panel
    $this->dynamicHeader()->buildGridForm()->alterGridForm()->processPanel();

  }


  /**
   * Method for altering the grid form before it get rendered
   * @return $this
   */
  protected function alterGridForm() {

    // Altering the form display for custom header
    switch ($this->getContext('features')->get('options.header.template')) {

      // Special header three needs form tweaking.
      case 'three' :
        foreach ($this->panel->findChildren('context', 'id',  'panel-region-logo') as $children) {
          $children
            ->removeAttribute('class')
            ->setGrid(array(
              'columns' => array(
                'mobile' => 12,
                'tablet' => 12,
                'small' => 12,
                'large' => 12,
              ),
            ))
            ->addClass($children->getGrid()->getClass());

          $children->getParent()->removeChildren($children->getMachineID())->prependChild($children);
        }

        foreach ($this->panel->findChildren('context', 'id',  array('panel-region-header_left', 'panel-region-navigation', 'panel-region-header_right')) as $children) {
          $children
            ->removeAttribute('class')
            ->setGrid(array(
              'columns' => array(
                'mobile' => 12,
                'tablet' => 4,
                'small' => 4,
                'large' => 4,
              ),
            ))
            ->addClass($children->getGrid()->getClass());
        }
        break;
    }

    return $this;
  }


  /**
   * Method for altering the layout object before got processed
   * by the layout grid builder method
   *
   * @return $this
   */
  protected function dynamicHeader() {
    switch ($this->getContext('features')->get('options.header.template')) {
      case 'one' :
        $remove = array('region-header_left', 'region-header_right');
        break;
      case 'two' :
        $remove = array('region-header_left');
        break;
      case 'four' :
      case 'five' :
        $remove = array('region-logo');
        break;
    }

    if (isset($remove)) {
      foreach ($this->getContext('layout')->findChildren('id', $remove) as $target) {
        $target->getParent()->removeChildren($target->getMachineID());
      }
    }

    return $this;
  }


  /**
   * Build the grid layout form
   * @return $this
   */
  protected function buildGridForm() {

    $assistance = new VTCore_Zeus_Assistance();

    $this->panel = new VTCore_Bootstrap_Element_BsElement(array(
      'id' => 'vtcore-grid-form-target',
      'type' => 'div',
      'attributes' => array(
        'id' => 'vtcore-grid-form-target',
      ),
    ));

    // Building the layout configuration per area and per region
    foreach ($this->getContext('layout')->getChildrens() as $area) {

      $regions = $area->getChildrens();
      if (empty($regions) || count($regions) < 2) {
        continue;
      }

      $this->panel->addChildren(new VTCore_Bootstrap_Element_BsPanel(array(
        'id' => 'vtcore-zeus-area-' . str_replace(array(
            ' ',
            '_'
          ), '-', $area->getContext('id')) . '-panel',
        'text' => sprintf(__('%s Column Grid', 'dreamhome'), $area->getContext('name')),
      )));

      $this->panel
        ->lastChild()
        ->setChildrenPointer('content')
        ->addChildren(new VTCore_Bootstrap_Grid_BsRow());

      $grid = floor(12 / count($regions));

      // Don't attempt to stringify the regions!
      // It will break validation.
      foreach ($regions as $region) {

        $this->panel
          ->lastChild()
          ->lastChild()
          ->addChildren(new VTCore_Bootstrap_Grid_BsColumn(array(
            'id' => 'panel-region-' . $region->getContext('arguments.id'),
            'grids' => array(
              'columns' => array(
                'mobile' => 12,
                'tablet' => $grid,
                'small' => $grid,
                'large' => $grid,
              ),
            ),
          )))
          ->lastChild()
          ->addChildren(new VTCore_Bootstrap_Form_BsGrids(array(
            'name' => 'theme[regions][' . $region->getContext('arguments.id') . '][grids]',
            'columns' => array(
              'text' => sprintf(__('%s Region', 'dreamhome'), $region->getContext('arguments.name')),
            ),
            'value' => $region->getContext('grids'),
            'element_grids' => array(
              'columns' => array(
                'mobile' => '12',
                'tablet' => '12',
                'small' => '12',
                'large' => '12',
              ),
            ),
          )));

      }
    }

    return $this;
  }

}