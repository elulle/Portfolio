<?php
/**
 * Class for building valid VTCore_Wordpress_Factory_Customizer
 * arrays for Zeus Schema options
 *
 * @author jason.xie@victheme.com
 * @todo use model buildContext() ?
 */
class VTCore_Zeus_Customizer_Schema
extends VTCore_Zeus_Customizer_Model {

  private $colorBuilder;

  protected $panelKey = 'zeus_schema';
  protected $key = 'schema';

  /**
   * Method for building the schema color options
   */
  public function register() {

    if (!$this->getCache()) {

      // Always build New OBJECT!
      $this->object = new VTCore_Zeus_Schema_Factory();
      $this->object->init()->RetrieveSchemas();

      $i = 1;

      $this->object->setObject('colorBuilder', new VTCore_Zeus_Schema_Color($this->object->getActiveSchema()->getData('color'), false, false, true));

      $options = array();
      foreach ($this->object->getSchemas() as $key => $schema) {
        $options[$schema->getSchema('id')] = $schema->getSchema('name');
      }

      $this->context[$this->key]['panels']['styles'] = array(
        'title' => __('Color & Fonts', 'dreamhome'),
        'priority' => 403,
        'capability' => 'edit_theme_options',
        'description' => __('Configure the theme color and fonts', 'dreamhome'),
      );

      $this->context[$this->key]['sections']['schema'] = array(
        'title' => __('Change Schema', 'dreamhome'),
        'priority' => 0,
        'capability' => 'edit_theme_options',
        'panel' => 'styles',
      );

      $this->context[$this->key]['settings']['schema-active'] = array(
        'object' => false,
        'default' => $this->object->getActiveSchemaID(),
        'transport' => 'postMessage',
        'capability' => 'edit_theme_options',
        'priority' => 0,
      );

      $this->context[$this->key]['controls']['schema-active'] = array(
        'object' => 'VTCore_Wordpress_Customizer_Element_Select',
        'label' => __('Select Style Schemas', 'dreamhome'),
        'section' => 'schema',
        'settings' => 'schema-active',
        'priority' => 0,
        'type' => 'select',
        'choices' => $options,
      );

      foreach ($this->object->getActiveSchema()->getData('color') as $key => $data) {

        // Dont process broken color schema entry
        if (!isset($data['title'])
            || !isset($data['description'])
            || !isset($data['selectors'])
            || !isset($data['parent'])) {

          continue;
        }

        $section = 'color-' . $key . '-section' ;

        $this->context[$this->key]['sections'][$section] = array(
          'title' => $data['title'],
          'description' => $data['description'],
          'panel' => 'styles',
          'priority' => $i++,
        );

        foreach ($data as $elkey => $value) {

          if (in_array($elkey, array('title', 'description', 'selectors', 'parent'))) {
            continue;
          }

          $text = str_replace('-', ' ', ucfirst($elkey));
          $name = 'schemas[color][' . $key . '][' . $elkey . ']';
          $objectKey = $key . '--' . $elkey;
          $target = $this->getColorTarget($objectKey);
          $rules = $this->getColorRules($objectKey);

          $this->context[$this->key]['settings'][$name] = array(
            'default'     => $value,
            'transport'   => 'postMessage',
            'capability' => 'edit_theme_options',
            'priority' => $i++,
          );


          if (strpos($elkey, 'color') !== false
              || strpos($elkey, '-hover') !== false
              || strpos($elkey, '-focus') !== false
              || strpos($elkey, '-visited') !== false) {

            $this->context[$this->key]['controls'][$name] = array(
              'object' => 'VTCore_Wordpress_Customizer_Element_Color',
              'label' =>  $text,
              'section' => $section,
              'settings' => $name,
              'priority' => $i++,
              'type' => 'vtcore_color',
            );

          }

          // Not working yet!
          elseif (strpos($elkey, 'gradient') !== false) {

            $this->context[$this->key]['controls'][$name] = array(
              'object' => 'VTCore_Wordpress_Customizer_Element_Gradient',
              'label' =>  $text,
              'section' => $section,
              'settings' => $name,
              'priority' => $i++,
              'type' => 'vtcore_gradient',
            );


          }

          elseif (strpos($elkey, 'image') !== false) {

            $this->context[$this->key]['controls'][$name] = array(
              'object' => 'WP_Customize_Image_Control',
              'label' =>  $text,
              'section' => $section,
              'settings' => $name,
              'priority' => $i++,
            );

          }

          elseif (strpos($elkey, 'background-repeat') !== false) {

            $this->context[$this->key]['controls'][$name] = array(
              'object' => 'VTCore_Wordpress_Customizer_Element_Select',
              'label' => $text,
              'section' => $section,
              'settings' => $name,
              'priority' => $i++,
              'type' => 'vtcore_select',
              'choices' => array(
                '' => __('Not set', 'dreamhome'),
                'no-repeat' => __('No Repeat', 'dreamhome'),
                'repeat' => __('Repeat All', 'dreamhome'),
                'repeat-x' => __('Repeat Horizontally', 'dreamhome'),
                'repeat-y' => __('Repeat Vertically', 'dreamhome'),
              ),
            );


          }
          elseif (strpos($elkey, 'border-style') !== false) {

            $this->context[$this->key]['controls'][$name] = array(
              'object' => 'VTCore_Wordpress_Customizer_Element_Select',
              'label' => $text,
              'section' => $section,
              'settings' => $name,
              'priority' => $i++,
              'type' => 'vtcore_select',
              'choices' => array(
                '' => __('Not set', 'dreamhome'),
                'none' => __('None', 'dreamhome'),
                'inherit' => __('Inherit', 'dreamhome'),
                'solid' => __('Solid', 'dreamhome'),
                'dotted' => __('Dotted',BASE_THEME),
                'dashed' => __('Dashed', 'dreamhome'),
                'double' => __('Double', 'dreamhome'),
                'ridge' => __('Ridge', 'dreamhome'),
                'inset' => __('Inset', 'dreamhome'),
                'outset' => __('Outset', 'dreamhome'),
                'groove' => __('Groove', 'dreamhome'),
              ),
            );


          }
          elseif (strpos($elkey, 'font-style') !== false
            || strpos($elkey, 'heading-style') !== false) {

            $this->context[$this->key]['controls'][$name] = array(
              'object' => 'VTCore_Wordpress_Customizer_Element_Select',
              'label' => $text,
              'section' => $section,
              'settings' => $name,
              'priority' => $i++,
              'type' => 'vtcore_select',
              'choices' => array(
                '' => __('Not set', 'dreamhome'),
                'normal' => __('Normal', 'dreamhome'),
                'oblique' => __('Oblique', 'dreamhome'),
                'italic' => __('Italic', 'dreamhome'),
                'inherit' => __('Inherit',BASE_THEME),
              ),
            );

          }
          elseif (strpos($elkey, 'weight') !== false) {

            $this->context[$this->key]['controls'][$name] = array(
              'object' => 'VTCore_Wordpress_Customizer_Element_Select',
              'label' => $text,
              'section' => $section,
              'settings' => $name,
              'priority' => $i++,
              'type' => 'vtcore_select',
              'choices' => array(
                '' => __('Not set', 'dreamhome'),
                'inherit' => __('Inherit',BASE_THEME),
                100 => __('Thin', 'dreamhome'),
                200 => __('Extra light', 'dreamhome'),
                300 => __('Light', 'dreamhome'),
                400 => __('Normal', 'dreamhome'),
                500 => __('Medium', 'dreamhome'),
                600 => __('Demi bold', 'dreamhome'),
                700 => __('Bold', 'dreamhome'),
                800 => __('Heavy', 'dreamhome'),
                900 => __('Black', 'dreamhome'),
              ),
            );

          }
          elseif (strpos($elkey, 'family') !== false) {

            $this->context[$this->key]['controls'][$name] = array(
              'object' => 'VTCore_Wordpress_Customizer_Element_Font',
              'label' => $text,
              'section' => $section,
              'settings' => $name,
              'priority' => $i++,
              'type' => 'vtcore_font',
            );
          }


          else {
            $this->context[$this->key]['controls'][$name] = array(
              'object' => 'VTCore_Wordpress_Customizer_Element_Text',
              'label' => $text,
              'section' => $section,
              'settings' => $name,
              'priority' => $i++,
              'type' => 'vtcore_text',
            );
          }

          $this->context[$this->key]['pointers'][$name] = array(
            'target' => implode(', ',$target),
            'rules' => array_shift($rules),
          );
        }
      }

      $this->setCache();
    }

    $this->insert();

    return $this;
  }


  public function getColorTarget($key) {
    return $this->object->getObject('colorBuilder')->getSchema($key)->getTarget();
  }



  public function getColorRules($key) {
    $rules = array();
    $objects = $this->object->getObject('colorBuilder')->getSchema($key)->getRules();
    $object = array_shift($objects);

    if (is_object($object)) {
      foreach ($object->getRules() as $rule) {
        list($key, $value) = explode(':', $rule);
        $rules[] = $key;
      }
    }

    return $rules;
  }

}