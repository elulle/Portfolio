<?php
/**
 * Class for hooking into vtcore wpuserloop object
 * and altering its query parameter
*
*
* @author jason.xie@victheme.com
*
*/
class VTCore_Zeus_Actions_VTCore__Wordpress__User__Loop__Detect__Query
extends VTCore_Wordpress_Models_Hook {

  public function hook($object = NULL) {

    if ($object instanceof VTCore_Wordpress_Element_WpUserLoop) {

      // Altering context for agents-custom-single-photo.php
      if ($object->getContext('template.items') == 'agents-custom-single-photo.php') {

        VTCore_Wordpress_Utility::loadAsset('jquery-slick');
        VTCore_Wordpress_Utility::loadAsset('jquery-verticalcenter');

        $slickSettings = array(
          'arrows' => false,
          'centerMode' => false,
          'centerPadding' => '0px',
          'slidesToShow' => 1,
          'slidesToScroll' => 1,
          'dots' => true,
          'adaptiveHeight' => true,
          'variableWidth' => false,
          'appendDots' => '.inner-content .vertical-target',
        );

        $object->removeContext('data.isotope-options');
        $object->removeData('isotope-options');
        $object->addClass('slick-carousel');
        $object->addData('settings', $slickSettings);
      }


      // Altering context for agents-custom-inline-photo.php
      if ($object->getContext('template.items') == 'agents-custom-inline-photo.php') {

        VTCore_Wordpress_Utility::loadAsset('jquery-slick');
        VTCore_Wordpress_Utility::loadAsset('jquery-equalheight');

        $width = array(
          'mobile' => 769,
          'tablet' => 992,
          'small' => 1199,
          'large' => 5000,
        );

        $breakObject = new stdClass();
        $breakObject->breakpoint = 480;

        $settingsObject = new stdClass();
        $settingsObject->slidesToShow = 1;
        $breakObject->settings = $settingsObject;
        $breakpoint = array($breakObject);

        foreach ($object->getContext('grids.columns') as $size => $column) {
          $breakObject = new stdClass();
          $breakObject->breakpoint = $width[$size];

          $settingsObject = new stdClass();
          $settingsObject->slidesToShow = ceil(12 / $column);
          $breakObject->settings = $settingsObject;

          $breakpoint[] = $breakObject;
        }

        $slickSettings = array(
          'arrows' => true,
          'centerMode' => false,
          'centerPadding' => '0px',
          'slidesToShow' => ceil(12 / $object->getContext('grids.columns.large')),
          'slidesToScroll' => 1,
          'responsive' => array_reverse($breakpoint),
          'dots' => false,
          'adaptiveHeight' => true,
          'variableWidth' => false,
          'prevArrow' => '<button type="button" class="slick-prev">&larr; ' . __('Prev', 'dreamhome') . '</button>',
          'nextArrow' => '<button type="button" class="slick-next">' . __('Next', 'dreamhome') . ' &rarr;</button>',
        );


        $object->addContext('id', false);
        $object->addContext('ajax', false);
        $object->removeContext('data.isotope-options');
        $object->removeData('isotope-options');
        $object->addClass('equalheightRow');
        $object->addClass('slick-carousel');
        $object->addData('settings', $slickSettings);

      }


      // Altering context for agent grid mode
      if ($object->getContext('template.items') == 'agents-grid.php') {
        $object->addData('isotope-options.fitRows.equalheight', true);
      }
    }
  }
}