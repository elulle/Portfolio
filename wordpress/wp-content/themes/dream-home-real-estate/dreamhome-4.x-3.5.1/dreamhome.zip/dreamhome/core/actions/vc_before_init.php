<?php
/**
 * Class for hooking to init action
 * and adding extra class to it.
 *
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Actions_VC__Before__Init
extends VTCore_Wordpress_Models_Hook {

  public function hook() {
    VTCore_Zeus_Init::getFactory('vc')->registerTheme();
  }
}