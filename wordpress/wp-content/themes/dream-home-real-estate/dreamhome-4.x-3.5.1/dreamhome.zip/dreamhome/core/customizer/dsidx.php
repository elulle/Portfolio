<?php
/**
 * Class for generating customizer array
 *
 * @author jason.xie@victheme.com
 */
class VTCore_Zeus_Customizer_DsIDX
extends VTCore_Zeus_Customizer_Model {

  protected $panelKey = 'zeus_dsidx';
  protected $key = 'dsidx';

  public function register() {

    if (!$this->getCache()) {
      $this->object = new VTCore_Zeus_Panels_DsIDX(array(
        'features' => VTCore_Zeus_Init::getFactory('features'),
        'process' => false,
        'build' => 'object',
      ));

      $this->context[$this->key]['panels'][$this->panelKey] = array(
        'title' => __('DsIDX', 'dreamhome'),
        'priority' => 403,
        'capability' => 'edit_theme_options',
        'description' => __('Configure the theme DsIDX page options.', 'dreamhome'),
        'active_callback' => array($this, 'active_callback'),
      );

      $this->buildContext();
      $this->setCache();
    }

    $this->insert();


    return $this;
  }

  public function active_callback() {

    global $wp_query;

    $active = false;

    // Integration to dsidx plugin
    if (get_query_var('idx-action') == 'results' || isset($wp_query->query['ds-idx-listings-page'])) {
      $active = true;
    }

    if (get_query_var('idx-action') == 'details') {
      $active = true;
    }

    return $active;
  }

}
