<?php
/**
 * Hooking into display widgets for
 * additional logic when processing
 * agents page
 *
 * @author jason.xie@victheme.com
 */
class VTCore_Zeus_Filters_DW__Instance__Visibility
extends VTCore_Wordpress_Models_Hook {

  protected $weight = 30;
  protected $argument = 2;

  public function hook($show = NULL, $instance = NULL) {

    global $wp_query;

    // Bridging dsidxpress plugin to display suite
    if (defined('DSIDXPRESS_PLUGIN_VERSION')
        && isset($wp_query->query["idx-action"])) {

      // dsidx single page logic
      if ($wp_query->query["idx-action"] == 'details'
          && isset($instance['page-dsidx-details'])
          && $instance['page-dsidx-details'] == 1) {

        $show  = true;
      }

      // dsidx listing page
      if ($wp_query->query["idx-action"] == 'results'
          && isset($instance['page-dsidx-results'])
          && $instance['page-dsidx-results'] == 1) {

        $show  = true;
      }
    }

    return $show;
  }
}