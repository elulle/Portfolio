<?php
/**
 * Class for filtering customize_register
 * and adding extra class to it.
 *
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Actions_Customize__Register
  extends VTCore_Wordpress_Models_Hook {

  public function hook($wp_customize = NULL) {

    $wp_customize->remove_section('colors');
    $wp_customize->remove_section('background-image');
    $wp_customize->remove_section('header-image');

    // Widget Panel
    // $wp_customize->remove_panel('widgets');

    // Theme options panel
    $object = new VTCore_Zeus_Customizer_General();
    $object->register();

    // Clear early to minimize memory footprint
    VTCore_Wordpress_Init::getFactory('customizer')
      ->process($wp_customize)
      ->clear();

    // Schema panel
    $object = new VTCore_Zeus_Customizer_Schema();
    $object->register();

    // Clear early to minimize memory footprint
    VTCore_Wordpress_Init::getFactory('customizer')
      ->process($wp_customize)
      ->clear();


    // Layout Panel
    VTCore_Wordpress_Utility::loadAsset('bootstrap-grids');

    $object = new VTCore_Zeus_Customizer_Layout();
    $object->register();

    // Clear early to minimize memory footprint
    VTCore_Wordpress_Init::getFactory('customizer')
      ->process($wp_customize)
      ->clear();

    // Page Panel
    $object = new VTCore_Zeus_Customizer_Page();
    $object->register();

    // Clear early to minimize memory footprint
    VTCore_Wordpress_Init::getFactory('customizer')
      ->process($wp_customize)
      ->clear();

    // Post Panel
    $object = new VTCore_Zeus_Customizer_Post();
    $object->register();

    // Clear early to minimize memory footprint
    VTCore_Wordpress_Init::getFactory('customizer')
      ->process($wp_customize)
      ->clear();

    // Property Panel
    if (defined('VTCORE_PROPERTY_LOADED')) {
      $object = new VTCore_Zeus_Customizer_Property();
      $object->register();

      // Clear early to minimize memory footprint
      VTCore_Wordpress_Init::getFactory('customizer')
        ->process($wp_customize)
        ->clear();
    }

    // Property Agents Panel
    if (defined('VTCORE_AGENTS_LOADED')) {
      $object = new VTCore_Zeus_Customizer_Agents();
      $object->register();

      // Clear early to minimize memory footprint
      VTCore_Wordpress_Init::getFactory('customizer')
        ->process($wp_customize)
        ->clear();

    }

    // DsIDX Panel
    if (defined('VTCORE_DSIDX_LOADED')) {
      $object = new VTCore_Zeus_Customizer_DsIDX();
      $object->register();

      // Clear early to minimize memory footprint
      VTCore_Wordpress_Init::getFactory('customizer')
        ->process($wp_customize)
        ->clear();
    }

    // Clear memory
    $object = NULL;
    unset($object);

    $this->preprocess($wp_customize);


  }


  /**
   * Method for performing final preprocessing
   * This is prepared for different theme needs
   * different pre processing method.
   *
   * Areas, Regions and Schema altering best performed
   * in their own alter actions. That way once altered
   * will effect all factory and contexes.
   *
   * @param $wp_customize
   *
   * @see VTCore_Zeus_Actions_VTCore__Zeus__Alter__Areas
   * @see VTCore_Zeus_Actions_VTCore__Zeus__Alter__Regions
   * @see VTCore_Zeus_Actions_VTCore__Zeus__Alter__Schema
   * @see VTCore_Zeus_Actions_VTCore__Zeus__Alter__Features
   */
  protected function preprocess($wp_customize) {}
}