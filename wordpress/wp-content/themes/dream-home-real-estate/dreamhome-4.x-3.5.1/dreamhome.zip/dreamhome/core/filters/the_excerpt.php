<?php
/**
 * Class for filtering the_excerpt
 * readmore button
 * and adding extra class to it.
 *
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Filters_The__Excerpt
extends VTCore_Wordpress_Models_Hook {

  public function hook($excerpt = NULL) {
    return $excerpt;
  }
}