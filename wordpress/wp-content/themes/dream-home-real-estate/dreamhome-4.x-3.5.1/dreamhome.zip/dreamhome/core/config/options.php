<?php
/**
 * Simple class for managing theme features.
 *
 * Themer must fill out the theme features variables
 * in this class for setting up the default values for
 * the theme.
 *
 * User can change the configuration via theme options
 * and save them to the theme database entry as wordpress
 * theme_mod specifies.
 *
 * This class then will merge the database entry with the
 * default values and pass them to theme templates via
 * VTCore_Zeus_Utility class.
 *
 * Other plugin can interact with the features system by
 * using Wordpress action vtcore_zeus_alter_features
 * and use the object public methods to alter the features.
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Config_Options
extends VTCore_Wordpress_Models_Config {

  protected $database = 'features';
  protected $filter = 'vtcore_zeus_features_context_alter';
  protected $loadFunction = 'get_theme_mod';
  protected $savefunction = 'set_theme_mod';
  protected $deleteFunction = 'remove_theme_mod';

  /**
   * Centralized location for registering default
   * values for all the theme features excluding
   * the default values for schema settings.
   */
  public function register(array $options) {
    $this->url = defined('VTCORE_ZEUS_THEME_URL') ? VTCORE_ZEUS_THEME_URL : get_template_directory_uri();
    $this->options = array(
      'show' => array(
        'teaser_list' => array(
          'title' => true,
          'image' => true,
          'byline' => true,
          'excerpt' => true,
          'readmore' => true,
        ),
        'teaser_grid' => array(
          'title' => true,
          'image' => true,
          'byline' => true,
          'excerpt' => true,
          'readmore' => true,
        ),
        'teaser_sticky' => array(
          'title' => true,
          'image' => true,
          'byline' => true,
          'excerpt' => true,
          'readmore' => true,
        ),
        'full' => array(
          'image' => true,
          'title' => true,
          'byline' => true,
          'content' => true,
          'author' => true,
          'comments' => true,
          'comment_form' => true,
          'social' => true,
        ),
        'notfound' => array(
          'title' => true,
          'content' => true,
        ),
        'page' => array(
          'image' => true,
          'title' => true,
          'content' => true,
          'comments' => true,
          'comment_form' => true,
          'social' => true,
        ),

        'footer' => array(
          'fullfooter' => true,
        ),
      ),

      'images' => array(
        'thumbnail' => array(
          'width' => 800,
          'height' => 600,
          'crop' => false
        ),
        'full' => array(
          'width' => 800,
          'height' => 600,
          'crop' => false
        ),
      ),


      'sidebars' => array(
        'teaser' => 'right',
        'full' => 'right',
        'notfound' => 'right',
        'page' => 'right',

      ),

      'options' => array(

        'header' => array(
          'template' => false,
        ),
        'nicescroll' => array(
          'enable' => true,
          'bouncescroll' => true,
          'cursorwidth' => '10px',
          'cursorborderradius' => '0',
          'scrollspeed' => '100',
          'zindex' => '9999',
          'touchbehavior' => false,
          'autohidemode' => false,
        ),

        'offcanvas' => array(
          'enable' => true,
          'swipe' => false,
          'slide' => array(
            'easing' => 'swing',
            'duration' => '350',
          ),
        ),

        'styling' => array(
          'saw_effect' => false,
        ),

        'favicon' => array(
          'image' => VTCORE_ZEUS_THEME_URL . '/favicon.ico',
        ),

        'menu' => array(
          'disable_parent' => false,
          'enable_slick' => true,
          'enable_sticky' => true,
          'enable_autoformat' => false,
        ),

        'animsition' => array(
          'enable' => false,
          'loading_text' => __('Loading ..', 'dreamhome'),
          'animation_in' => 'zoom-in-sm',
          'in_duration' => 2000,
          'animation_out' => 'zoom-out-sm',
          'out_duration' => 2000,
        ),

        'page' => array(
          'maxwidth' => 'max-1170',
          'style' => 'style-normal',
          'responsive' => 'bs-responsive',
        ),

        'blog' => array(
          'teaser' => 'blog-grid',
          'grids' => array(
            'columns' => array(
              'mobile' => 6,
              'tablet' => 6,
              'small' => 6,
              'large' => 6,
            ),
          ),
        ),

        'form' => array(
          'jvfloat' => true,
        ),

        'notfound' => array(
          'title' => __('Oops. This Page Could Not Be Found!', 'dreamhome'),
          'content' => __('Oops! 404', 'dreamhome'),
        ),
        'footer' => array(
          'copyrighttext' => __('Dream Home Premium Theme built by VicTheme.com', 'dreamhome'),
        ),

      ),
    );


    if (defined('VTCORE_PROPERTY_LOADED')) {

      $this->options['show']['property_teaser_list'] = array(
        'image' => true,
        'title' => true,
        'address' => true,
        'price' => true,
        'excerpt' => true,
        'social' => false,
        'readmore' => false,
        'info' => true,
      );

      $this->options['show']['property_teaser_grid'] = array(
        'image' => true,
        'title' => true,
        'address' => true,
        'price' => true,
        'excerpt' => true,
        'social' => false,
        'readmore' => false,
        'info' => true,
      );


      $this->options['show']['property_single'] = array(
        'fotorama' => true,
        'title' => true,
        'address' => true,
        'fields' => true,
        'attributes' => true,
        'content' => true,
        'price' => true,
        'social' => true,
        'floorplan' => true,
        'video' => true,
        'maps' => true,
        'contact' => true,
        'status' => true,
        'listing' => true,
        'agents' => true,
      );

      $this->options['sidebars']['property_archive'] = 'left';
      $this->options['sidebars']['property_single'] = 'right';

      $this->options['options']['property_single_listing'] = array(
        'title' => __('Our Latest Property', 'dreamhome'),
        'description' => __('Browse our latest property listing', 'dreamhome'),
      );
    }


    if (defined('VTCORE_AGENTS_LOADED')) {

      $this->options['show']['agents_listing_grid'] = array(
        'photo' => true,
        'name' => true,
        'location' => true,
        'info' => false,
        'social' => true,
        'bio' => true,
        'readmore' => false,
      );

      $this->options['show']['agents_listing_list'] = array(
        'photo' => true,
        'name' => true,
        'location' => true,
        'info' => true,
        'social' => true,
        'bio' => true,
        'readmore' => true,
      );

      $this->options['show']['agents_profile'] = array(
        'content' => true,
        'photo' => true,
        'info' => true,
        'listing' => true,
        'contact' => true,
        'maps' => true,
      );

      $this->options['sidebars']['agents_archive'] = 'none';
      $this->options['sidebars']['agents_profile'] = 'none';

      $this->options['options']['agents_profile'] = array(
        'title' => __('Agents Property', 'dreamhome'),
        'description' => __('Browse property listing by this agents', 'dreamhome'),
        'listing' => 3,
      );
    }


    if (defined('DSIDXPRESS_PLUGIN_VERSION')) {

      $this->options['show']['dsidx-listing'] = array(
        'title' => true,
        'content' => true,
      );

      $this->options['show']['dsidx-page'] = array(
        'title' => true,
        'content' => true,
        'social' => true,
      );

      $this->options['sidebars']['dsidx-listing'] = 'right';
      $this->options['sidebars']['dsidx-page'] = 'right';

      $this->options['options']['dsidx'] = array(
        'mode' => 'grid',
        'grids' => array(
          'columns' => array(
            'mobile' => 6,
            'tablet' => 6,
            'small' => 4,
            'large' => 4,
          ),
        ),
      );
    }

    $this->schema = VTCore_Wordpress_Init::getFactory('schemas');

    // Try to fill out the logo options if the default logo is false
    if (!$this->get('options.logo')) {
      if ($this->schema->getActiveSchema()->getData('logo')) {
        $this->mutate('options.logo', $this->schema->getActiveSchema()->getData('logo'));
      }
    }

    // Try to fill out the header template options if the default header template is false
    if (!$this->get('options.header.template')) {
      if ($this->schema->getActiveSchema()->getData('header')) {
        $this->mutate('options.header.template', $this->schema->getActiveSchema()->getData('header'));
      }
    }

    // Merge the user supplied options
    $this->merge($options);

    // Apply the hookable filter
    $this->filter();

    // Inject from database
    $this->load();

    // Backward compatibility
    do_action('vtcore_zeus_alter_features', $this);

    // Always turn off slick nav on non responsive mode
    if ($this->options['options']['page']['responsive'] == 'bs-fixed') {
      $this->options['options']['menu']['enable_slick'] = false;
    }

    return $this;
  }
}