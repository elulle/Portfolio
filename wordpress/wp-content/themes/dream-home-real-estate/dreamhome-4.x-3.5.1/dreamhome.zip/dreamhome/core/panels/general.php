<?php
/**
 * Panel section for configuring general options
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Panels_General
extends VTCore_Zeus_Panels_Model {

  /**
   * Overriding parent method
   * @see VTCore_Bootstrap_Element_BsElement::buildElement()
   */
  public function buildElement() {

    // Logo Configurations
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
        'text' => __('Logo', 'dreamhome'),
        'id' => 'vtcore-zeus-logo-panel',
      ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsRow()
      ->lastChild()
      ->BsColumn(array(
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 8,
            'small' => 8,
            'large' => 8,
          ),
        ),
      ))
      ->lastChild()
      ->BsText(array(
        'text' => __('Text', 'dreamhome'),
        'name' => 'theme[features][options][logo][text]',
        'value' => $this->getOption('logo', 'text'),
        'description' => __('Set the text to serve as the logo or leave empty to disable it.', 'dreamhome'),
      ))
      ->BsText(array(
        'text' => __('Slogan', 'dreamhome'),
        'name' => 'theme[features][options][logo][slogan]',
        'value' => $this->getOption('logo', 'slogan'),
        'description' => __('Set the text to serve as the slogan text underneath the logo or leave empty to disable it.', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsText(array(
        'text' => __('Image Width', 'dreamhome'),
        'name' => 'theme[features][options][logo][width]',
        'value' => $this->getOption('logo', 'width'),
        'description' => __('Force the logo image to have maximum width as configured.', 'dreamhome'),
        'suffix' => 'px',
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 12,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsText(array(
        'text' => __('Image Height', 'dreamhome'),
        'name' => 'theme[features][options][logo][height]',
        'value' => $this->getOption('logo', 'height'),
        'description' => __('Force the logo image to have maximum height as configured.', 'dreamhome'),
        'suffix' => 'px',
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 12,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->getParent()
      ->getParent()
      ->BsColumn(array(
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ))
      ->lastChild()
      ->addOverloaderPrefix('VTCore_Wordpress_Form_')
      ->WpMedia(array(
        'text' => __('Image', 'dreamhome'),
        'name' => 'theme[features][options][logo][image]',
        'value' => $this->getOption('logo', 'image'),
        'description' => __('Image that will be used as the logo for normal screen', 'dreamhome'),
        'attributes' => array(
          'class' => array('logo-preview'),
        ),
      ));

    $this->processPanel();








    // Favicon Configurations
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
        'text' => __('Favicon', 'dreamhome'),
        'id' => 'vtcore-zeus-favicon-panel',
      ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsRow()
      ->lastChild()
      ->addOverloaderPrefix('VTCore_Wordpress_Form_')
      ->BsDescription(array(
        'text' =>  __('Upload the image that will be served as the favicon icon', 'dreamhome'),
        'grids' => array(
          'columns' => array(
            'mobile' => 8,
            'tablet' => 8,
            'small' => 8,
            'large' => 8,
          ),
        ),
      ))
      ->WpMedia(array(
        'name' => 'theme[features][options][favicon][image]',
        'value' => $this->getOption('favicon', 'image'),
        'attributes' => array(
        'class' => array('favicon-preview'),
        ),
        'grids' => array(
          'columns' => array(
            'mobile' => 4,
            'tablet' => 4,
            'small' => 4,
            'large' => 4,
          ),
        ),
      ));

    $this->processPanel();









    // Build the menu options
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
        'text' => __('Menu Options', 'dreamhome'),
        'id' => 'vtcore-zeus-menu-panel',
      ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][options][menu][disable_parent]',
        'text' => __('Disable Parent Link', 'dreamhome'),
        'description' => __('Disabling the first level parent link for menu with children and replace it with # as the destination.', 'dreamhome'),
        'checked' => (boolean) $this->getOption('menu', 'disable_parent'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][options][menu][enable_slick]',
        'text' => __('Enable Slick Navigation', 'dreamhome'),
        'description' => __('Enable or disable the slick navigation when screen width is less than 768px.', 'dreamhome'),
        'checked' => (boolean) $this->getOption('menu', 'enable_slick'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][options][menu][enable_sticky]',
        'text' => __('Enable Sticky Header', 'dreamhome'),
        'description' => __('Enable or disable the sticky header.', 'dreamhome'),
        'checked' => (boolean) $this->getOption('menu', 'enable_sticky'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][options][menu][enable_autoformat]',
        'text' => __('Enable Auto Shrink', 'dreamhome'),
        'description' => __('Auto shrink will covert menu into small menu when the menu is too wide', 'dreamhome'),
        'checked' => (boolean) $this->getOption('menu', 'enable_autoformat'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));

    $this->processPanel();










    // Initial loading animation
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
        'text' => __('Page Loading Animation', 'dreamhome'),
        'id' => 'vtcore-zeus-animsition-panel',
      ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][options][animsition][enable]',
        'text' => __('Enable page loading animation', 'dreamhome'),
        'description' => __('Toggle to enalbe or disable the initial page loading animation', 'dreamhome'),
        'checked' => (boolean) $this->getOption('animsition', 'enable'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsText(array(
        'name' => 'theme[features][options][animsition][loading_text]',
        'text' => __('Loading Text', 'dreamhome'),
        'description' => __('Set the text to display when page is loading.', 'dreamhome'),
        'value' => $this->getOption('animsition', 'loading_text'),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsSelect(array(
        'name' => 'theme[features][options][animsition][animation_in]',
        'text' => __('Animation In', 'dreamhome'),
        'description' => __('Type of animation used when loading in', 'dreamhome'),
        'value' => $this->getOption('animsition', 'animation_in'),
        'attributes' => array(
          'class' => array('clear'),
        ),
        'options' => array(
          'fade-in' => __('Fade In', 'dreamhome'),
          'fade-out' => __('Fade Out', 'dreamhome'),
          'fade-in-up' => __('Fade In Out', 'dreamhome'),
          'fade-out-up' => __('Fade Out Up', 'dreamhome'),
          'fade-in-down' => __('Fade In Down', 'dreamhome'),
          'fade-out-down' => __('Fade Out Down', 'dreamhome'),
          'fade-in-left' => __('Fade In Left', 'dreamhome'),
          'fade-out-left' => __('Fade Out Left', 'dreamhome'),
          'fade-in-right' => __('Fade In Right', 'dreamhome'),
          'fade-out-right' => __('Fade Out Right', 'dreamhome'),
          'rotate-in' => __('Rotate In', 'dreamhome'),
          'rotate-out' => __('Rotate Out', 'dreamhome'),
          'flip-in-x' => __('Flip in X', 'dreamhome'),
          'flip-out-x' => __('Flip out X', 'dreamhome'),
          'flip-in-y' => __('Flip in Y', 'dreamhome'),
          'flip-out-y' => __('Flip out Y', 'dreamhome'),
          'zoom-in' => __('Zoom In', 'dreamhome'),
          'zoom-out' => __('Zoom Out', 'dreamhome'),
        ),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsText(array(
        'name' => 'theme[features][options][animsition][in_duration]',
        'text' => __('Animation in duration', 'dreamhome'),
        'description' => __('Set the animation duration when loading in', 'dreamhome'),
        'suffix' => __('miliseconds', 'dreamhome'),
        'value' => $this->getOption('animsition', 'in_duration'),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsSelect(array(
        'name' => 'theme[features][options][animsition][animation_out]',
        'text' => __('Animation Out', 'dreamhome'),
        'description' => __('Type of animation used when loading out', 'dreamhome'),
        'value' => $this->getOption('animsition', 'animation_out'),
        'attributes' => array(
          'class' => array('clear'),
        ),
        'options' => array(
          'fade-in' => __('Fade In', 'dreamhome'),
          'fade-out' => __('Fade Out', 'dreamhome'),
          'fade-in-up' => __('Fade In Out', 'dreamhome'),
          'fade-out-up' => __('Fade Out Up', 'dreamhome'),
          'fade-in-down' => __('Fade In Down', 'dreamhome'),
          'fade-out-down' => __('Fade Out Down', 'dreamhome'),
          'fade-in-left' => __('Fade In Left', 'dreamhome'),
          'fade-out-left' => __('Fade Out Left', 'dreamhome'),
          'fade-in-right' => __('Fade In Right', 'dreamhome'),
          'fade-out-right' => __('Fade Out Right', 'dreamhome'),
          'rotate-in' => __('Rotate In', 'dreamhome'),
          'rotate-out' => __('Rotate Out', 'dreamhome'),
          'flip-in-x' => __('Flip in X', 'dreamhome'),
          'flip-out-x' => __('Flip out X', 'dreamhome'),
          'flip-in-y' => __('Flip in Y', 'dreamhome'),
          'flip-out-y' => __('Flip out Y', 'dreamhome'),
          'zoom-in' => __('Zoom In', 'dreamhome'),
          'zoom-out' => __('Zoom Out', 'dreamhome'),
        ),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsText(array(
        'name' => 'theme[features][options][animsition][out_duration]',
        'text' => __('Animation out duration', 'dreamhome'),
        'description' => __('Set the animation duration when loading out', 'dreamhome'),
        'suffix' => __('miliseconds', 'dreamhome'),
        'value' => $this->getOption('animsition', 'out_duration'),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));

    $this->processPanel();








    // Build the styling
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Global Styling', 'dreamhome'),
      'id' => 'vtcore-zeus-styling-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->addChildren(new VTCore_Bootstrap_Grid_BsRow())
      ->lastChild()
      ->addChildren(new VTCore_Bootstrap_Form_BsCheckbox(array(
        'name' => 'theme[features][options][styling][saw_effect]',
        'text' => __('Use the jigsaw saw border effect', 'dreamhome'),
        'description' => __('Enabling this will show the jigsaw border effect on some of the page elements', 'dreamhome'),
        'checked' => (boolean) $this->getOption('styling', 'saw_effect'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )))
      ->addChildren(new VTCore_Bootstrap_Form_BsCheckbox(array(
        'name' => 'theme[features][options][form][jvfloat]',
        'text' => __('Enable JvFloat', 'dreamhome'),
        'description' => __('Toggle to enable or disable the jvfloat effect which will convert the form label as hidden placeholder', 'dreamhome'),
        'checked' => (boolean) $this->getOption('form', 'jvfloat'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )));


    $this->processPanel();


    // Nice Scroll Options
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Nice Scroll Options', 'dreamhome'),
      'id' => 'vtcore-zeus-nicescroll-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->addChildren(new VTCore_Bootstrap_Grid_BsRow())
      ->lastChild()
      ->addChildren(new VTCore_Bootstrap_Form_BsCheckbox(array(
        'name' => 'theme[features][options][nicescroll][enable]',
        'text' => __('Enable Nicescroll', 'dreamhome'),
        'description' => __('Toggle to enable or disable the nice scroll bar', 'dreamhome'),
        'checked' => (boolean) $this->getOption('nicescroll', 'enable'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )))
      ->addChildren(new VTCore_Bootstrap_Form_BsCheckbox(array(
        'name' => 'theme[features][options][nicescroll][bouncescroll]',
        'text' => __('Enable Bounce Scroll', 'dreamhome'),
        'description' => __('Toggle to enable or disable the bounce scroll effect', 'dreamhome'),
        'checked' => (boolean) $this->getOption('nicescroll', 'bouncescroll'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )))
      ->addChildren(new VTCore_Bootstrap_Form_BsCheckbox(array(
        'name' => 'theme[features][options][nicescroll][touchbehavior]',
        'text' => __('Enable Touch Screen Behavior', 'dreamhome'),
        'description' => __('Toggle to enable or disable the touch screen scroll behavior', 'dreamhome'),
        'checked' => (boolean) $this->getOption('nicescroll', 'touchbehavior'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )))
      ->addChildren(new VTCore_Bootstrap_Form_BsCheckbox(array(
        'name' => 'theme[features][options][nicescroll][autohide]',
        'text' => __('Enable Autohide', 'dreamhome'),
        'description' => __('Toggle to enable or disable the autohide feature for the scrollbar', 'dreamhome'),
        'checked' => (boolean) $this->getOption('nicescroll', 'autohide'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )))
      ->addChildren(new VTCore_Bootstrap_Form_BsText(array(
        'name' => 'theme[features][options][nicescroll][cursorwidth]',
        'text' => __('Scroll Bar Width', 'dreamhome'),
        'description' => __('Set the scrollbar width in pixel eg. 10px', 'dreamhome'),
        'value' => $this->getOption('nicescroll', 'cursorwidth'),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )))
      ->addChildren(new VTCore_Bootstrap_Form_BsText(array(
        'name' => 'theme[features][options][nicescroll][cursorborderradius]',
        'text' => __('Scroll Bar Border Radius', 'dreamhome'),
        'description' => __('Set the scrollbar border radius in pixel eg. 10px', 'dreamhome'),
        'value' => $this->getOption('nicescroll', 'cursorborderradius'),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )))
      ->addChildren(new VTCore_Bootstrap_Form_BsText(array(
        'name' => 'theme[features][options][nicescroll][scrollspeed]',
        'text' => __('Scrolling Speed', 'dreamhome'),
        'description' => __('Set the scrolling speed in miliseconds', 'dreamhome'),
        'suffix' => 'ms',
        'value' => $this->getOption('nicescroll', 'scrollspeed'),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )))
      ->addChildren(new VTCore_Bootstrap_Form_BsText(array(
        'name' => 'theme[features][options][nicescroll][zindex]',
        'text' => __('Zindex', 'dreamhome'),
        'description' => __('Set the scrollbar zindex', 'dreamhome'),
        'value' => $this->getOption('nicescroll', 'zindex'),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )));

    $this->processPanel();



    // OffCanvas Options
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Offcanvas Options', 'dreamhome'),
      'id' => 'vtcore-zeus-offcanvas-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->addChildren(new VTCore_Bootstrap_Grid_BsRow())
      ->lastChild()
      ->addChildren(new VTCore_Bootstrap_Form_BsCheckbox(array(
        'name' => 'theme[features][options][offcanvas][enable]',
        'text' => __('Enable OffCanvas', 'dreamhome'),
        'description' => __('Toggle to enable or disable the offcanvas element', 'dreamhome'),
        'checked' => (boolean) $this->getOption('offcanvas', 'enable'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )))
      ->addChildren(new VTCore_Bootstrap_Form_BsCheckbox(array(
        'name' => 'theme[features][options][offcanvas][swipe]',
        'text' => __('Enable Swipe', 'dreamhome'),
        'description' => __('Toggle to enable or disable the offcanvas mouse swipe to emulate touch swipe, this options can inteferes with mouse click event. do not activate if it hinders with normal mouse operation mode.', 'dreamhome'),
        'checked' => (boolean) $this->getOption('offcanvas', 'swipe'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )))
      ->addChildren(new VTCore_Bootstrap_Form_BsSelect(array(
        'name' => 'theme[features][options][offcanvas][slide][easing]',
        'text' => __('Slide Easing Effect', 'dreamhome'),
        'description' => __('Choose the easing effect for the slide animation', 'dreamhome'),
        'value' => $this->getOption('offcanvas.slide', 'easing'),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
        'options' => array(
          'swing' => 'swing',
          'linear' => 'linear',
          'easeInQuad' =>  'easeInQuad',
          'easeOutQuad' => 'easeOutQuad',
          'easeInOutQuad' => 'easeInOutQuad',
          'easeInCubic' => 'easeInCubic',
          'easeOutCubic' => 'easeOutCubic',
          'easeInOutCubic' => 'easeInOutCubic',
          'easeInQuart' => 'easeInQuart',
          'easeOutQuart' => 'easeOutQuart',
          'easeInOutQuart' => 'easeInOutQuart',
          'easeInQuint' => 'easeInQuint',
          'easeOutQuint' => 'easeOutQuint',
          'easeInOutQuint' => 'easeInOutQuint',
          'easeInSine' => 'easeInSine',
          'easeOutSine' => 'easeOutSine',
          'easeInOutSine' => 'easeInOutSine',
          'easeInExpo' => 'easeInExpo',
          'easeOutExpo' => 'easeOutExpo',
          'easeInOutExpo' => 'easeInOutExpo',
          'easeInCirc' => 'easeInCirc',
          'easeOutCirc' => 'easeOutCirc',
          'easeInOutCirc' => 'easeInOutCirc',
          'easeInBack' => 'easeInBack',
          'easeOutBack' => 'easeOutBack',
          'easeInOutBack' => 'easeInOutBack',
        )
      )))
      ->addChildren(new VTCore_Bootstrap_Form_BsText(array(
        'name' => 'theme[features][options][offcanvas][slide][duration]',
        'text' => __('Animation Duration', 'dreamhome'),
        'description' => __('Set the animation duration', 'dreamhome'),
        'suffix' => 'ms',
        'value' => $this->getOption('offcanvas.slide', 'duration'),
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      )));

    $this->processPanel();




    // Build the footer elements
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
        'id' => 'vtcore-zeus-footer-panel',
        'text' => __('Footer Element', 'dreamhome'),
      ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][footer][fullfooter]',
        'text' => __('Show Full Footer Element', 'dreamhome'),
        'description' => __('Show / hide the full footer, disabling this will remove the copyright and footer menu element.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('footer', 'fullfooter'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->getParent()
      ->BsText(array(
        'text' => __('Copyright Text', 'dreamhome'),
        'name' => 'theme[features][options][footer][copyrighttext]',
        'value' => $this->getOption('footer', 'copyrighttext'),
        'description' => __('Set the text to serve as copyright text in the full footer element.', 'dreamhome'),
      ));



    $this->processPanel();






    // Build the page not found options
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
        'id' => 'vtcore-zeus-notfound-panel',
        'text' => __('Page 404 Options', 'dreamhome'),
      ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][notfound][title]',
        'text' => __('Show Title', 'dreamhome'),
        'description' => __('Show / hide the 404 page title.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('notfound', 'title'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][notfound][content]',
        'text' => __('Show Content', 'dreamhome'),
        'description' => __('Show / hide the 404 page content.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('notfound', 'content'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->getParent()
      ->BsText(array(
        'text' => __('Title', 'dreamhome'),
        'name' => 'theme[features][options][notfound][title]',
        'value' => $this->getOption('notfound', 'title'),
        'description' => __('Set the title for the page 404.', 'dreamhome'),
      ))
      ->BsTextarea(array(
        'text' => __('Content', 'dreamhome'),
        'name' => 'theme[features][options][notfound][content]',
        'value' => $this->getOption('notfound', 'content'),
        'description' => __('Set the content for the page 404.', 'dreamhome'),
      ));


    $this->processPanel();

  }

}