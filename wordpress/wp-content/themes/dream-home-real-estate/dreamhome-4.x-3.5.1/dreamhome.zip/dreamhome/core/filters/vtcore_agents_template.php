<?php
/**
 * Registering agents template
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Filters_VTCore__Agents__Template
extends VTCore_Wordpress_Models_Hook {

  public function hook($template = NULL) {
    $template['agents-mini-list'] = __('Mini list', 'dreamhome');
    $template['agents-custom-single-photo'] = __('Single author photo', 'dreamhome');
    $template['agents-custom-inline-photo'] = __('Inline author photo', 'dreamhome');

    return $template;
  }
}