<?php
/**
 * Panel section for configuring general options
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Panels_DsIDX
extends VTCore_Zeus_Panels_Model {

  /**
   * Overriding parent method
   * @see VTCore_Bootstrap_Element_BsElement::buildElement()
   */
  public function buildElement() {

    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Listing Page', 'dreamhome'),
      'id' => 'vtcore-zeus-dsidx-listing-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' =>  __('This setting will be applied to the dsidx listing page', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][dsidx-listing][title]',
        'text' => __('Show Title', 'dreamhome'),
        'description' => __('Show / hide the property title.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('dsidx-listing', 'title'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][dsidx-listing][content]',
        'text' => __('Show Content', 'dreamhome'),
        'description' => __('Show / hide the property content.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('dsidx-listing', 'content'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->getParent()
      ->BsSelect(array(
        'text' => __('Teaser Template', 'dreamhome'),
        'name' => 'theme[features][options][dsidx][mode]',
        'description' => __('Define the template mode for the dsidx listing page', 'dreamhome'),
        'value' => $this->getOption('dsidx', 'mode'),
        'options' => array(
          'list' => __('List', 'dreamhome'),
          'grid' => __('Grid', 'dreamhome'),
        ),
      ))
      ->BsGrids(array(
        'columns' => array(
          'text' => __('Teaser Columns', 'dreamhome'),
          'description' => __('Set the teaser items column grids', 'dreamhome'),
        ),
        'name' => 'theme[features][options][dsidx][grids]',
        'value' => $this->getOption('dsidx', 'grids'),
      ));

    $this->processPanel();


    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Single Page', 'dreamhome'),
      'id' => 'vtcore-zeus-dsidx-single-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' => __('The dsidx single page settings will be applied to the dsidx single property page', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][dsidx-page][title]',
        'text' => __('Show Title', 'dreamhome'),
        'description' => __('Show / hide the page title.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('dsidx-page', 'title'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][dsidx-page][content]',
        'text' => __('Show Content', 'dreamhome'),
        'description' => __('Show / hide the page content.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('dsidx-page', 'content'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][dsidx-page][social]',
        'text' => __('Show Social', 'dreamhome'),
        'description' => __('Show / hide the page social button.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('dsidx-page', 'social'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));


    $this->processPanel();


  }

}