<?php
/**
 * Class for altering the default property
 * configuration.
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Filters_VTCore__Property__Config__Alter
extends VTCore_Wordpress_Models_Hook {

  public function hook($config = NULL) {

    // Changing the default grid size
    $config['teasers']['grids'] = array(
      'columns' => array(
        'mobile' => 6,
        'tablet' => 6,
        'small' => 6,
        'large' => 6,
      ),
    );

    // Setting for default fotorama
    $config['fotorama'] = array(
      'width' => '100%',
      'shuffle' => false,
      'shadows' => false,
      'direction' => 'ltr', // rtl || ltr
      'allowfullscreen' => 'false',
      'fit' => 'contain',
      'transition' => 'crossfade',
      'thumbwidth' => '170',
      'thumbheight' => '110',
      'thumbmargin' => '30',
      'startindex' => '0',
    );

    return $config;
  }
}