<?php
/**
 * Hooking into VTCore Headline plugin to define
 * the default settings for the headline element
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Filters_VTCore__Headline__Configuration__Context__Alter
extends VTCore_Wordpress_Models_Hook {

  public function hook($context = NULL) {

    if (!$options = get_option('vtcore_headline_config', false)) {
      $context['dsidx'] = array(
        'general' => array(
          'enable' => true,
          'title' => __('Property IDX Listing', 'dreamhome'),
          'subtitle' => __('Browse available properties', 'dreamhome'),
        ),
      );
    }

    $schemaDefault = VTCore_Zeus_Init::getFactory('schemas')->getActiveSchema()->getData('headline');
    foreach ($context as $key => $content) {
      $context[$key] = wp_parse_args($content, $schemaDefault);
    }

    return $context;
  }
}