<?php
/**
 * Class for storing visual composer grid item templates
 *
 * Example entry arrays :
 *
 * $template[{template name}] = array(
 *   'name' => {template name with translated string}
 *   'template' => '{the visual composer shortcodes for grid}'
 * );
 *
 * @author jason.xie@victheme.com
 */
class VTCore_Zeus_VisualComposer_Grid {

  /**
   * Storing the theme default grid item templates
   * @see filter vc_grid_item_predefined_templates
   */
  public function themeGridTemplates($templates) {

    // Place the templates here!

    return $templates;
  }

}