<?php
/**
 * Hooking into VTCore Headline plugin to remove
 * unsupported metabox tabs
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Filters_VTCore__Headline__Hide__Metabox
extends VTCore_Wordpress_Models_Hook {

  public function hook($context = NULL) {

    // Idxpress listing page can only use the headline
    // main config!
    $context[] = 'ds-idx-listings-page';

    return $context;
  }
}