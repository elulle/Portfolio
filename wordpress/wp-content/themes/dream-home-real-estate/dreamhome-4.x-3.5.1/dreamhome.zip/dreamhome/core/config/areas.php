<?php
/**
 * Configuration for the theme layout areas
 *
 * @author jason.xie@victheme.com
 * @see VTCore_Wordpress_Layout_Area
 *
 */
class VTCore_Zeus_Config_Areas
extends VTCore_Wordpress_Models_Config {

  protected $database = 'areas';
  protected $filter = 'vtcore_zeus_area_context_alter';
  protected $loadFunction = 'get_theme_mod';
  protected $savefunction = 'set_theme_mod';
  protected $deleteFunction = 'remove_theme_mod';

  public function register(array $options) {

    // Set theme default regions
    $this->options = array(
      'top' => array(
        'id' => 'top',
        'name' => __('Top Header', 'dreamhome'),
        'description' => __('Theme top header section.', 'dreamhome'),
        'weight' => 0,
      ),
      'header' => array(
        'id' => 'header',
        'name' => __('Header', 'dreamhome'),
        'description' => __('Theme header section.', 'dreamhome'),
        'weight' => 1,
      ),
      'slider' => array(
        'id' => 'slider',
        'name' => __('Slider', 'dreamhome'),
        'description' => __('Theme slider section.', 'dreamhome'),
        'weight' => 3,
      ),
      'preface' => array(
        'id' => 'preface',
        'name' => __('Preface', 'dreamhome'),
        'description' => __('Theme preface section.', 'dreamhome'),
        'weight' => 4,
      ),
      'content_top' => array(
        'id' => 'content_top',
        'name' => __('Content Top', 'dreamhome'),
        'description' => __('Theme content top section.', 'dreamhome'),
        'weight' => 5,
      ),
      'maincontent' => array(
        'id' => 'maincontent',
        'name' => __('Main Content', 'dreamhome'),
        'description' => __('Theme main content section.', 'dreamhome'),
        'weight' => 6,
      ),
      'content_bottom' => array(
        'id' => 'content_bottom',
        'name' => __('Content Bottom', 'dreamhome'),
        'description' => __('Theme content bottom section.', 'dreamhome'),
        'weight' => 7,
      ),
      'postface' => array(
        'id' => 'postface',
        'name' => __('Postface', 'dreamhome'),
        'description' => __('Theme postface section.', 'dreamhome'),
        'weight' => 8,
      ),
      'footer' => array(
        'id' => 'footer',
        'name' => __('Footer', 'dreamhome'),
        'description' => __('Theme footer section.', 'dreamhome'),
        'weight' => 9,
      ),
      'fullfooter' => array(
        'id' => 'fullfooter',
        'name' => __('Full Footer', 'dreamhome'),
        'description' => __('Theme full footer section.', 'dreamhome'),
        'weight' => 10,
      ),
      'offcanvas' => array(
        'id' => 'Offcanvas',
        'name' => __('Offcanvas', 'dreamhome'),
        'description' => __('Theme offcanvas section.', 'dreamhome'),
        'weight' => 11,
      ),
    );

    // Only build if headline is enabled
    if (defined('VTCORE_HEADLINE_LOADED')) {

      $this->options['headline'] = array(
        'id' => 'headline',
        'name' => __('Headline', 'dreamhome'),
        'description' => __('Theme headline section.', 'dreamhome'),
        'weight' => 2,
      );
    }

    // Merge the user supplied options
    $this->merge($options);

    // Apply the hookable filter
    $this->filter();

    // Inject from database
    $this->load();

    // Backward compatibility
    do_action('vtcore_zeus_alter_areas', $this);

    return $this;
  }

}