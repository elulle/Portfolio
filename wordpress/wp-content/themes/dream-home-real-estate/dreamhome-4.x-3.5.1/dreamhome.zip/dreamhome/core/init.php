<?php
/**
 * Class for initializing Zeus Framework and
 * acts as the bridge between VTCore and Zeus
 * framework
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Init
extends VTCore_Wordpress_Models_Factories {

  static protected $factories;
  private static $theme;

  private $actions = array(
    'widgets_init',
    'wp_enqueue_scripts',
    'pre_get_posts',
    'vtcore_wordpress_user_loop_detect_query',
    'wp_before_admin_bar_render',
    'init',
  );


  private $filters = array(
    'excerpt_more',
    'the_excerpt',
    'the_posts',
    'get_calendar',
    'post_gallery',
    'attribute_escape',
    'cancel_comment_reply_link',
    'comment_reply_link',
    'template_include',
    'wp_nav_menu_objects',
  );


  /**
   * Constructing the main class and adding action to init.
   */
  public function register() {

    // Loading text domain
    load_theme_textdomain('dreamhome', VTCORE_ZEUS_THEME_PATH . DIRECTORY_SEPARATOR . 'languages');

    global $revSliderAsTheme;
    $revSliderAsTheme = true;

    self::$theme = wp_get_theme();

    // Load autoloader
    $autoloader = new VTCore_Autoloader('VTCore_Zeus', dirname(__FILE__));
    $autoloader->setRemovePath('vtcore' . DIRECTORY_SEPARATOR . 'zeus' . DIRECTORY_SEPARATOR);
    $autoloader->register();


    // Registering theme supports
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links').
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list'));
    add_theme_support('title-tag');
    add_theme_support('vtcore_custom_template');
    add_theme_support('bootstrap');


    // Registering default menu location
    register_nav_menu('primary', __( 'Navigation Menu', 'dreamhome'));

    // Registering template, set this as early as possible so schema can alter it
    self::getFactory('template')
      ->register(VTCORE_ZEUS_THEME_PATH . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . 'wploop', 'templates' . DIRECTORY_SEPARATOR . 'wploop')
      ->register(VTCORE_ZEUS_THEME_PATH . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . 'custom', 'templates' . DIRECTORY_SEPARATOR . 'custom');

    // Setup the VTCore asset factory, set this as early as possible so schema can alter it
    self::getFactory('assets')
      ->get('library')
      ->detect(VTCORE_ZEUS_THEME_PATH . DIRECTORY_SEPARATOR . 'assets', get_template_directory_uri() . '/assets', false, 'VTCore_Zeus_Assets');

    // Detecting dynamic hooks
    $this->detectHooks();

    // Registering actions
    self::getFactory('actions')
      ->addPrefix('VTCore_Zeus_Actions_')
      ->addHooks($this->actions)
      ->register();


    // Registering filters
    self::getFactory('filters')
      ->addPrefix('VTCore_Zeus_Filters_')
      ->addHooks($this->filters)
      ->register();

    // Registering schemas
    self::setFactory('schemas', new VTCore_Zeus_Schema_Factory());
    self::getFactory('schemas')
      ->init()
      ->RegisterAssets()
      ->RegisterTemplates();

    // Registering config
    // Must be run after schemas initialized
    self::setFactory('features', new VTCore_Zeus_Config_Options());

    // Registering regions
    if (class_exists('VTCore_Wordpress_Factory_Layout', true)) {
      $areas = new VTCore_Zeus_Config_Areas();
      $regions = new VTCore_Zeus_Config_Regions();
      self::setFactory('layout', new VTCore_Wordpress_Factory_Layout(array(
        'areas' => $areas->extract(),
        'regions' => $regions->extract(),
      )));
    }


    // Booting visualComposer integration system
    if (function_exists('vc_set_as_theme')) {
      self::setFactory('vc', new VTCore_Zeus_VisualComposer_Init());
    }

    // Integrating with DSIDXpress Plugin
    if (defined('DSIDXPRESS_PLUGIN_VERSION')) {
      remove_filter("the_posts", array("dsSearchAgent_Client", "Activate"), 10);
      remove_filter("the_posts", array("dsIdxListingsPages", "DisplayPage"), 100);
    }

    // Registering Page Class Factory
    self::setFactory('page', new VTCore_Zeus_Factory_PageClass());

  }


  /**
   * Loading dynamically detected hooks
   */
  protected function detectHooks() {

    // @bugfix customizer keep nuking zeus panel when invoked in is_admin()
    if (is_customize_preview()) {
      $this->actions[] = 'customize_preview_init';
      $this->actions[] = 'customize_register';
      $this->actions[] = 'customize_save';
      $this->actions[] = 'wp_ajax_color_customizer';
    }

    if (is_admin()) {
      $this->actions[] = 'admin_menu';
    }

    if (VTCORE_VC_LOADED) {
      $this->actions[] = 'vc_before_init';
      $this->actions[] = 'vc_after_mapping';
      $this->filters[] = 'vc_load_default_templates';
      $this->filters[] = 'vc_grid_item_predefined_templates';
    }

    if (defined('VTCORE_HEADLINE_LOADED')) {
      $this->actions[] = 'vtcore_headline_add_configuration_panel';
      $this->filters[] = 'vtcore_headline_configuration_context_alter';
      $this->filters[] = 'vtcore_headline_context_alter';
      $this->filters[] = 'vtcore_headline_remove_metabox_tabs';
      $this->filters[] = 'vtcore_headline_alter';
      $this->filters[] = 'vtcore_headline_hide_metabox';
      $this->filters[] = 'vtcore_headline_metabox_form_alter';
    }

    if (defined('DSIDXPRESS_PLUGIN_VERSION')) {
      $this->filters[] = 'dw_instance_visibility';
      $this->filters[] = 'dw_pages_types_register';
    }

    if (defined('VTCORE_PROPERTY_LOADED')) {
      $this->filters[] = 'vtcore_property_config_alter';
    }

    if (defined('VTCORE_AGENTS_LOADED')) {
      $this->filters[] = 'vtcore_agents_template';
      $this->filters[] = 'vtcore_agents_config_alter';
    }

    return $this;
  }

  /**
   * Retrieving theme information
   */
  public static function getThemeInfo($key) {
    return self::$theme->get($key);
  }

}