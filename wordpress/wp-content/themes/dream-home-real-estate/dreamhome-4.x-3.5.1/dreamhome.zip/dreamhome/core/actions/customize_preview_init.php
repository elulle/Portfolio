<?php
/**
 * Class for filtering customize_controls_print_scripts
 * and adding extra class to it.
 *
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Actions_Customize__Preview__Init
extends VTCore_Wordpress_Models_Hook {

  public function hook() {
    VTCore_Wordpress_Utility::loadAsset('wp-gradientpicker');
    VTCore_Wordpress_Utility::loadAsset('jquery-deparam');
    VTCore_Wordpress_Utility::loadAsset('bootstrap-grids');
    VTCore_Wordpress_Utility::loadAsset('customizer');

    // Only handles Preview, actual saving is using customizer_save action.
    if (current_user_can('edit_theme_options')
        && isset($_POST['wp_customize'])
        && isset($_POST['customized'])
        && isset($_POST['theme'])
        && $_POST['wp_customize'] == 'on'
        && !empty($_POST['customized'])
        && $_POST['theme'] == ACTIVE_THEME) {

      $this->post = filter_input_array(INPUT_POST);
      $this->customized = (array) json_decode($this->post['customized']);

      $rebuild = false;
      foreach ($this->customized as $key => $value) {

        if ($value == '__i__') {
          continue;
        }

        if (strpos($key, 'features[') !== false) {
          $objectKeys = str_replace(array('[', ']'), array('.', ''), str_replace('features[', '', $key));
          VTCore_Zeus_Init::getFactory('features')->add($objectKeys, $value);
        }

        if (strpos($key, 'regions[') !== false) {
          $objectKeys = str_replace(array('regions[', '][', '[', ']'), array('', '.', '.', ''), $key);
          VTCore_Zeus_Init::getFactory('layout')->addContext('regions.' . $objectKeys, $value);
          $rebuild = true;
        }
      }

      if ($rebuild) {
        VTCore_Zeus_Init::getFactory('layout')->buildElement();
      }

    }

  }

}