<?php
/**
 * Class for filtering template from template_include filter
 *
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Filters_Template__Include
extends VTCore_Wordpress_Models_Hook {

  protected $weight = 12;

  public function hook($template = NULL) {

    global $wp_query;

    // Integration to dsidx plugin
    if (get_query_var('idx-action') == 'results' || isset($wp_query->query['ds-idx-listings-page'])) {
      if ($file = locate_template('dsidx-listing.php')) {
        $template = $file;
      }
    }

    if (get_query_var('idx-action') == 'details') {
      if ($file = locate_template('dsidx-page.php')) {
        $template = $file;
      }
    }

    // Bug fix schema overriden templates never got called
    $maybeTemplate = VTCore_Wordpress_Init::getFactory('template')->locate($template);
    if (!empty($maybeTemplate) && file_exists($maybeTemplate)) {
      $template = $maybeTemplate;
    }

    return $template;
  }
}