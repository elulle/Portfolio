<?php
/**
 * Class for filtering the_posts
 * posts array of objects.
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Filters_The__Posts
extends VTCore_Wordpress_Models_Hook {

  protected $argument = 2;

  public function hook($posts = NULL, $query = NULL) {

    // Fixing dsidxpress breaking all other plugin loops
    if (defined('DSIDXPRESS_PLUGIN_VERSION') && !is_admin()) {

      // Idx give empty post on single page
      if (isset($query->query['idx-action']) || isset($query->query['ds-idx-listings-page'])) {
        $posts = dsSearchAgent_Client::Activate($posts);
        //$posts = dsIdxListingsPages::DisplayPage($posts);

        add_filter('the_posts', array($this, 'DisplayPage'), 100, 2);
      }

    }

    return $posts;
  }


  public function DisplayPage($posts, $query) {
    if (isset($query->query['idx-action']) || isset($query->query['ds-idx-listings-page'])) {
      $posts = dsIdxListingsPages::DisplayPage($posts);
    }

    return $posts;
  }
}

