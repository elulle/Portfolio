<?php
/**
 * Class for altering the menu object before processed as markup.
 * This relies on the dropdown nav walker, wont work with normal
 * wordpress walker.
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Filters_Wp__Nav__Menu__Objects
extends VTCore_Wordpress_Models_Hook {

  protected $argument = 2;
  protected $weight = 10;

  public function hook($items = NULL, $args = NULL) {

    // Split the top level menu
    if (isset($args->split_to) && isset($args->split_number)) {

      $array = array();
      foreach ($items as $delta => $post) {
        if (empty($post->menu_item_parent)) {
          $array[$delta] = $post;
        }
      }

      $total = count($array);
      $max = ceil($total / $args->split_to);
      $offset = $args->split_number * $max;
      $array = array_slice($array, $offset, $max, true);

      foreach ($items as $delta => $post) {
        $items[$delta]->force_remove = false;
        if (empty($post->menu_item_parent)
            && !isset($array[$delta])) {
          $items[$delta]->force_remove = true;
        }
      }
    }

    return $items;
  }
}