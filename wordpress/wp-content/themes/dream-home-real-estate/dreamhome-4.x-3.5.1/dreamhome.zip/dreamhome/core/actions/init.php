<?php
/**
 * Class for hooking to init action
 * and adding extra class to it.
 *
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Actions_Init
extends VTCore_Wordpress_Models_Hook {

  public function hook() {

    // Old version will use constant, move it to theme_support
    if (defined('VTCORE_PROPERTY_CUSTOM_CONTENT')) {
      add_theme_support('vtcore_property_template', VTCORE_PROPERTY_CUSTOM_CONTENT);
    }

    // Compatibility with old version routing
    if (get_theme_support('vtcore_property_template')) {
      VTCore_Wordpress_Init::getFactory('propertyConfig')
        ->add('routing.single.mode', 'default')
        ->add('routing.archive.mode', 'default');
    }

    // Adding Logo image size
    add_image_size(
      'logo',
      VTCore_Zeus_Init::getFactory('features')->get('options.logo.width'),
      VTCore_Zeus_Init::getFactory('features')->get('options.logo.height'),
      false
    );

  }
}