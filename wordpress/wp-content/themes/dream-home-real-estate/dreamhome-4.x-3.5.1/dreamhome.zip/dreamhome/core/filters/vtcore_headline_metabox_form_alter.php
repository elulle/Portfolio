<?php
/**
 * Hooking into VTCore Headline plugin to alter the metabox form
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Filters_VTCore__Headline__Metabox__Form__Alter
extends VTCore_Wordpress_Models_Hook {

  protected static $unique = 0;

  public function hook($form = NULL) {


    if (is_a($form, 'VTCore_Headline_Metabox_Items')) {

      if (!$form->getContext('ajax-delta')) {
        $form->addContext('ajax-delta', self::$unique);
      }

      $object = new VTCore_Bootstrap_Element_BsElement(array(
        'type' => 'div',
        'header' => $form->getContext('header'),
        'attributes' => array(
          'id' => 'ajax-target-items-' . $form->getContext('ajax-delta'),
        ),
      ));

      if ($form->getContext('general.template') == 'carousel') {
        $remove = $form->findChildren('objectType', 'VTCore_Fontawesome_Form_Base');
        foreach($remove as $child) {
          $child->getParent()->removeChildren($child->getMachineID());
        }

        $remove = $form->findChildren('text', array(__('Icon Color', 'victheme_headline'), __('Icon Background', 'victheme_headline')));
        foreach($remove as $child) {
          $child->getParent()->getParent()->getParent()->removeChildren($child->getParent()->getParent()->getMachineID());
        }

        $remove = $form->findChildren('text', array(__('Headline Items', 'victheme_headline')));
        foreach ($remove as $child) {
          $child->setText(__('Slider Items', 'dreamhome'));
        }

        $remove = $form->findChildren('objectType', array('VTCore_Bootstrap_Form_BsDescription'));
        foreach ($remove as $child) {
          $child->setText(__('Set the slider items for the carousel', 'dreamhome'));
        }
      }
      else {
        $form->resetChildren();
        $form->addChildren(new VTCore_Bootstrap_Form_BsDescription(array(
          'text' => __('Selected template is not capable to display items', 'dreamhome'),
        )));
      }

      $object->addChildren($form);

      $form = $object;
      unset($object);
    }

    // Altering metabox items forms
    if (is_a($form, 'VTCore_Headline_Metabox_General')) {

      VTCore_Wordpress_Utility::loadAsset('wp-ajax');

      self::$unique++;

      if (!$form->getContext('ajax-delta')) {
        $form->addContext('ajax-delta', self::$unique);
      }

      // Adding the additional title, subtitle and icon config
      $form
        ->BsRow()
        ->lastChild()
        ->BsColumn(array(
          'grids' => array(
            'columns' => array(
              'mobile' => 12,
              'tablet'=> 4,
              'small' => 4,
              'large' => 4,
            ),
          ),
        ))
        ->lastChild()
        ->BsHeader(array(
          'tag' => 'h3',
          'text' => __('Headline Template', 'dreamhome'),
        ))
        ->BsDescription(array(
          'text' => __('Configure the headline headline template to be used to format the headline output display.', 'dreamhome'),
        ))
        ->getParent()
        ->BsColumn(array(
          'grids' => array(
            'columns' => array(
              'mobile' => 12,
              'tablet'=> 8,
              'small' => 8,
              'large' => 8,
            ),
          ),
        ))
        ->lastChild()
        ->BsRow()
        ->lastChild()
        ->BsSelect(array(
          'text' => __('Template', 'dreamhome'),
          'name' => $form->getContext('prefix') . '[general][template]',
          'value' => $form->getContext('general.template'),
          'options' => array(
            'default' => __('Default', 'dreamhome'),
            'fullscreen' => __('Full Screen', 'dreamhome'),
            'simple' => __('Corporate', 'dreamhome'),
            'carousel' => __('Carousel', 'dreamhome'),
            'clean' => __('Clean', 'dreamhome'),
          ),
          'grids' => array(
            'columns' => array(
              'mobile' => 12,
              'tablet'=> 6,
              'small' => 6,
              'large' => 6,
            ),
          ),
          'input_elements' => array(
            'attributes' => array(
              'class' => array('btn-ajax-change'),
            ),
            'data' => array(
              'nonce' => wp_create_nonce('vtcore-ajax-nonce-admin'),
              'ajax-mode' => 'change',
              'ajax-target' => $form->getContext('ajax-delta'),
              'ajax-loading-text' => __('Changing Headline Template', 'dreamhome'),
              'ajax-object' => 'VTCore_Zeus_Ajax_Headline',
              'ajax-action' => 'vtcore_ajax_framework',
              'ajax-value' => base64_encode(serialize($form->getContexts())),
              'ajax-queue' => array(
                'change-template'
              ),
            ),
          ),
        ))
        ->BsSelect(array(
          'text' => __('Position', 'dreamhome'),
          'name' => $form->getContext('prefix') . '[general][position]',
          'value' => $form->getContext('general.position'),
          'options' => array(
            'top' => __('Above header', 'dreamhome'),
            'bottom' => __('Below header', 'dreamhome'),
          ),
          'grids' => array(
            'columns' => array(
              'mobile' => 12,
              'tablet'=> 6,
              'small' => 6,
              'large' => 6,
            ),
          ),
        ));


      if ($form->getContext('general.template') == 'carousel') {
        $remove = $form->findChildren('context', 'group', array('title', 'subtitle'));
        foreach ($remove as $child) {
          $child->getParent()->removeChildren($child->getMachineID());
        }
      }

      $object = new VTCore_Bootstrap_Element_BsElement(array(
        'type' => 'div',
        'header' => $form->getContext('header'),
        'attributes' => array(
          'id' => 'ajax-target-general-' . $form->getContext('ajax-delta'),
        ),
      ));

      $object->addChildren($form);
      $form = $object;
      unset($object);
    }

    // Remove
    return $form;
  }
}