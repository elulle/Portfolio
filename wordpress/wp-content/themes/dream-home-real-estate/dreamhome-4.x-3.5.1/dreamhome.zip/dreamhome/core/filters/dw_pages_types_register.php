<?php
/**
 * Hooking into display suite for adding
 * extra options and visibility checking
 * for agents related pages
 *
 * @author jason.xie@victheme.com
 */
class VTCore_Zeus_Filters_DW__Pages__Types__Register
extends VTCore_Wordpress_Models_Hook {

  public function hook($types = NULL) {

    // Dsidxpress plugin integration to display widget
    if (defined('DSIDXPRESS_PLUGIN_VERSION')) {
      $types['dsidx-details'] = __('Dsidxpress Page', 'dreamhome');
      $types['dsidx-results'] = __('Dsidxpress Listings', 'dreamhome');
    }

    return $types;
  }
}