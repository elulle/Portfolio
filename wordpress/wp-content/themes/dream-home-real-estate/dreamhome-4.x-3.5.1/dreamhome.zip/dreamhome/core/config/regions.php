<?php
/**
 * Configuration for the theme regions
 *
 * @author jason.xie@victheme.com
 * @see VTCore_Wordpress_Layout_Region
 *
 */
class VTCore_Zeus_Config_Regions
extends VTCore_Wordpress_Models_Config {

  protected $database = 'regions';
  protected $filter = 'vtcore_zeus_regions_context_alter';
  protected $loadFunction = 'get_theme_mod';
  protected $savefunction = 'set_theme_mod';
  protected $deleteFunction = 'remove_theme_mod';

  public function register(array $options) {

    // Set theme default regions
    $this->options = array(

      // Always put sidebar on top of the array
      // simply because Wordpress is not smart enough
      // to assign default widget to proper region
      // when theme is initialized at the first time.
      'sidebar' => array(
        'parent' => 'maincontent',
        'mode' => 'dynamic',
        'weight' => 1,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '4',
            'small' => '4',
            'large' => '4',
          ),
        ),
        'arguments' => array(
          'name' => __('Sidebar', 'dreamhome'),
          'id' => 'sidebar',
          'description' => __('This region can be repositioned from left to right using the theme configurations.', 'dreamhome'),
          //'before_widget' => '<div id="%1$s" class="widget col-xs-6 col-sm-6 col-md-12 col-lg-12 %2$s">',
          'before_title'  => '<h2 class="widgettitle">',
        ),
      ),

      'top_left' => array(
        'parent' => 'top',
        'mode' => 'dynamic',
        'weight' => 0,
        'grids' => array(
          'columns' => array(
            'mobile' => '0',
            'tablet' => '5',
            'small' => '4',
            'large' => '4',
          ),
        ),
        'arguments' => array(
          'name' => __('Top Header Left', 'dreamhome'),
          'id' => 'top_left',
          'description' => __('Top header left region at the top of header', 'dreamhome'),
        ),
      ),

      'top_right' => array(
        'parent' => 'top',
        'mode' => 'dynamic',
        'weight' => 1,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '7',
            'small' => '8',
            'large' => '8',
          ),
        ),
        'arguments' => array(
          'name' => __('Top Header Right', 'dreamhome'),
          'id' => 'top_right',
          'description' => __('Top header right region at the top of header', 'dreamhome'),
        ),
      ),

      'header_left' => array(
        'parent' => 'header',
        'mode' => 'dynamic',
        'weight' => 0,
        'grids' => array(
          'columns' => array(
            'mobile' => '4',
            'tablet' => '4',
            'small' => '3',
            'large' => '3',
          ),
        ),
        'arguments' => array(
          'name' => __('Header Left', 'dreamhome'),
          'id' => 'header_left',
          'description' => __('Header left region at the header area for dynamic widget', 'dreamhome'),
        ),
      ),

      'logo' => array(
        'parent' => 'header',
        'mode' => 'static',
        'weight' => 1,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '4',
            'small' => '4',
            'large' => '4',
          ),
        ),
        'arguments' => array(
          'name' => __('Logo', 'dreamhome'),
          'id' => 'logo',
          'description' => __('A Static region for building logo element in the header', 'dreamhome'),
        ),
      ),
      'navigation' => array(
        'parent' => 'header',
        'mode' => 'static',
        'weight' => 2,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '8',
            'small' => '8',
            'large' => '8',
          ),
        ),
        'arguments' => array(
          'name' => __('Navigation', 'dreamhome'),
          'id' => 'navigation',
          'description' => __('A Static region for building main navigation element in the header', 'dreamhome'),
        ),
      ),

      'header_right' => array(
        'parent' => 'header',
        'mode' => 'dynamic',
        'weight' => 3,
        'grids' => array(
          'columns' => array(
            'mobile' => '4',
            'tablet' => '4',
            'small' => '3',
            'large' => '3',
          ),
        ),
        'arguments' => array(
          'name' => __('Header Right', 'dreamhome'),
          'id' => 'header_right',
          'description' => __('Header right region at the header area for dynamic widget', 'dreamhome'),
        ),
      ),
      'prefaceone' => array(
        'parent' => 'preface',
        'mode' => 'dynamic',
        'weight' => 0,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '12',
            'small' => '12',
            'large' => '12',
          ),
        ),
        'arguments' => array(
          'name' => __('Pre Face One', 'dreamhome'),
          'id' => 'prefaceone',
          'description' => __('Pre face region after the headline', 'dreamhome'),
          'before_title'  => '<h2 class="widgettitle text-underline">',
          'after_title' => '</h2><span class="separator"></span>',
        ),
      ),
      'prefacetwo' => array(
        'parent' => 'preface',
        'mode' => 'dynamic',
        'weight' => 1,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '6',
            'small' => '6',
            'large' => '6',
          ),
        ),
        'arguments' => array(
          'name' => __('Pre Face Two', 'dreamhome'),
          'id' => 'prefacetwo',
          'description' => __('Pre face region after the headline', 'dreamhome'),
          'before_title'  => '<h2 class="widgettitle text-underline">',
          'after_title' => '</h2><span class="separator"></span>',
        ),
      ),
      'prefacethree' => array(
        'parent' => 'preface',
        'mode' => 'dynamic',
        'weight' => 2,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '6',
            'small' => '6',
            'large' => '6',
          ),
        ),
        'arguments' => array(
          'name' => __('Pre Face Three', 'dreamhome'),
          'id' => 'prefacethree',
          'description' => __('Pre face region after the headline', 'dreamhome'),
          'before_title'  => '<h2 class="widgettitle text-underline">',
          'after_title' => '</h2><span class="separator"></span>',
        ),
      ),
      'slider' => array(
        'parent' => 'slider',
        'mode' => 'dynamic',
        'weight' => 0,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '12',
            'small' => '12',
            'large' => '12',
          ),
        ),
        'arguments' => array(
          'name' => __('Slider', 'dreamhome'),
          'id' => 'slider',
          'description' => __('Slider Region on top of the main content, suitable for slider elements.', 'dreamhome'),
        ),
      ),
      'content_top' => array(
        'parent' => 'content_top',
        'mode' => 'dynamic',
        'weight' => 0,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '12',
            'small' => '12',
            'large' => '12',
          ),
        ),
        'arguments' => array(
          'name' => __('Content Top', 'dreamhome'),
          'id' => 'content_top',
          'description' => __('A Dynamic region above the content section', 'dreamhome'),
        ),
      ),
      'content' => array(
        'parent' => 'maincontent',
        'mode' => 'static',
        'weight' => 0,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '8',
            'small' => '8',
            'large' => '8',
          ),
        ),
        'arguments' => array(
          'name' => __('Content', 'dreamhome'),
          'id' => 'content',
          'description' => __('A Static region for building content element in the main content', 'dreamhome'),
        ),
      ),
      'content_bottom' => array(
        'parent' => 'content_bottom',
        'mode' => 'dynamic',
        'weight' => 0,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '12',
            'small' => '12',
            'large' => '12',
          ),
        ),
        'arguments' => array(
          'name' => __('Content Bottom', 'dreamhome'),
          'id' => 'content_bottom',
          'description' => __('A Dynamic region underneath the content section', 'dreamhome'),
        ),
      ),
      'postfaceone' => array(
        'parent' => 'postface',
        'mode' => 'dynamic',
        'weight' => 0,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '4',
            'small' => '4',
            'large' => '4',
          ),
        ),
        'arguments' => array(
          'name' => __('Post Face One', 'dreamhome'),
          'id' => 'postfaceone',
          'description' => __('Post face region one before the footer', 'dreamhome'),
        ),
      ),
      'postfacetwo' => array(
        'parent' => 'postface',
        'mode' => 'dynamic',
        'weight' => 1,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '4',
            'small' => '4',
            'large' => '4',
          ),
        ),
        'arguments' => array(
          'name' => __('Post Face Two', 'dreamhome'),
          'id' => 'postfacetwo',
          'description' => __('Post face region two before the footer', 'dreamhome'),
        ),
      ),
      'postfacethree' => array(
        'parent' => 'postface',
        'mode' => 'dynamic',
        'weight' => 2,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '4',
            'small' => '4',
            'large' => '4',
          ),
        ),
        'arguments' => array(
          'name' => __('Post Face Three', 'dreamhome'),
          'id' => 'postfacethree',
          'description' => __('Post face region three before the footer', 'dreamhome'),
        ),
      ),
      'footerone' => array(
        'parent' => 'footer',
        'mode' => 'dynamic',
        'weight' => 0,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '4',
            'small' => '4',
            'large' => '4',
          ),
        ),
        'arguments' => array(
          'name' => __('Footer One', 'dreamhome'),
          'id' => 'footerone',
          'description' => __('First footer region, located on the left side of the footer.', 'dreamhome'),
        ),
      ),
      'footertwo' => array(
        'parent' => 'footer',
        'mode' => 'dynamic',
        'weight' => 1,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '8',
            'small' => '8',
            'large' => '8',
          ),
        ),
        'arguments' => array(
          'name' => __('Footer Two', 'dreamhome'),
          'id' => 'footertwo',
          'description' => __('Second footer region, located after the footer one region.', 'dreamhome'),
        ),
      ),
      'footerthree' => array(
        'parent' => 'footer',
        'mode' => 'dynamic',
        'weight' => 2,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '6',
            'small' => '6',
            'large' => '6',
          ),
        ),
        'arguments' => array(
          'name' => __('Footer Three', 'dreamhome'),
          'id' => 'footerthree',
          'description' => __('Third footer region, located after the footer two region.', 'dreamhome'),
        ),
      ),
      'footerfour' => array(
        'parent' => 'footer',
        'mode' => 'dynamic',
        'weight' => 3,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '6',
            'small' => '6',
            'large' => '6',
          ),
        ),
        'arguments' => array(
          'name' => __('Footer Four', 'dreamhome'),
          'id' => 'footerfour',
          'description' => __('Fourth footer region, located after the footer two region.', 'dreamhome'),
        ),
      ),
      'copyright' => array(
        'parent' => 'fullfooter',
        'mode' => 'static',
        'weight' => 0,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '12',
            'small' => '12',
            'large' => '12',
          ),
        ),
        'arguments' => array(
          'name' => __('Copyright', 'dreamhome'),
          'id' => 'copyright',
          'description' => __('Full footer copyright notice.', 'dreamhome'),
        ),
      ),
      'offcanvas' => array(
        'parent' => 'offcanvas',
        'mode' => 'dynamic',
        'weight' => 1,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '12',
            'small' => '12',
            'large' => '12',
          ),
        ),
        'arguments' => array(
          'name' => __('Off Canvas', 'dreamhome'),
          'id' => 'offcanvas',
          'description' => __('OffCanvas region', 'dreamhome'),
        ),
      ),
    );

    // Sizing the header dynamically.
    $this->dynamicHeaderSize();

    // Regions special for headline
    if (defined('VTCORE_HEADLINE_LOADED')) {
      $this->options['headline'] = array(
        'parent' => 'headline',
        'mode' => 'dynamic',
        'weight' => 1,
        'grids' => array(
          'columns' => array(
            'mobile' => '12',
            'tablet' => '12',
            'small' => '12',
            'large' => '12',
          ),
        ),
        'arguments' => array(
          'name' => __('Headline', 'dreamhome'),
          'id' => 'headline',
          'description' => __('This region is placed in the headline block area.', 'dreamhome'),
          'before_title'  => '<h2 class="widgettitle">',
        ),
      );

    }



    // Merge the user supplied options
    $this->merge($options);

    // Apply the hookable filter
    $this->filter();

    // Inject from database
    $this->load();

    // Backward compatibility
    do_action('vtcore_zeus_alter_regions', $this);

    return $this;
  }


  /**
   * Method for dynamically change the header regions grid
   * size based on what kind of header did user or schema chooses.
   *
   * @return $this
   */
  protected function dynamicHeaderSize() {
    $slick = VTCore_Zeus_Init::getFactory('features')->get('options.menu.enable_slick');
    switch (VTCore_Zeus_Init::getFactory('features')->get('options.header.template')) {

      case 'one' :
        $this
          ->mutate('logo.grids', array(
            'columns' => array(
              'mobile' => $slick ? 10 : 12,
              'tablet' => 4,
              'small' => 4,
              'large' => 4,
            ),
          ))
          ->mutate('navigation.grids', array(
            'columns' => array(
              'mobile' => $slick ? 0 : 12,
              'tablet' => 8,
              'small' => 8,
              'large' => 8,
            ),
          ));

        break;

      case 'two' :
        $this
          ->mutate('logo.grids', array(
            'columns' => array(
              'mobile' => $slick ? 10 : 12,
              'tablet' => 3,
              'small' => 3,
              'large' => 3,
            ),
          ))
          ->mutate('navigation.grids', array(
            'columns' => array(
              'mobile' => $slick ? 0 : 6,
              'tablet' => 6,
              'small' => 6,
              'large' => 6,
            ),
          ))
          ->mutate('header_right.grids', array(
            'columns' => array(
              'mobile' => $slick ? 12 : 6,
              'tablet' => 3,
              'small' => 3,
              'large' => 3,
            ),
          ));

        break;

      case 'three' :
        $this
          ->mutate('logo.grids', array(
            'columns' => array(
              'mobile' => 12,
              'tablet' => 12,
              'small' => 12,
              'large' => 12,
            ),
          ))
          ->mutate('header_left.grids', array(
            'columns' => array(
              'mobile' => $slick ? 6 : 12,
              'tablet' => 3,
              'small' => 3,
              'large' => 3,
            ),
          ))
          ->mutate('navigation.grids', array(
            'columns' => array(
              'mobile' => $slick ? 0 : 12,
              'tablet' => 6,
              'small' => 6,
              'large' => 6,
            ),
          ))
          ->mutate('header_right.grids', array(
            'columns' => array(
              'mobile' => $slick ? 6 : 12,
              'tablet' => 3,
              'small' => 3,
              'large' => 3,
            ),
          ));

        break;

      case 'four' :
        $this
          ->mutate('header_left.grids', array(
            'columns' => array(
              'mobile' => 0,
              'tablet' => 2,
              'small' => 2,
              'large' => 2,
            ),
          ))
          ->mutate('navigation.grids', array(
            'columns' => array(
              'mobile' => 12,
              'tablet' => 8,
              'small' => 8,
              'large' => 8,
            ),
          ))
          ->mutate('header_right.grids', array(
            'columns' => array(
              'mobile' => 0,
              'tablet' => 2,
              'small' => 2,
              'large' => 2,
            ),
          ));

        break;

      case 'five' :
        $this
          ->mutate('header_left.grids', array(
            'columns' => array(
              'mobile' => $slick ? 6 : 12,
              'tablet' => 3,
              'small' => 3,
              'large' => 3,
            ),
          ))
          ->mutate('navigation.grids', array(
            'columns' => array(
              'mobile' => $slick ? 0 : 12,
              'tablet' => 6,
              'small' => 6,
              'large' => 6,
            ),
          ))
          ->mutate('header_right.grids', array(
            'columns' => array(
              'mobile' => $slick ? 6 : 12,
              'tablet' => 3,
              'small' => 3,
              'large' => 3,
            ),
          ));

        break;

    }

    return $this;

  }
}