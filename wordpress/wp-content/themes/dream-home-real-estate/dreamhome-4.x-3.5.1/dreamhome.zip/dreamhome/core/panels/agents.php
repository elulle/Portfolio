<?php
/**
 * Panel section for configuring general options
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Panels_Agents
extends VTCore_Zeus_Panels_Model {

  /**
   * Overriding parent method
   * @see VTCore_Bootstrap_Element_BsElement::buildElement()
   */
  public function buildElement() {


    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Profile Page', 'dreamhome'),
      'id' => 'vtcore-zeus-agents-page-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' =>  __('This setting will be applied to the agents profile page', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_profile][content]',
        'text' => __('Show Content', 'dreamhome'),
        'description' => __('Show / hide the agents content.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_profile', 'content'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_profile][photo]',
        'text' => __('Show Photo', 'dreamhome'),
        'description' => __('Show / hide the agents photo.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_profile', 'photo'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_profile][info]',
        'text' => __('Show Info', 'dreamhome'),
        'description' => __('Show / hide the agents info box.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_profile', 'info'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_profile][listing]',
        'text' => __('Show Listing', 'dreamhome'),
        'description' => __('Show / hide the agents property listing box.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_profile', 'listing'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));


    if (defined('WPCF7_VERSION')) {
      $this->panel
        ->lastChild()
        ->BsCheckbox(array(
          'name' => 'theme[features][show][agents_profile][contact]',
          'text' => __('Show Contact', 'dreamhome'),
          'description' => __('Show / hide the agents contact form.', 'dreamhome'),
          'checked' => (boolean) $this->getShow('agents_profile', 'contact'),
          'switch' => true,
          'grids' => array(
            'columns' => array(
              'mobile' => 12,
              'tablet' => 6,
              'small' => 6,
              'large' => 6,
            ),
          ),
        ));
    }

    if (defined('VTCORE_MAPS_LOADED')) {
      $this->panel
        ->lastChild()
        ->BsCheckbox(array(
          'name' => 'theme[features][show][agents_profile][maps]',
          'text' => __('Show Maps', 'dreamhome'),
          'description' => __('Show / hide the agents maps.', 'dreamhome'),
          'checked' => (boolean) $this->getShow('agents_profile', 'maps'),
          'switch' => true,
          'grids' => array(
            'columns' => array(
              'mobile' => 12,
              'tablet' => 6,
              'small' => 6,
              'large' => 6,
            ),
          ),
        ));
    }

    $this->panel
      ->BsText(array(
        'text' => __('Title', 'dreamhome'),
        'name' => 'theme[features][options][agents_profile][title]',
        'description' => __('Define agents profile page title', 'dreamhome'),
        'value' => $this->getOption('agents_profile', 'title'),
      ))
      ->BsTextarea(array(
        'text' => __('Description', 'dreamhome'),
        'name' => 'theme[features][options][agents_profile][description]',
        'description' => __('Define agents profile page description text', 'dreamhome'),
        'value' => $this->getOption('agents_profile', 'description'),
      ))
      ->BsNumber(array(
        'text' => __('Number Of Property', 'dreamhome'),
        'description' => __('Define how many property should be displayed in the agents profile page.', 'dreamhome'),
        'name' => 'theme[features][options][agents_profile][listing]',
        'value' => $this->getOption('agents_profile', 'listing'),
        'min' => 0,
        'step' => 1,
      ));

    $this->processPanel();


    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Teaser List', 'dreamhome'),
      'id' => 'vtcore-zeus-agents-teaser-list-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' => __('The agents listing element settings will be applied to the agents teaser element in the agents listing page on list mode', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_list][photo]',
        'text' => __('Show Photo', 'dreamhome'),
        'description' => __('Show / hide the agents photo.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_list', 'photo'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_list][name]',
        'text' => __('Show Name', 'dreamhome'),
        'description' => __('Show / hide the agents name.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_list', 'name'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_list][location]',
        'text' => __('Show Location', 'dreamhome'),
        'description' => __('Show / hide the agents location.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_list', 'location'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_list][info]',
        'text' => __('Show Info', 'dreamhome'),
        'description' => __('Show / hide the agents information box.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_list', 'info'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_list][social]',
        'text' => __('Show Social', 'dreamhome'),
        'description' => __('Show / hide the agents social.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_list', 'social'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_list][bio]',
        'text' => __('Show Biography', 'dreamhome'),
        'description' => __('Show / hide the agents biography.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_list', 'bio'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_list][readmore]',
        'text' => __('Show Readmore', 'dreamhome'),
        'description' => __('Show / hide the agents readmore.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_list', 'readmore'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));


    $this->processPanel();


    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Teaser Grid', 'dreamhome'),
      'id' => 'vtcore-zeus-agents-teaser-grid-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' => __('The agents listing element settings will be applied to the agents teaser element in the agents listing page on grid mode', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_grid][photo]',
        'text' => __('Show Photo', 'dreamhome'),
        'description' => __('Show / hide the agents photo.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_grid', 'photo'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_grid][name]',
        'text' => __('Show Name', 'dreamhome'),
        'description' => __('Show / hide the agents name.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_grid', 'name'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_grid][location]',
        'text' => __('Show Location', 'dreamhome'),
        'description' => __('Show / hide the agents location.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_grid', 'location'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_grid][info]',
        'text' => __('Show Info', 'dreamhome'),
        'description' => __('Show / hide the agents information box.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_grid', 'info'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_grid][social]',
        'text' => __('Show Social', 'dreamhome'),
        'description' => __('Show / hide the agents social.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_grid', 'social'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_grid][bio]',
        'text' => __('Show Biography', 'dreamhome'),
        'description' => __('Show / hide the agents biography.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_grid', 'bio'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][agents_listing_grid][readmore]',
        'text' => __('Show Readmore', 'dreamhome'),
        'description' => __('Show / hide the agents readmore.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('agents_listing_grid', 'readmore'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));

    $this->processPanel();
  }

}