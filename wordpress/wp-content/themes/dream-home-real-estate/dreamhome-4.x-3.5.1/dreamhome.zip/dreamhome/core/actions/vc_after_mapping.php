<?php
/**
 * Hooking to vc_after_mapping hooks
 * for injecting additional visual
 * composer maps.
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Actions_VC__After__Mapping
extends VTCore_Wordpress_Models_Hook {

  public function hook() {
    VTCore_Zeus_Init::getFactory('vc')->addParams();
    VTCore_Zeus_Init::getFactory('vc')->alterParams();
  }
}