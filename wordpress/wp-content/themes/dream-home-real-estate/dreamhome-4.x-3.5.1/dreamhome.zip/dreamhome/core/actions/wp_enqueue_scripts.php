<?php
/**
 * Class for invoking wp_enqueue_scripts action
 * in a single place.
 *
 * This is done this way so themer can easily
 * queue scripts and styles.
 *
 * The ordering of calling loadAsset or wp_enqueue_script
 * will also reorder the queueing of the particular styles
 * providing no other plugin or modules altering the queue
 * after this class.
 *
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Actions_Wp__Enqueue__Scripts
extends VTCore_Wordpress_Models_Hook {

  public function hook() {

    // Core scripts, cannot be disabled!
    $enqueueArgs = array(
      'deps' => 'jquery',
      'footer' => true,
    );

    VTCore_Wordpress_init::getFactory('assets')
      ->get('queues')
      ->add('jquery-aspect-ratio', $enqueueArgs)
      ->add('bootstrap', $enqueueArgs)
      ->add('font-awesome', $enqueueArgs)
      ->add('jquery-resizeend', $enqueueArgs)
      ->add('jquery-totop', $enqueueArgs)
      ->add('jquery-viewport', $enqueueArgs)
      ->add('jquery-verticalcenter', $enqueueArgs)
      ->add('css-animation', $enqueueArgs)
      ->add('jquery-smoothscroll', $enqueueArgs)
      ->add('jquery-isotope', $enqueueArgs);

    // Load animsition
    if (VTCore_Zeus_Init::getFactory('features')->get('options.animsition.enable')) {
      VTCore_Wordpress_init::getFactory('assets')
        ->get('queues')
        ->add('jquery-animsition', $enqueueArgs);
    }

    // Only load offcanvas jvette element if enabled
    if (VTCore_Zeus_Init::getFactory('features')->get('options.offcanvas.enable')) {
      VTCore_Wordpress_init::getFactory('assets')
        ->get('queues')
        ->add('jquery-jvette', $enqueueArgs);

      // Remove the jvette css and use theme one instead
      VTCore_Wordpress_init::getFactory('assets')
        ->get('library')
        ->remove('jquery-jvette.css.jvette-css');
    }

    // Only load sticky header assets if enabled
    if (VTCore_Zeus_Init::getFactory('features')->get('options.menu.enable_sticky')) {
      VTCore_Wordpress_init::getFactory('assets')
        ->get('queues')
        ->add('jquery-hcsticky', $enqueueArgs);
    }

    // Only load slicknav assets if enabled
    if (VTCore_Zeus_Init::getFactory('features')->get('options.menu.enable_slick')) {
      VTCore_Wordpress_init::getFactory('assets')
        ->get('queues')
        ->add('jquery-slicknav', $enqueueArgs);
    }

    // Only load jvfloat assets if enabled
    if (VTCore_Zeus_Init::getFactory('features')->get('options.form.jvfloat')) {
      VTCore_Wordpress_init::getFactory('assets')
        ->get('queues')
        ->add('jquery-jvfloat', $enqueueArgs);
    }

    // Only load nicescroll assets if enabled
    if (VTCore_Zeus_Init::getFactory('features')->get('options.nicescroll.enable')) {
      VTCore_Wordpress_init::getFactory('assets')
        ->get('queues')
        ->add('jquery-nicescroll', $enqueueArgs);
    }

    // Don't Proceed any further if no VicTheme Headline plugin is enabled.
    if (defined('VTCORE_HEADLINE_LOADED')) {

      VTCore_Wordpress_init::getFactory('assets')
        ->get('queues')
        ->add('jquery-videobg', $enqueueArgs)
        ->add('headline-front', $enqueueArgs);

      // @bugfix headline instance broken due to global $template is not populated yet.
      VTCore_Headline_Utility::clearCache();
      $instance = VTCore_Headline_Utility::getHeadline();

      if (VTCore_Headline_Utility::checkEnabled('general', $instance)) {
        VTCore_Wordpress_Init::getFactory('assets')
          ->get('library')
          ->add('theme.css.style-css.dynamic.headline', VTCore_Headline_Utility::getMaskingCSS($instance) . VTCore_Headline_Utility::getBackgroundCSS($instance));
      }
    }


    // Load the controller javascript and main theme css
    VTCore_Wordpress_init::getFactory('assets')
      ->get('queues')
      ->add('theme', $enqueueArgs);

    // Load visual composer additional asset
    if (defined('VTCORE_VC_LOADED') && VTCORE_VC_LOADED) {
      VTCore_Wordpress_init::getFactory('assets')
        ->get('queues')
        ->add('vc-front', $enqueueArgs);
    }

    // Load revolution slider additional asset
    if (defined('VTCORE_REVSLIDER_LOADED') && VTCORE_REVSLIDER_LOADED) {
      VTCore_Wordpress_init::getFactory('assets')
        ->get('queues')
        ->add('revslider-front', $enqueueArgs);
    }

    // Load woocommerce assets
    if (defined('VTCORE_WOOCOMMERCE_LOADED') && VTCORE_WOOCOMMERCE_LOADED) {
      VTCore_Wordpress_init::getFactory('assets')
        ->get('queues')
        ->add('woocommerce-front', $enqueueArgs);
    }

    // Load property assets
    if (defined('VTCORE_PROPERTY_LOADED')) {
      VTCore_Wordpress_init::getFactory('assets')
        ->get('queues')
        ->add('property-front', $enqueueArgs);
    }

    // Load agents assets
    if (defined('VTCORE_AGENTS_LOADED')) {
      VTCore_Wordpress_init::getFactory('assets')
        ->get('queues')
        ->add('agents-front', $enqueueArgs);
    }

    if (VTCORE_DSIDX_LOADED) {
      VTCore_Wordpress_Utility::loadAsset('theme-dsidx');
    }


    // Load the active schema extra css
    VTCore_Wordpress_init::getFactory('assets')
      ->get('queues')
      ->add(VTCore_Zeus_Init::getFactory('schemas')->getActiveSchemaID(), $enqueueArgs);

    VTCore_Wordpress_Init::getFactory('assets')
      ->get('library')

      // Nuke default bootstrap styling
      ->remove('bootstrap.css.bootstrap-theme-css')

      // Note: the style name must be any previously registered css!
      // Load the dynamic style last to override other CSS.
      ->add('theme.css.style-css.dynamic.schema', VTCore_Zeus_Init::getFactory('schemas')->getCSS())

      // Load user custom css
      ->add('theme.css.style-css.inline.custom', get_theme_mod('custom_css', ''));

    // Allow user to create custom.css or custom.js file
    // and get loaded automatically.
    VTCore_Wordpress_init::getFactory('assets')
      ->get('queues')
      ->add('custom', $enqueueArgs);

  }
}