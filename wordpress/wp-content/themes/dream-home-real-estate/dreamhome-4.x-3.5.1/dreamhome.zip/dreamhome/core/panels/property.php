<?php
/**
 * Panel section for configuring property options
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Panels_Property
extends VTCore_Zeus_Panels_Model {

  /**
   * Overriding parent method
   * @see VTCore_Bootstrap_Element_BsElement::buildElement()
   */
  public function buildElement() {


    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Single Page', 'dreamhome'),
      'id' => 'vtcore-zeus-property-page-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' =>  __('This setting will be applied to the property single page', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_single][fotorama]',
        'text' => __('Show Image Gallery', 'dreamhome'),
        'description' => __('Show / hide the property single gallery image using fotorama.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_single', 'fotorama'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_single][title]',
        'text' => __('Show Title', 'dreamhome'),
        'description' => __('Show / hide the property single title.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_single', 'title'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_single][address]',
        'text' => __('Show Address', 'dreamhome'),
        'description' => __('Show / hide the property single address.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_single', 'address'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_single][fields]',
        'text' => __('Show Property Fields', 'dreamhome'),
        'description' => __('Show / hide the property single fields.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_single', 'fields'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_single][attributes]',
        'text' => __('Show Attributes', 'dreamhome'),
        'description' => __('Show / hide the property single attributes.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_single', 'attributes'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_single][content]',
        'text' => __('Show Content', 'dreamhome'),
        'description' => __('Show / hide the property single content.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_single', 'content'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_single][price]',
        'text' => __('Show Price', 'dreamhome'),
        'description' => __('Show / hide the property single price.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_single', 'price'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_single][social]',
        'text' => __('Show Social', 'dreamhome'),
        'description' => __('Show / hide the property single social.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_single', 'social'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_single][floorplan]',
        'text' => __('Show Floorplan', 'dreamhome'),
        'description' => __('Show / hide the property single floorplan.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_single', 'floorplan'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_single][video]',
        'text' => __('Show Video', 'dreamhome'),
        'description' => __('Show / hide the property single video.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_single', 'video'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_single][status]',
        'text' => __('Show Status', 'dreamhome'),
        'description' => __('Show / hide the property single status.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_single', 'status'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_single][listing]',
        'text' => __('Show Listing', 'dreamhome'),
        'description' => __('Show / hide the property single latest property listing box.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_single', 'listing'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));

    if (defined('VTCORE_AGENTS_LOADED')) {
      $this->panel
        ->lastChild()
        ->BsCheckbox(array(
          'name' => 'theme[features][show][property_single][agents]',
          'text' => __('Show Agents', 'dreamhome'),
          'description' => __('Show / hide the property agents.', 'dreamhome'),
          'checked' => (boolean) $this->getShow('property_single', 'agents'),
          'switch' => true,
          'grids' => array(
            'columns' => array(
              'mobile' => 12,
              'tablet' => 6,
              'small' => 6,
              'large' => 6,
            ),
          ),
        ));
    }

    if (defined('WPCF7_VERSION')) {
      $this->panel
        ->lastChild()
        ->BsCheckbox(array(
          'name' => 'theme[features][show][property_single][contact]',
          'text' => __('Show Contact', 'dreamhome'),
          'description' => __('Show / hide the property single contact.', 'dreamhome'),
          'checked' => (boolean) $this->getShow('property_single', 'contact'),
          'switch' => true,
          'grids' => array(
            'columns' => array(
              'mobile' => 12,
              'tablet' => 6,
              'small' => 6,
              'large' => 6,
            ),
          ),
        ));
    }

    if (defined('VTCORE_MAPS_LOADED')) {
      $this->panel
        ->lastChild()
        ->BsCheckbox(array(
          'name' => 'theme[features][show][property_single][maps]',
          'text' => __('Show Maps', 'dreamhome'),
          'description' => __('Show / hide the property single maps.', 'dreamhome'),
          'checked' => (boolean) $this->getShow('property_single', 'maps'),
          'switch' => true,
          'grids' => array(
            'columns' => array(
              'mobile' => 12,
              'tablet' => 6,
              'small' => 6,
              'large' => 6,
            ),
          ),
        ));
    }

    $this->panel
      ->BsText(array(
        'text' => __('Title', 'dreamhome'),
        'name' => 'theme[features][options][property_single_listing][title]',
        'description' => __('Define property single page title', 'dreamhome'),
        'value' => $this->getOption('property_single_listing', 'title'),
      ))
      ->BsTextarea(array(
        'text' => __('Description', 'dreamhome'),
        'name' => 'theme[features][options][property_single_listing][description]',
        'description' => __('Define property single page description text', 'dreamhome'),
        'value' => $this->getOption('property_single_listing', 'description'),
      ));

    $this->processPanel();




    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Teaser List', 'dreamhome'),
      'id' => 'vtcore-zeus-property-teaser-list-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' => __('The property teaser setting will be applied property teaser elements when it uses the list template mode.', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_list][image]',
        'text' => __('Show Image', 'dreamhome'),
        'description' => __('Show / hide the property teaser image.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_list', 'image'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_list][title]',
        'text' => __('Show Title', 'dreamhome'),
        'description' => __('Show / hide the property teaser title.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_list', 'title'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_list][address]',
        'text' => __('Show Address', 'dreamhome'),
        'description' => __('Show / hide the property teaser address.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_list', 'address'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_list][price]',
        'text' => __('Show Price', 'dreamhome'),
        'description' => __('Show / hide the property teaser price.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_list', 'price'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_list][excerpt]',
        'text' => __('Show Excerpt', 'dreamhome'),
        'description' => __('Show / hide the property teaser excerpt.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_list', 'excerpt'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_list][social]',
        'text' => __('Show Social', 'dreamhome'),
        'description' => __('Show / hide the property teaser social buttons.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_list', 'social'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_list][readmore]',
        'text' => __('Show Readmore', 'dreamhome'),
        'description' => __('Show / hide the property teaser readmore.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_list', 'readmore'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_list][info]',
        'text' => __('Show Property Info', 'dreamhome'),
        'description' => __('Show / hide the property teaser info box.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_list', 'info'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));

    $this->processPanel();



    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Teaser Grid', 'dreamhome'),
      'id' => 'vtcore-zeus-property-teaser-grid-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->BsDescription(array(
        'text' => __('The property teaser setting will be applied property teaser elements when it uses the grid template mode.', 'dreamhome'),
      ))
      ->BsRow()
      ->lastChild()
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_grid][image]',
        'text' => __('Show Image', 'dreamhome'),
        'description' => __('Show / hide the property teaser image.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_grid', 'image'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_grid][title]',
        'text' => __('Show Title', 'dreamhome'),
        'description' => __('Show / hide the property teaser title.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_grid', 'title'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_grid][address]',
        'text' => __('Show Address', 'dreamhome'),
        'description' => __('Show / hide the property teaser address.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_grid', 'address'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_grid][price]',
        'text' => __('Show Price', 'dreamhome'),
        'description' => __('Show / hide the property teaser price.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_grid', 'price'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_grid][excerpt]',
        'text' => __('Show Excerpt', 'dreamhome'),
        'description' => __('Show / hide the property teaser excerpt.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_grid', 'excerpt'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_grid][social]',
        'text' => __('Show Social', 'dreamhome'),
        'description' => __('Show / hide the property teaser social buttons.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_grid', 'social'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_grid][readmore]',
        'text' => __('Show Readmore', 'dreamhome'),
        'description' => __('Show / hide the property teaser readmore.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_grid', 'readmore'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ))
      ->BsCheckbox(array(
        'name' => 'theme[features][show][property_teaser_grid][info]',
        'text' => __('Show Property Info', 'dreamhome'),
        'description' => __('Show / hide the property teaser info box.', 'dreamhome'),
        'checked' => (boolean) $this->getShow('property_teaser_grid', 'info'),
        'switch' => true,
        'grids' => array(
          'columns' => array(
            'mobile' => 12,
            'tablet' => 6,
            'small' => 6,
            'large' => 6,
          ),
        ),
      ));

    $this->processPanel();

  }

}