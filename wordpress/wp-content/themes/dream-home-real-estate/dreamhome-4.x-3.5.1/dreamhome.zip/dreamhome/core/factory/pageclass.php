<?php
/**
 * Centralized Factory for building the main div page
 * attributes. It is recommended to use this factory
 * when adding or removing attributes of the page element.
 *
 * @author jason.xie@victheme.com
 */
class VTCore_Zeus_Factory_PageClass
extends VTCore_Html_Base {

  protected $context = array(
    'type' => 'div',
    'raw' => false,
    'clean' => false,
    'attributes' => array(
      'id' => 'page',
      'class' => array(
        'clearfix',
        'ajax-page-target',
      ),
    ),
  );


  public function buildElement() {
    
    // Don't allow the element to have children!
    $this
      ->resetChildren()
      ->addAttributes($this->getContext('attributes'));
    
    // Processing common theme page classes
    if (VTCore_Zeus_Init::getFactory('features')->get('options.page.maxwidth', 'attr')) {
      $this->addClass(VTCore_Zeus_Init::getFactory('features')->get('options.page.maxwidth', 'attr'));
    }
    
    if (VTCore_Zeus_Init::getFactory('features')->get('options.page.style', 'attr')) {
      $this->addClass(VTCore_Zeus_Init::getFactory('features')->get('options.page.style', 'attr'));
    }

    // Booting the custom template variables
    if (defined('VTCORE_WORDPRESS_CUSTOM_TEMPLATE_FILE')) {
      $this->addClass(str_replace('.php', '', VTCORE_WORDPRESS_CUSTOM_TEMPLATE_FILE));
    }

    // Booting schema name
    if (VTCore_Zeus_Init::getFactory('schemas')->getActiveSchema()) {
      $this->addClass('schema-' . VTCore_Zeus_Init::getFactory('schemas')->getActiveSchemaID());
    }

    // Booting jigsaw effect
    if (VTCore_Zeus_Init::getFactory('features')->get('options.styling.saw_effect')) {
      $this->addClass('with-saw-effect');
    }
    else {
      $this->addClass('without-saw-effect');
    }

    // Adding extra classes for easier css theming
    if (VTCore_Zeus_Utility::isActiveSidebar('slider')) {
      $this->addClass('with-slider');
    }
    else {
      $this->addClass('without-slider');
    }
    
    // Booting slicknav
    if (VTCore_Zeus_Init::getFactory('features')->get('options.menu.enable_slick')) {
      $this->addClass('with-slicknav');
    }
    else {
      $this->addClass('without-slicknav');
    }

    // Booting sticky header
    if (VTCore_Zeus_Init::getFactory('features')->get('options.menu.enable_sticky')) {
      $this->addClass('with-sticky');
    }
    else {
      $this->addClass('without-sticky');
    }

    // Booting autoformat
    if (VTCore_Zeus_Init::getFactory('features')->get('options.menu.enable_autoformat')) {
      $this->addClass('with-auto-menu-shrink');
    }
    else {
      $this->addClass('without-auto-menu-shrink');
    }

    // Booting jvfloat
    if (VTCore_Zeus_Init::getFactory('features')->get('options.form.jvfloat')) {
      $this->addClass('with-jvfloat jvfloat');
    }
    else {
      $this->addClass('without-jvfloat');
    }
    
    // Booting animsition
    if (VTCore_Zeus_Init::getFactory('features')->get('options.animsition.enable')) {
      $this
        ->addClass('animsition with-animsition')

        ->addData(
          'animsition-loading-text',
          VTCore_Zeus_Init::getFactory('features')
            ->get('options.animsition.loading_text', 'data'))

        ->addData(
          'animsition-in-class',
          VTCore_Zeus_Init::getFactory('features')
            ->get('options.animsition.animation_in', 'data'))

        ->addData(
          'animsition-in-duration',
          VTCore_Zeus_Init::getFactory('features')
            ->get('options.animsition.in_duration', 'data'))

        ->addData(
          'animsition-out-class',
          VTCore_Zeus_Init::getFactory('features')
            ->get('options.animsition.animation_out', 'data'))

        ->addData(
          'animsition-out-duration',
          VTCore_Zeus_Init::getFactory('features')
            ->get('options.animsition.out_duration', 'data'));
    }
    else {
      $this->addClass('without-animsition');
    }


    // Booting nicescroll
    if (VTCore_Zeus_Init::getFactory('features')->get('options.nicescroll.enable')) {

      // Preprocess boolean
      $options = VTCore_Zeus_Init::getFactory('features')->get('options.nicescroll');
      foreach (array('enable', 'bouncescroll', 'touchbehavior', 'autohide') as $key) {
        if (isset($options[$key])) {
          $options[$key] = filter_var($options[$key], FILTER_VALIDATE_BOOLEAN);
        }
      }

      $this
        ->addClass('with-nicescroll')

        ->addData('nicescroll', $options)

        ->addData('nicescroll.cursorcolor', VTCore_Zeus_Init::getFactory('schemas')
          ->getActiveSchema()
          ->getColorValue('nicescroll', 'background-color-bar'))

        ->addData('nicescroll.cursorborder', FALSE)

        ->addData('nicescroll.background', VTCore_Zeus_Init::getFactory('schemas')
          ->getActiveSchema()
          ->getColorValue('nicescroll', 'background-color-rail'));
    }

    // Booting offcanvas
    if (VTCore_Zeus_Init::getFactory('features')->get('options.offcanvas.enable')) {
      $options = VTCore_Zeus_Init::getFactory('features')->get('options.offcanvas');
      foreach (array('swipe') as $key) {
        if (isset($options[$key])) {
          $options[$key] = filter_var($options[$key], FILTER_VALIDATE_BOOLEAN);
        }
      }

      $this
        ->addClass('with-offcanvas')
        ->addData('offcanvas', $options);
    }

    // Standard headline support
    if (defined('VTCORE_HEADLINE_LOADED') && VTCORE_HEADLINE_LOADED) {
      $headlineInstance = VTCore_Headline_Utility::getHeadline();
      if (isset($headlineInstance['general']['enable']) && $headlineInstance['general']['enable'] == TRUE) {

        $this->addClass('with-headline');

        if (isset($headlineInstance['general']['position'])) {
          $this->addClass('headline-direction-' . $headlineInstance['general']['position']);
        }

        if (isset($headlineInstance['general']['template'])) {
          $this->addClass('headline-template-' . $headlineInstance['general']['template']);
        }
      }
      else {
        $this->addClass('without-headline');
      }
    }

  }


  /**
   * Build and convert the object into HTML value
   */
  protected function buildContent() {
    return str_replace(array('<div', '</div>', '>'), array('', '', '' ), parent::buildContent());
  }

}