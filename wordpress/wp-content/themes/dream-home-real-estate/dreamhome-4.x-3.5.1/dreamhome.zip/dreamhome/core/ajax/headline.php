<?php
/**
 * Ajax callback class for WpAccordion Object
 *
 * Additional context outside the wp-ajax api context needed
 * for building the proper ajax results :
 *
 * WpAccordion
 * ===========
 * context : serialized base64_encoded strings containing
 *           array of arguments for WpAccodion Object content
 * id      : the id for the destination target
 *
 *
 * @see VTCore_Wordpress_Element_WpAccordion
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Ajax_Headline
extends VTCore_Wordpress_Models_Ajax {

  protected $render = array();
  protected $post;


  private $context;


  /**
   * Ajax callback function
   *
   * $post will hold all the data passed by ajax.
   */
  protected function processAjax() {

    $this->context = unserialize(base64_decode($this->post['value']));
    $this->context['general']['template'] = $this->post['elval'];
    $this->context['ajax-delta'] = $this->post['target'];

    $object = new VTCore_Headline_Metabox_Items($this->context);
    $object = apply_filters('vtcore_headline_metabox_form_alter', $object);

    $this->render['action'][] = array(
      'mode' => 'replace',
      'target' => '#ajax-target-items-' . $this->post['target'],
      'content' => $object->__toString(),
    );

    $object = new VTCore_Headline_Metabox_General($this->context);
    $object = apply_filters('vtcore_headline_metabox_form_alter', $object);

    $this->render['action'][] = array(
      'mode' => 'replace',
      'target' => '#ajax-target-general-' . $this->post['target'],
      'content' => $object->__toString(),
    );

    return $this->render;
  }

}