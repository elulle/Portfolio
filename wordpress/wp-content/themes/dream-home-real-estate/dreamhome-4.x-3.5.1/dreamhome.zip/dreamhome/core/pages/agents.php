<?php
/**
 * Simple plugin system for configuration panels
 *
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Pages_Agents
extends VTCore_Zeus_Pages_Model {

  /**
   * Override parent method
   * @return VTCore_Zeus_Pages_Style
   */
  protected function config() {

    $this->icon = 'dashboard';
    $this->title = __('Agents Options', 'dreamhome');

    // Force refresh features
    VTCore_Zeus_Init::getFactory('features')->register(array());

    $this->object = new VTCore_Zeus_Panels_Agents(array(
      'features' => VTCore_Zeus_Init::getFactory('features'),
      'process' => !empty($_POST['theme']),
    ));

    return $this;
  }

}