<?php
/**
 * Panel section for configuring general options
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Panels_CSS
extends VTCore_Zeus_Panels_Model {


  /**
   * Overriding parent method
   * @see VTCore_Bootstrap_Element_BsElement::buildElement()
   */
  public function buildElement() {

    // Logo Configurations
    $this->panel = new VTCore_Bootstrap_Element_BsPanel(array(
      'text' => __('Custom CSS Rule', 'dreamhome'),
      'id' => 'vtcore-zeus-customcss-panel',
    ));

    $this->panel
      ->setChildrenPointer('content')
      ->addChildren(new VTCore_Bootstrap_Form_BsDescription(array(
        'text' => __('The custom css entered here will be recorded to database and printed as inline css when page is loading.', 'dreamhome'),
      )))
      ->addChildren(new VTCore_Bootstrap_Form_BsTextarea(array(
        'name' => 'theme[custom_css]',
        'value' => get_theme_mod('custom_css', ''),
        'raw' => true,
            'id' => 'custom_css',
      )));

    $this->processPanel();

  }

}