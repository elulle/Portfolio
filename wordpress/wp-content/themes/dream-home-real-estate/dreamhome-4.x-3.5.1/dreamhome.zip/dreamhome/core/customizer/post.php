<?php
/**
 * Class for generating customizer array
 *
 * @author jason.xie@victheme.com
 */
class VTCore_Zeus_Customizer_Post
extends VTCore_Zeus_Customizer_Model {

  protected $panelKey = 'zeus_post';
  protected $key = 'post';

  public function register() {

    if (!$this->getCache()) {
      $this->object = new VTCore_Zeus_Panels_Post(array(
        'features' => VTCore_Zeus_Init::getFactory('features'),
        'process' => false,
        'build' => 'object',
      ));

      $this->context[$this->key]['panels'][$this->panelKey] = array(
        'title' => __('Post Page', 'dreamhome'),
        'priority' => 403,
        'capability' => 'edit_theme_options',
        'description' => __('Configure the theme post page options.', 'dreamhome'),
        'active_callback' => array($this, 'active_callback'),
      );

      $this->buildContext();
      $this->setCache();
    }

    $this->insert();


    return $this;
  }

  public function active_callback() {

    $active = (is_singular('post') || is_post_type_archive('post') || is_home());

    if (!$active) {

      // Detect Custom template;
      $template = VTCore_Zeus_Utility::getCustomTemplate();
      if (strpos($template, 'blog') !== false) {
        $active = true;
      }
    }

    if (!$active) {

      // Detect Custom template;
      $template = VTCore_Zeus_Utility::getCustomTemplate();
      if (strpos($template, 'post') !== false) {
        $active = true;
      }
    }

    return $active;
  }


}
