<?php
/**
 * Link to Wordpress Action admin_menu for
 * registering Zeus Administration menus.
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Actions_Admin__Menu
extends VTCore_Wordpress_Models_Hook {

  public function hook() {

    // Theme general configuration
    add_theme_page(
      'General Options',
      'General',
      'edit_theme_options',
      'zeus_general_options',
      array(new VTCore_Zeus_Pages_General(), 'buildPage')
    );


    // Theme schema configuration
    add_theme_page(
      'Style Options',
      'Style',
      'edit_theme_options',
      'zeus_schema_options',
      array(new VTCore_Zeus_Pages_Style(), 'buildPage')
    );

    // Theme layout configuration
    add_theme_page(
      'Layout Options',
      'Layout',
      'edit_theme_options',
      'zeus_layout_options',
      array(new VTCore_Zeus_Pages_Layout(), 'buildPage')
    );

    // Theme property configuration
    add_theme_page(
      'Post Options',
      'Post',
      'edit_theme_options',
      'zeus_posts_options',
      array(new VTCore_Zeus_Pages_Post(), 'buildPage')
    );

    // Theme property configuration
    add_theme_page(
      'Page Options',
      'Page',
      'edit_theme_options',
      'zeus_page_options',
      array(new VTCore_Zeus_Pages_Page(), 'buildPage')
    );

    // Theme property configuration
    add_theme_page(
      'Property Options',
      'Property',
      'edit_theme_options',
      'zeus_property_options',
      array(new VTCore_Zeus_Pages_Property(), 'buildPage')
    );

    // Theme property configuration
    add_theme_page(
      'Agents Options',
      'Agents',
      'edit_theme_options',
      'zeus_agents_options',
      array(new VTCore_Zeus_Pages_Agents(), 'buildPage')
    );


    // Theme dsidx configuration
    add_theme_page(
      'DsIDX Options',
      'DsIDX',
      'edit_theme_options',
      'zeus_dsidx_options',
      array(new VTCore_Zeus_Pages_DsIDX(), 'buildPage')
    );


    // Custom css configuration page
    add_theme_page(
      'Custom CSS',
      'Custom CSS',
      'edit_theme_options',
      'custom_css',
      array(new VTCore_Zeus_Pages_CSS(), 'buildPage')
    );

  }
}