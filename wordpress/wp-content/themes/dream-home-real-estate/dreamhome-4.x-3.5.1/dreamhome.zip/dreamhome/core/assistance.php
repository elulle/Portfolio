<?php
/**
 * Class for registering the help pages url
 *
 * Entries should have :
 *   title    :  The link title
 *   url      :  The link url
 *   target   :  The link target
 *   type     :  The link type
 *
 *
 * @available constant :
 *     VTCORE_ZEUS_HELP_URL for the theme main help url.
 *
 * @author jason.xie@victheme.com
 * @used in theme options help button and help panels
 *
 */
class VTCore_Zeus_Assistance {

  protected $context;

  public function __construct() {

    $this->context = array(

      'documentation' => array(
        'title' => __('Read Theme Documentation', 'dreamhome'),
        'url' => 'http://documentation.victheme.com/' . BASE_THEME . '/index.html',
        'target' => '_blank',
        'type' => 'link',
      ),

      'logo' => array(
        'title' => __('How to change logo', 'dreamhome'),
        'url' => 'http://vimeo.com/117257138',
        'target' => '_blank',
        'type' => 'video',
      ),


      'favicon' => array(
        'title' => __('How to change favicon', 'dreamhome'),
        'url' => 'http://vimeo.com/117389963',
        'target' => '_blank',
        'type' => 'video',
      ),

      'slick_menu' => array(
        'title' => __('How to enable or disable mobile menu', 'dreamhome'),
        'url' => 'http://vimeo.com/98117247',
        'target' => '_blank',
        'type' => 'video'
      ),

      'page_loading' => array(
        'title' => __('How to configure page loading animation', 'dreamhome'),
        'url' => 'http://vimeo.com/117277088',
        'target' => '_blank',
        'type' => 'video'
      ),

      'archives' => array(
        'title' => __('How to configure Archives page ', 'dreamhome'),
        'url' => 'http://vimeo.com/117932881',
        'target' => '_blank',
        'type' => 'video'
      ),

      'property' => array(
        'title' => __('How to set title on property single page', 'dreamhome'),
        'url' => 'http://vimeo.com/117812579',
        'target' => '_blank',
        'type' => 'video'
      ),


      'agents' => array(
        'title' => __('How to set title on property agents profile page', 'dreamhome'),
        'url' => 'http://vimeo.com/117872455',
        'target' => '_blank',
        'type' => 'video'
      ),


      'excerpt' => array(
        'title' => __('How to hide / show elements', 'dreamhome'),
        'url' => 'http://vimeo.com/117396108',
        'target' => '_blank',
        'type' =>'video',
      ),

      'copyright' => array(
        'title' => __('How to change copyright text', 'dreamhome'),
        'url' => 'http://vimeo.com/117396092',
        'target' => '_blank',
        'type' => 'video',
      ),


      'configure404'  => array(
        'title' => __('How to configure page 404', 'dreamhome'),
        'url' => 'http://vimeo.com/97198352',
        'target' => '_blank',
        'type' => 'video',
      ),


      'pagelayout'  => array(
        'title' => __('How to configure page grid layout', 'dreamhome'),
        'url' => 'http://vimeo.com/97197361',
        'target' => '_blank',
        'type' => 'video',
      ),


      'sidebar_position_blog'  => array(
        'title' => __('How to configure sidebar position', 'dreamhome'),
        'url' => 'http://vimeo.com/117400163',
        'target' => '_blank',
        'type' => 'video',
      ),

      'layout_top'  => array(
        'title' => __('How to configure top header grid layout', 'dreamhome'),
        'url' => 'http://vimeo.com/108911665',
        'target' => '_blank',
        'type' => 'video',
      ),

      'layout_header'  => array(
        'title' => __('How to configure header grid layout', 'dreamhome'),
        'url' => 'http://vimeo.com/97197650',
        'target' => '_blank',
        'type' => 'video',
      ),

      'layout_maincontent'  => array(
        'title' => __('How to configure main content grid layout', 'dreamhome'),
        'url' => 'http://vimeo.com/97197652',
        'target' => '_blank',
        'type' => 'video',
      ),

      'layout_content_bottom'  => array(
        'title' => __('How to configure content bottom grid layout', 'dreamhome'),
        'url' => 'http://vimeo.com/109032053',
        'target' => '_blank',
        'type' => 'video',
      ),

      'layout_footer'  => array(
        'title' => __('How to configure content bottom grid layout', 'dreamhome'),
        'url' => 'http://vimeo.com/97197648',
        'target' => '_blank',
        'type' => 'video',
      ),

      'layout_fullfooter'  => array(
        'title' => __('How to configure content bottom grid layout', 'dreamhome'),
        'url' => 'http://vimeo.com/97197649',
        'target' => '_blank',
        'type' => 'video',
      ),


      'change_theme_style'  => array(
        'title' => __('How to change theme style', 'dreamhome'),
        'url' => 'http://vimeo.com/98295905',
        'target' => '_blank',
        'type' => 'video',
      ),


      'schema'  => array(
        'title' => __('How to customize color schema', 'dreamhome'),
        'url' => 'http://vimeo.com/97198353',
        'target' => '_blank',
        'type' => 'video',
      ),


      /** Not linked any where **/
      'disable_parent_link'  => array(
        'title' => __('how to disable parent link for menu', 'dreamhome'),
        'url' => 'http://vimeo.com/98125334',
        'target' => '_blank',
        'type' => 'video',
      ),

      'sticky_header'  => array(
        'title' => __('How to enable header sticky menu navigation', 'dreamhome'),
        'url' => 'https://vimeo.com/117276483',
        'target' => '_blank',
        'type' => 'video',
      ),

      'single_post_element'  => array(
        'title' => __('How to configure single post element', 'dreamhome'),
        'url' => 'http://vimeo.com/117396109',
        'target' => '_blank',
        'type' => 'video',
      ),

      'single_page_element'  => array(
        'title' => __('How to configure single page element', 'dreamhome'),
        'url' => 'http://vimeo.com/117400136',
        'target' => '_blank',
        'type' => 'video',
      ),

      '404_page_element'  => array(
        'title' => __('How to configure error 404 page', 'dreamhome'),
        'url' => 'http://vimeo.com/97198351',
        'target' => '_blank',
        'type' => 'video',
      ),

      'footer_element'  => array(
        'title' => __('How to configure footer element', 'dreamhome'),
        'url' => 'http://vimeo.com/117389970',
        'target' => '_blank',
        'type' => 'video',
      ),

      'page_layout_responsive'  => array(
        'title' => __('How to set responsiveness', 'dreamhome'),
        'url' => 'http://vimeo.com/100229182',
        'target' => '_blank',
        'type' => 'video',
      ),

      'sidebar_position_404'  => array(
        'title' => __('How to set responsiveness', 'dreamhome'),
        'url' => 'http://vimeo.com/97197362',
        'target' => '_blank',
        'type' => 'video',
      ),

      'headline'  => array(
        'title' => __('How to change headline color', 'dreamhome'),
        'url' => 'http://vimeo.com/98248810',
        'target' => '_blank',
        'type' => 'video',
      ),


      'theme_options_visibility'  => array(
        'title' => __('How to open or hide elements between settings', 'dreamhome'),
        'url' => 'http://vimeo.com/97197359',
        'target' => '_blank',
        'type' => 'video',
      ),

      'theme_options_reset'  => array(
        'title' => __('How to Reset the settings back to default', 'dreamhome'),
        'url' => 'http://vimeo.com/117937731',
        'target' => '_blank',
        'type' => 'video',
      ),

      'post_type_post'  => array(
        'title' => __('How to create post', 'dreamhome'),
        'url' => 'http://vimeo.com/97197360',
        'target' => '_blank',
        'type' => 'video',
      ),

      'headline_archive'  => array(
        'title' => __('How to configure headline in archive page', 'dreamhome'),
        'url' => 'http://vimeo.com/98895630',
        'target' => '_blank',
        'type' => 'video',
      ),

      'headline_inner'  => array(
        'title' => __('How to configure headline in archive page', 'dreamhome'),
        'url' => 'http://vimeo.com/98907848',
        'target' => '_blank',
        'type' => 'video',
      ),

      'footer_widgets'  => array(
        'title' => __('How to configure footer element using widget', 'dreamhome'),
        'url' => 'http://vimeo.com/98307178',
        'target' => '_blank',
        'type' => 'video',
      ),


      'visualmaps'  => array(
        'title' => __('How to create maps', 'dreamhome'),
        'url' => 'http://vimeo.com/98855605',
        'target' => '_blank',
        'type' => 'video',
      ),

      'visualfront'  => array(
        'title' => __('How to edit page using visual composer frontend editor', 'dreamhome'),
        'url' => 'http://vimeo.com/108890353',
        'target' => '_blank',
        'type' => 'video',
      ),

      'visualback'  => array(
        'title' => __('How to edit page using visual composer backend editor', 'dreamhome'),
        'url' => 'http://vimeo.com/108892911',
        'target' => '_blank',
        'type' => 'video',
      ),

      'property_teaser'  => array(
        'title' => __('How to configure property teaser element', 'dreamhome'),
        'url' => 'https://vimeo.com/117883561',
        'target' => '_blank',
        'type' => 'video',
      ),

      'property_single'  => array(
        'title' => __('How to configure property single page element', 'dreamhome'),
        'url' => 'https://vimeo.com/117920343',
        'target' => '_blank',
        'type' => 'video',
      ),

      'agents_list_list'  => array(
        'title' => __('How to configure Agents listing List mode element', 'dreamhome'),
        'url' => 'https://vimeo.com/117928645',
        'target' => '_blank',
        'type' => 'video',
      ),

      'agents_list_grid'  => array(
        'title' => __('How to configure Agents listing Grid mode element', 'dreamhome'),
        'url' => 'https://vimeo.com/117931609',
        'target' => '_blank',
        'type' => 'video',
      ),

      'agents_profile'  => array(
        'title' => __('How to configure Agents profile element', 'dreamhome'),
        'url' => 'https://vimeo.com/117933984',
        'target' => '_blank',
        'type' => 'video',
      ),




    );

  }


  public function getAssistanceItems() {
    return $this->context;
  }

  public function getAssistanceItem($type, $key) {
    return isset($this->context[$type][$key]) ? $this->context[$type][$key] : false;
  }

}