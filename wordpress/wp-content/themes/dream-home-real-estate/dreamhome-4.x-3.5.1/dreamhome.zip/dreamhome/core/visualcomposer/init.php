<?php
/**
 * Visual Composer addon for Zeus Framework
 *
 * @author jason.xie@victheme.com
 */
class VTCore_Zeus_VisualComposer_Init {

  /**
   * Registering theme to visual composer
   */
  public function registerTheme() {
    vc_set_as_theme(true);
    vc_set_shortcodes_templates_dir(VTCORE_ZEUS_THEME_PATH . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . 'visualcomposer' . DIRECTORY_SEPARATOR);
  }


  /**
   * Collect all new parameters in this method
   * This is done this way because this needs to be invoked
   * on hook action init.
   */
  public function addParams() {}


  /**
   * Collect all params altering here, this is done
   * this way because this is need to be invoked after
   * hook action init.
   */
  public function alterParams() {

    // Extra styles
    VcSharedLibrary::$box_styles[__('Diamond', 'dreamhome')] = 'diamond';
    VcSharedLibrary::$box_styles[__('Post Thumbnail', 'dreamhome')] = 'post-thumbnail';


    vc_update_shortcode_param('vc_single_image', array(
      'type' => 'dropdown',
      'heading' => __( 'Image style', 'js_composer' ),
      'param_name' => 'style',
      'value' => VcSharedLibrary::$box_styles
    ));

    vc_update_shortcode_param('vc_single_image', array(
      'type' => 'textfield',
      'heading' => __( 'Border Size', BASE_THEME ),
      'param_name' => 'border_width',
      'dependency' => array(
        'element' => 'style',
        'value' => array('diamond')
      ),
    ));

    vc_update_shortcode_param('vc_single_image', array(
      'type' => 'dropdown',
      'heading' => __( 'Border color', 'js_composer' ),
      'param_name' => 'border_color',
      'value' => getVcShared( 'colors' ),
      'std' => 'grey',
      'dependency' => array(
        'element' => 'style',
        'value' => array( 'vc_box_border', 'vc_box_border_circle', 'vc_box_outline', 'vc_box_outline_circle', 'diamond')
      ),
      'description' => __( 'Border color.', 'js_composer' ),
      'param_holder_class' => 'vc_colored-dropdown'
    ));
  }


  /**
   * Adding default templates
   */
  public function addTemplate($templates) {

    // Calling the template storage and
    // inject the template strings.
    $this->templates = new VTCore_Zeus_VisualComposer_Template();
    return $this->templates->themeTemplates($templates);
  }


  /**
   * Adding custom grid
   * @return array
   */
  public function addGrid($templates) {
    $this->grid = new VTCore_Zeus_VisualComposer_Grid();
    return $this->grid->themeGridTemplates($templates);
  }

}