<?php
/**
 * Class for generating customizer array
 *
 * @author jason.xie@victheme.com
 */
class VTCore_Zeus_Customizer_Agents
extends VTCore_Zeus_Customizer_Model {

  protected $panelKey = 'zeus_agents';
  protected $key = 'agents';

  public function register() {

    if (!$this->getCache()) {
      $this->object = new VTCore_Zeus_Panels_Agents(array(
        'features' => VTCore_Zeus_Init::getFactory('features'),
        'process' => false,
        'build' => 'object',
      ));

      $this->context[$this->key]['panels'][$this->panelKey] = array(
        'title' => __('Agents', 'dreamhome'),
        'priority' => 403,
        'capability' => 'edit_theme_options',
        'description' => __('Configure the theme property agents options.', 'dreamhome'),
        'active_callback' => array($this, 'active_callback'),
      );

      $this->buildContext();
      $this->setCache();
    }

    $this->insert();


    return $this;
  }

  public function active_callback() {
    $active = false;
    if (defined('VTCORE_AGENTS_LOADED')) {
      global $wp_query;
      $active = ((isset($wp_query->is_agent_profile ) && $wp_query->is_agent_profile  == TRUE) || (isset($wp_query->is_agent_listing) && $wp_query->is_agent_listing  == TRUE));

      if (!$active) {

        // Detect Custom template;
        $template = VTCore_Zeus_Utility::getCustomTemplate();
        if (strpos($template, 'agents') !== false) {
          $active = true;
        }
      }
    }
    return $active;
  }

}
