<?php
/**
 * Hooking into vtcore_headline_context_alter to change
 * the default context for headline metabox
 *
 * @author jason.xie@victheme.com
 *
 */
class VTCore_Zeus_Filters_VTCore__Headline__Context__Alter
extends VTCore_Wordpress_Models_Hook {

  protected $argument = 2;

  public function hook($context = NULL, $options = NULL) {

    // Check if user has enter any data or not
    if (empty($options)) {

      // Allow per schema to inject default value to configuration.
      $object = new VTCore_Wordpress_Objects_Array((array) $context);
      $object
        ->mutate('general.enable', true)
        ->merge(VTCore_Zeus_Init::getFactory('schemas')->getActiveSchema()->getData('headline'));

      $context = $object->extract();
      unset($object);

    }

    return $context;
  }
}