<?php
/**
 * Main template for building
 * the property archive page
 * including all the property categories
 * and its archive page.
 *
 * The main loop can be configured
 * via victheme_property configuration
 * page GUI.
 *
 * @author jason.xie@victheme.com
 */
?>
<?php get_header(); ?>

  <div id="maincontent" class="area clearfix">
    <div class="container-fluid">
      <div class="row">

        <div id="content"
             class="region
			      <?php if (VTCore_Zeus_Utility::getSidebar('property_archive')) {
               echo VTCore_Zeus_Utility::getColumnSize('content');
             } ?>
			      <?php echo 'with-sidebar-' . VTCore_Zeus_Utility::getSidebar('property_archive'); ?>">


          <?php

          // Overriding the default property loop
          // pager arguments
          $pagerArgs = array(
            'prev_text' => __('&larr; Previous', 'dreamhome'),
            'next_text' => __('Next &rarr;', 'dreamhome'),
            'attributes' => array(
              'class' => array(
                'text-center',
              ),
            ),
          );

          // Simply call the victheme_property defaultloop template
          include VTCore_Wordpress_Utility::locateTemplate('property-loop.php');

          ?>

        </div>


        <?php
        // Build sidebar
        if (VTCore_Zeus_Utility::getSidebar('property_archive') == 'right'
          || VTCore_Zeus_Utility::getSidebar('property_archive') == 'left'
        ) {
          get_sidebar('sidebar');
        }
        ?>


      </div>
    </div>
  </div>

<?php get_footer(); ?>