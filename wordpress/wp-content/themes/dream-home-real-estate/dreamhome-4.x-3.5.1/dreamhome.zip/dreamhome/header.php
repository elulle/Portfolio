<?php
/**
 * Main Header template
 * @author jason.xie@victheme.com
 */
?>
<!DOCTYPE html>

<!--[if IEMobile 7 ]> <html <?php language_attributes(); ?>class="no-js iem7"> <![endif]-->
<!--[if lt IE 7 ]> <html <?php language_attributes(); ?> class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html <?php language_attributes(); ?> class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html <?php language_attributes(); ?> class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html <?php language_attributes(); ?> class="no-js ie9"> <![endif]-->
<!--[if IE 10 ]>    <html <?php language_attributes(); ?> class="no-js ie10"> <![endif]-->
<!--[if IE 11 ]>    <html <?php language_attributes(); ?> class="no-js ie11"> <![endif]-->
<!--[if (gte IE 11)|(gt IEMobile 7)|!(IEMobile)|!(IE)]><!--><html <?php language_attributes(); ?> class="no-js"><!--<![endif]-->

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" IE="edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<link rel="shortcut icon" href="<?php echo VTCore_Zeus_Utility::getFavicon(); ?>" />


	<!-- media-queries.js (fallback) -->
	<!--[if lt IE 9]>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
	<![endif]-->

	<!-- html5.js -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

  <!-- Remove the no-js quickly if javascript is enabled -->
  <script>
    document.documentElement.className = document.documentElement.className.replace("no-js","js");
  </script>

	<?php wp_head(); ?>
</head>

<body <?php body_class('template-' . VTCore_Zeus_Utility::getCustomTemplate()); ?>>
<div <?php echo VTCore_Zeus_Init::getFactory('page'); ?>>

  <?php
  // Build offcanvas element
  if (VTCore_Zeus_Init::getFactory('features')->get('options.offcanvas.enable')) {
    get_sidebar('offcanvas');
  }

  ?>

  <?php if (VTCore_Zeus_Utility::isActiveSidebar('top_left') || VTCore_Zeus_Utility::isActiveSidebar('top_right')) : ?>
    <div id="top-header" class="area clearfix">
      <div class="container-fluid">
        <div class="row">
          <?php get_sidebar('top_left'); ?>
          <?php get_sidebar('top_right');?>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php

  if (defined('VTCORE_HEADLINE_LOADED')) {
    $headlineInstance = VTCore_Headline_Utility::getHeadline();
    if (!isset($headlineInstance['general']['position'])) {
      $headlineInstance['general']['position'] = 'bottom';
    }
    if (!isset($headlineInstance['general']['template'])) {
      $headlineInstance['general']['template'] = 'default';
    }
  }

  // Build the headline on position top
  if (defined('VTCORE_HEADLINE_LOADED') && VTCORE_HEADLINE_LOADED && $headlineInstance['general']['position'] == 'top' ) {
    get_template_part('templates' . DIRECTORY_SEPARATOR . 'headline' . DIRECTORY_SEPARATOR . $headlineInstance['general']['template']);
  }

  // Build the header portion for navigation, logo and / or dynamic sidebar
  get_template_part('templates/header/' . VTCore_Zeus_Init::getFactory('features')->get('options.header.template'));

  // Build the headline on position bottom
  if (defined('VTCORE_HEADLINE_LOADED') && VTCORE_HEADLINE_LOADED && $headlineInstance['general']['position'] == 'bottom') {
    get_template_part('templates' . DIRECTORY_SEPARATOR . 'headline' . DIRECTORY_SEPARATOR . $headlineInstance['general']['template']);
  }

  ?>

  <?php get_sidebar('slider'); ?>
  <?php get_sidebar('preface'); ?>
  <?php get_sidebar('content_top'); ?>

