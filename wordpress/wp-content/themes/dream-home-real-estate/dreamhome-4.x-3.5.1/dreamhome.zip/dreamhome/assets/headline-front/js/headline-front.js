/**
 * Controlling the headline parts
 *
 * @author jason.xie@victheme.com
 */
jQuery(document).ready(function ($) {

  "use strict";

  // Adaptive Headline
  // This needs to be initialized as soon as possible
  var VTHeadline  = {
    init: function() {
      this.$headline = $('#headline');
      this.initialized = false;

      if (this.$headline.length) {
        this.$headlineMask = this.$headline.find('.headline-mask');
        this.$headlineBackground = this.$headline.find('.headline-background');
        this.$headlineBar = this.$headline.find('.headline-bar');
        this.$headlineContent = this.$headline.find('.headline-content');
        this.$headlineInner = this.$headline.find('.headline-inner');

        // Detect and set active style
        this.checkActiveStyle();

        var _el = this;
        this.initialized = true;
      }

      return this;
    },
    checkActiveStyle: function() {

      this.active = false;

      if (this.$headline.hasClass('fullscreen-mode')) {
        this.active = this.style.fullscreen;
      }

      if (this.$headline.hasClass('carousel-mode')) {
        this.active = this.style.carousel;
      }

      if (this.$headline.hasClass('clean-mode')) {
        this.active = this.style.clean;
      }

      // Create reference to parent
      if (this.active) {
        this.active.el = this;
      }

      return this;
    },
    style: {
      fullscreen: {
        el: {},
        reposition: function () {

          this.el.innerHeight = 100;

          if (this.el.$headlineBar.length) {
            var that = this.el;
            this.el.$headlineBar.each(function () {
              that.innerHeight += $(this.el).outerHeight();
            });
          }

          if (this.el.$headlineContent.length) {
            this.el.innerHeight += this.el.$headlineContent.outerHeight();
          }

          if (this.el.innerHeight < 480) {
            this.el.innerHeight = 480;
          }

          if (this.el.innerHeight < $(window).height()) {
            this.el.innerHeight = $(window).height();
          }

          this.el.$headline.height(this.el.innerHeight);

          if (this.el.$headlineBackground && this.el.$headlineBackground.hasClass('parallax') == false) {
            this.el.stretchImage();
          }
          return this.el;
        }
      },
      carousel: {
        el: {},
        reposition: function() {

          this.el.innerHeight = 100;

          if (this.el.$headlineInner.length) {
            this.el.innerHeight += this.el.$headlineInner.outerHeight();
          }

          if (this.el.innerHeight < 480) {
            this.el.innerHeight = 480;
          }

          if (this.el.innerHeight < $(window).height()) {
            this.el.innerHeight = $(window).height();
          }

          this.el.$headline.height(this.el.innerHeight);

          if (this.el.$headlineBackground && this.el.$headlineBackground.hasClass('parallax') == false) {
            this.el.stretchImage();
          }

          return this.el;
        }
      }
    },
    reposition: function() {
      this.initialized && this.active && this.active.reposition();
      return this;
    },
    checkImage: function() {
      this.src = this.$headlineBackground.css('background-image').replace(/"/g,"").replace(/url\(|\)$/ig, "");

      if (this.src.length) {
        this.img = new Image();
        this.img.src = this.src;
        this.img;
        this.img.ratio = this.img.width / this.img.height;
      }
      return this;
    },
    stretchImage: function() {

      this.img || this.checkImage();

      if (this.img) {
        this.newsize = {
          width: this.$headline.width(),
          height: this.$headline.width() / this.img.ratio
        };
        // Image is shorter than the viewport
        if ((this.$headline.width() / this.img.ratio) < this.$headline.height()) {
          this.newsize.height = this.$headline.height();
          this.newsize.width = this.newsize.height * this.img.ratio;
        }

        this.$headlineBackground.css('background-size', this.newsize.width + 'px ' + this.newsize.height + 'px');
      }

      return this;
    }
  }

  VTHeadline.init().reposition();

  /**
   * Window events
   */
  $(window)
    .on('resize', function () {

      // Reposition headline
      VTHeadline.init().reposition();
      
    });

});
