/**
 * Javascript for handling Property search forms.
 * This will effect the property advanced search, property simple search,
 * property maps and property split search.
 *
 * It will also try to load bootstrap dropdown js if user has no bootstrap
 * assets loaded.
 *
 * @author jason.xie@victheme.com
 */
(function ($) {

  $(document)

    // Generic functions
    .on('ready.property', function() {
      $('html').addClass('js').removeClass('no-js');
    })

    // Hide the normal search group when we have exposed form
    .on('ready.property-split', function() {
      $('.property-form-with-exposed .property-split-search-normal-input-group').slideUp();
    })

    // Split search toggle button
    .on('click.property-split-advanced-toggle', '.property-split-search-toggle-button', function() {
      var Target = $(this)
        .closest('.property-search-form')
        .find('.property-split-search-normal-input-group');

      Target.slideToggle(300);

      setTimeout(function() {
        if (Target.data('isotope')) {
          Target.addClass('isotope-fixed').isotope('layout');
        }
        $(document).trigger('property-split-toggle');
      }, 301)
    })

    // Fix the z-index problem on bootstrap dropdown element
    // such as bootstrap-select and bootstrap-datepicker
    .on('show.bs.dropdown hide.bs.dropdown', function(event) {

      if (!event.target || !event.type) {
        return;
      }

      var element = $(event.target);
      if (element.hasClass('js-datepicker') || element.hasClass('bootstrap-select')) {
        var propertyGroup = element.closest('.property-search-group');
        if (propertyGroup.length) {
          switch (event.type) {
            case 'show' :
              propertyGroup.addClass('group-active');
              break;

            case 'hide' :
              propertyGroup.removeClass('group-active');
              break;
          }
        }
      }
    })

    // User toggle label
    .on('bs-toggle-change.property-search-type', function (event, element) {
      var PropertyTarget = $(element).closest('.js-isotope');
      PropertyTarget.length && PropertyTarget.data('isotope') && setTimeout(function() {
        PropertyTarget.isotope('layout');
      }, 410);
    })

    // Search form change type
    .on('ajaxComplete.property-search-type-change', function (event, xhr, settings) {

      // These condition must be met before we fire the rest
      if (!settings.marker
        || !settings.marker.id
        || !settings.marker.mode) {

        return;
      }


      switch (settings.marker.mode) {
        case 'property-search-replace' :
          var self = $(settings.marker.id),
            AjaxData = $.fn.VTCoreProcessAjaxResponse(xhr.responseText),
            objectQueue = $({});

          // Initialize isotope if hasn't been initialized yet.
          if (settings.marker.isotope) {
            objectQueue.queue('item', function (next) {
              self.length
                && !self.data('isotope')
                && self.data('isotope-options')
                && self.isotope(self.data('isotope-options'));

              next();
            });
          }

          AjaxData.content
          && AjaxData.content.action
          && $.each(AjaxData.content.action, function (key, data) {

            objectQueue.queue('item', function (next) {
              self.find('.property-search-group').remove();
              next();
            });

            var content = $(data.content.replace(/(\r\n|\n|\r)/gm, ""));
            objectQueue.queue('item', function (next) {
              $(content).insertAfter(self.find('.property-search-type-selector-form'));
              next();
            });

            if (settings.marker.isotope) {
              objectQueue.queue('item', function (next) {
                self.isotope('appended', $(content));
                next();
              });

              objectQueue.queue('item', function (next) {
                self.isotope('layout');
                next();
              });
            }

          });

          // Queue finishing steps
          objectQueue.queue('item', function (next) {
            self
              .data('ajax-stop', false)
              .removeClass('ajax-processing')
              .trigger('property-search-type-change-ajax-processed');

            next();
          });

          // Process the queued item
          objectQueue.dequeue('item');

          break;

        case 'wpterms-hs' :

          if (typeof IsoTimer != 'undefined') {
            clearTimeout(IsoTimer);
          }

          var IsoTimer = setTimeout(function() {
            $('.property-search-forms.js-isotope').each(function() {
              $(this).data('isotope') && $(this).isotope('layout');
            })
          }, 100);

          break;
      }

    })

    // Wploop combined with search element
    .on('click.ajax-search', '[data-ajax-type="property-search"]', function (e) {

      var self = $(this),
        target = $('[data-arrival="' + self.data('destination') + '"]'),
        pager = $('[data-ajax-type="pager"][data-destination="' + self.data('destination') + '"]');

      if (target.length) {
        e.preventDefault();
        target
          .data('paged', 1)
          .data('property-search', $.param(self.closest('form').serializeArray(), true))
          .data('pagedContext', pager.data('context'))
          .trigger('doajax');

        //  .data('ajax-stop', true);

        $('html, body').animate({
          scrollTop: target.offset().top - ($(window).height() * 0.20)
        }, 2000);
      }

      // No valid target fallback to normal element
      else {
        return true;
      }
    })

    // Google Maps combined with search element
    .on('click.ajax-maps', '[data-ajax-type="property-maps"]', function (e) {

      var self = $(this),
        target = $('[data-ajax-target="' + self.data('target') + '"]');

      if (target.length) {
        e.preventDefault();
        target
          .data('pager', self.data('pager'))
          .data('property-search', $.param(self.closest('form').serializeArray(), true))
          .trigger('doajax');

          // Not sure why this is not working?
          // .data('ajax-stop', true);
      }

    });

})(jQuery)


