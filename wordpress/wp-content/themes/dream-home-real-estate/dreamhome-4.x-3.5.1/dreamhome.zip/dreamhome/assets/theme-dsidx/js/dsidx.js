/**
 * Additional javascript for dsidx display
 * 
 * @author jason.xie@victheme.com
 */
jQuery(document).ready(function ($) {
 
  "use strict";
  
  // Build the grid mode for dsidx
  //$('.template-dsidx-grid')
  //  .find('#dsidx-listings > li:not(.dsidx-listing)')
  //  .remove();
  
  $('.template-dsidx-grid')
    .find('#dsidx-listings > li')
    .each(function() {
      $(this)
        .addClass('item')
        .addClass($(this).closest('.template-dsidx-grid').data('grids'))
        //.removeClass('dsidx-listing')
        .children()
        .addClass('clearfix');
        //.wrapAll('<div class="dsidx-listing clearfix" />');
    });
  
  
  $('.template-dsidx-grid')
    .find('#dsidx-listings')
    .addClass('row js-isotope')
    .data('isotope-options', {
      layoutMode : 'fitRows',
      itemSelector : '.item',
      fitRows : {
        equalheight: true,
        gutter: {
          width: 0,
          height: 0
        }
      },
      resizeDelay : 300,
    })
    .isotope({
      layoutMode : 'fitRows',
      itemSelector : '.item',
      fitRows : {
        equalheight: true,
        gutter: {
          width: 0,
          height: 0
        }
      },
      resizeDelay : 300
    });
  

  // Boot form eye candy
  if ($('#page.jvfloat').length) {
    $('.dsidx-widget-guided-search').find('input').not(':checkbox, :radio, :submit, :reset, :hidden, .jvprocessed').each(function() {
      var self = $(this), label = self.parent().find('label[for="' + self.attr('name') + '"]');

      if (label.length) {
        self.attr('placeholder', label.text());
        label.remove();
        self.jvFloat().addClass('jvprocessed');
      }
    });

    $('.dsidx-widget-guided-search').find('select > option[value=""]').each(function() {
      $(this).text('- ' + $(this).parent().parent().find('label').text() + ' -');
      $(this).parent().parent().find('label').remove();
    });
  }

  $('.dsidx-widget-single-listing-photo').each(function() {
    $(this).width($(this).closest('.dsidx-widget-single-listing-photos').width());
  });
  
  $('#dsidx-media').each(function() {
    $(this).width($(this).parent().width());
  });
  
  
  $(window)
    .on('resize', function() {
      
      $('.dsidx-widget-single-listing-photo').each(function() {
        $(this).width($(this).closest('.dsidx-widget-single-listing-photos').width());
      });
      
      $('#dsidx-media').each(function() {
        $(this).width($(this).parent().width());
      });
    });
  
});
