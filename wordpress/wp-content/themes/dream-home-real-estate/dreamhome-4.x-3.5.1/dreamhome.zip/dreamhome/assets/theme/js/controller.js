/**
 * 
 * The main theme controller javascript.
 * This file will load and configure other
 * javascript settings related to the theme.
 * 
 * @author jason.xie@victheme.com
 */
jQuery(document).ready(function ($) {
 
  "use strict";

  var VT = {
    $page: $('#page')
  };

  VT.$page.mode = 'desktop';
  if ($(window).width() < 769) {
    VT.$page.mode = 'mobile';
  }

  // Dont initialize parallax on mobile or tablet!
  if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|BB|PlayBook|IEMobile|Windows Phone|Kindle|Silk|Opera Mini/i.test(navigator.userAgent)) {
    $(window).off('scroll.parallax');
    VT.$page.mode = 'mobile';
    //VT.$page.find('.parallax').removeClass('parallax');
  }

  VT.$page.addClass('view-mode-' + VT.$page.mode);
  VT.$page.width = $(window).innerWidth();

  // Booting jvfloat
  // Run this early to prevent jumping
  VT.jvFloat = function() {
    $(document).find('input, textarea, select')
      .not(':checkbox, :radio, :submit, :reset, :hidden, .jvprocessed, .bs-toggle-processed')
      .each(function () {
        var self = $(this),
          label = self.closest('.form-group').children().filter('label');

        // Don't process bs-toggle elements
        if (self.hasClass('form-control') && self.parent().data('toggle-label')) {
          return true;
        }

        if (label.length) {
          self.attr('placeholder', label.text());
          label.hide();
          self.jvFloat().addClass('jvprocessed');
        }
      });

    $('.wp-termshs').each(function () {
      if (!$(this).data('toggle-label')) {
        $(this).find('label').eq(0).hide();
      }
    });
  }
  if (VT.$page.hasClass('jvfloat') && VT.$page.find('input, textarea, select').length) {
    VT.jvFloat();
  }

  /**
   * Window events
   */
  $(window)
    .on('load', function() {

      // Piggy backing to pageready event
      if (!$('#page.animsition').length) {
        setTimeout(function() {
          $(window).trigger('pageready');
        }, 10);
      }

    })

  /**
   * Page Ready will be called after animsition
   * or if animsition not enabled after window load
   * event.
   */
    .on('pageready', function() {

      // Force VC to relayout row
      if (typeof window.vc_rowBehaviour == 'function') {
        window.vc_rowBehaviour()
      }

      // Booting EqualheightRow Element
      if (VT.$page.find('.equalheightRow').length) {
        VT.equalheight = {
          init: function() {
            this.$el = VT.$page.find('.equalheightRow');
            this.reposition();
          },
          reposition: function() {
            this.$el.resetEqualHeight(800);
          }
        }

        VT.equalheight.init();
      }

      // Booting scroll animation
      if (VT.$page.find('.scroll-animated').length) {
        VT.scrollAnimated = {
          init: function() {
            this.$el = VT.$page.find('.scroll-animated');
            return this;
          },
          revealAll: function() {
            this.$el
              .addClass($(this).data('animation'))
              .removeClass('scroll-animated')
              .addClass('scroll-animated-completed');
            return this;
          },
          reposition: function() {
            this.$el.filter(':not(.scroll-animated-completed)').filter(':in-viewport').each(function () {
              $(this)
                .addClass($(this).data('animation'))
                .removeClass('scroll-animated')
                .addClass('scroll-animated-completed');
            });

            return this;
          },
          reset: function() {
            this.$el.filter('.scroll-animated-completed').each(function () {
              $(this)
                .removeClass($(this).data('animation'))
                .addClass('scroll-animated')
                .removeClass('scroll-animated-completed');
            });
            return this;
          }
        }

        VT.scrollAnimated.init();

        if (VT.$page.mode == 'mobile') {
          VT.scrollAnimated && VT.scrollAnimated.revealAll();
        }
      }

      // Booting data aspect
      if (VT.$page.find('[data-aspect="true"]').length) {
        VT.$page.find('[data-aspect="true"]').VTCoreAspectRatio();
      }

      // Booting sticky header
      if (VT.$page.hasClass('with-sticky')) {

        VT.sticky = {
          init: function () {
            this.$sticky = VT.$page.find('#header');

            this.$sticky.hcSticky({
              top: -1,
              responsive: false,
              onStart: function () {
                VT.sticky.reposition();
              },
              onStop: function () {
                setTimeout(function() {
                  VT.sticky.reposition();
                }, 100);
                VT.sticky.reposition();
              },
              offResolutions: -640
            });
            return this;
          },
          reposition: function () {

            this.$sticky
              .parent()
              .height(this.$sticky.outerHeight());

            var that = this;

            this.$sticky
              .find('.vertical-target')
              .each(function () {
                that.$sticky
                  .vertCentCentering($(this), $(this).data('vertical-offset'));
              });

            this.$sticky.find('.js-isotope').isotope('layout');
            VT.slick && VT.slick.reposition();
            return this;
          },
          off: function () {
            this.$sticky.hcSticky('off');
            return this;
          },
          on: function () {
            this.$sticky.hcSticky('on');
          },
          reinit: function() {
            this.$sticky.hcSticky('reinit');
            return this;
          }
        }

        VT.sticky.init();
      }

      // Booting slick nav menu
      if (VT.$page.hasClass('with-slicknav')) {

        VT.slick = {
          init: function () {
            this.targetClass = '.slicknav';
            this.autoFormat = VT.$page.hasClass('with-auto-menu-shrink');
            this.$slick = VT.$page.find('#header ' + this.targetClass);
            this.$slick
              .addClass('slicknav-source')
              .slicknav({
                label: '',
                prependTo: '',
                appendTo: '#header',
                open: function () {
                  VT.$page.addClass('slicknav-open');
                  ($(window).width() < 640) && VT.sticky && VT.sticky.off();
                },
                close: function () {
                  VT.$page.removeClass('slicknav-open');
                  ($(window).width() > 640) && VT.sticky && VT.sticky.on();
                }
              });

            this.processSlick();

            return this;
          },
          checkParentVisibility: function(element) {
            if (element.parent().is(':hidden')) {
              return this.checkParentVisibility(element.parent());
            }

            return element;

          },
          processSlick: function() {
            this.slickElements = {};
            var that = this;
            this.$slick.each(function() {
              var delta = $(this).data('slick-source'),
                clone = $(this).clone(),
                self = $(this),
                hiddenParent = false,
                maxwidth = 0,
                maxheight = 0;

              if (self.parent().is(':hidden')) {
                hiddenParent = that.checkParentVisibility(self.parent());
              }

              clone
                .css({
                  position: 'absolute',
                  visibility: 'hidden',
                  display: 'table',
                  zIndex: -1,
                  width : '100%',
                  height: '',
                  maxWidth : '',
                  maxHeight: ''
                });

              $(this).parent().append(clone);

              // Don't use .css() we need the !important rules!
              hiddenParent
              && hiddenParent
                .attr('style', 'display: table !important; visibility: hidden !important; position: absolute;');

              // Loop and count each width and height manually for
              // stable output!
              clone.children().each(function() {
                maxwidth += $(this).outerWidth();
                maxheight += $(this).outerHeight();
              });

              that.slickElements[delta] = {
                source: self,
                target: VT.$page.find('[data-slick-target="' + delta + '"]'),
                delta: delta,
                width: maxwidth,
                height: maxheight,
                container: self.parent()
              }

              hiddenParent && hiddenParent.removeAttr('style');

              clone.remove();

            })
          },
          format: function () {
            VT.$page.find('.slicknav_nav')
              .find('.dropdown, .dropdown-menu, .dropdown-toggle')
              .removeClass('dropdown dropdown-menu dropdown-toggle');

            VT.$page.find('.slicknav_nav')
                .addClass('container-fluid')
              .find('.caret').remove();

            VT.$page.find('.slicknav_nav').wrap('<div class="container-fluid"/>');
            VT.$page.find('#header > .container-fluid').append('<div class="slick-positioning"></div>');

            this.reposition();

            return this;
          },
          reposition: function () {
            this.topPos = (VT.$page.find('#header').outerHeight() - VT.$page.find('.slicknav_btn').outerHeight()) / 2;
            VT.$page.find('.slicknav_btn').css('top', this.topPos);

            if (VT.$page.find('#header .slick-positioning').length) {
              this.leftPos = VT.$page.find('#header .slick-positioning').offset().left;
              VT.$page.find('.slicknav_btn').css('left', this.leftPos);
            }
            return this;
          },
          ubermenu: function() {
            VT.$page.find('#megaUber').addClass('slicknav');
            return this;
          },
          detectVisibility: function() {

            if (!this.autoFormat){
              return;
            }

            !this.slickElements && this.processSlick();

            var that = this;
            $.each(this.slickElements, function(delta, slick) {
              // Container cannot hold the menu fire slick
              if (slick.container.innerWidth() < slick.width || VT.$page.mode == 'mobile') {
                slick.source.hide();
                slick.target.show();
              }
              // Container is wide enough for menu remove slick
              else {
                slick.source.show();
                slick.target.hide();
              }

              setTimeout(function() {
                VT.sticky && VT.sticky.reposition();
              }, 300);
            });

            VT.$page.addClass('menu-auto-formatted');

            return this;
          }
        }

        VT.slick.ubermenu().init().format().detectVisibility().reposition();
        VT.sticky && VT.sticky.reposition();

      }

      // Booting SmoothScroll
      if (VT.$page.mode == 'desktop') {
        if (VT.$page.find('a[href*="#"]').length) {
          VT.$page.find('a[href*="#"]').each(function () {
            // Only smoothscroll on valid target
            if ($($(this)[0].hash.substr(1)).length) {
              $(this).smoothScroll();
            }
          });
        }
      }

      // Saw Effect Element
      if (VT.$page.hasClass('with-saw-effect')) {
        VT.SawEffects = {
          init: function() {
            VT.$page.find('#header, #headline, #postface, .wrapper-sticky').addClass('saw-effect');
            this.$el = VT.$page.find('.saw-effect');
            return this;
          },
          reposition: function() {

            var cssRule = '';

            this.$el.each(function(delta, value) {
              var color = $(this).css('background-color'),
                prefixes = [
                  '-moz-',
                  '-webkit-',
                  '-o-',
                  ''
                ],

                self = $(this),
                id = 'saw-effect-element-' + delta,
                selector = '[data-saw-effect="' + id + '"]';

              if (!color || color == 'transparent') {
                color = self.parent().css('background-color');
              }
              self.attr('data-saw-effect', id);
              cssRule += '#page.with-saw-effect ' + selector + ':after {\n';
              $.each(prefixes, function (key, prefix) {
                cssRule += 'background: ' + prefix + "linear-gradient(45deg, transparent 33.333%," + color + " 33.333%, " + color + " 66.667%, transparent 66.667% ),"
                  + prefix + "linear-gradient(-45deg, transparent 33.333%, " + color + " 33.333%, " + color + " 66.667%, transparent 66.667% );\n";
              });
              cssRule += '}\n';

            });

            if (cssRule.length != 0) {
              $('<style id="saw-effect-dynamic-css" type="text/css">' + cssRule + '</style>').appendTo(document.head);
            }

            return this;
          }
        }

        VT.SawEffects.init().reposition();
      }

      // Fix counter up kill vc animation
      if (VT.$page.find('.wpb_animate_when_almost_visible:not(.wpb_start_animation)').length
        && typeof jQuery.fn.waypoint3 !== 'undefined') {
        VT.$page.find('.wpb_animate_when_almost_visible:not(.wpb_start_animation)').waypoint3(function () {
          $(this).addClass('wpb_start_animation');
        }, { offset:'85%' });
      }

      // Offsetting maps center for agents profile maps
      if (VT.$page.find('#agents-profile-contact').find('.googlemaps-instances').length) {
        VT.agentMaps = {
          init: function() {
            this.$agentMaps = VT.$page.find('#agents-profile-contact').find('.googlemaps-instances');
            return this;
          },
          reposition: function() {
            this.$agentsMaps && this.$agentsMaps.each(function() {
              $.goMap = $(this).data('goMap');
              $.goMap.panBy($(this).width() * 0.20, 0);
            });
            return this;
          }
        }

        VT.agentMaps.init().reposition();
      }

      // Formatting the content bottom
      if (VT.$page.find('#content-bottom').length) {
        if (VT.$page.find('#content-bottom')
            .find('.widget:eq(0)')
            .find('.template-agents-custom-single-photo')
            .length) {

          VT.$page.find('#content-bottom').addClass('drop-background');
        }
      }

      // Booting nicescroll
      if (VT.$page.hasClass('with-nicescroll') && VT.$page.mode == 'desktop') {
        VT.MainNiceScroll = {
          init: function() {
            this.$mainNiceScroll = $('html');
            this.options = VT.$page.data('nicescroll');
            this.options.scrollID = 'mainScroll';
            this.$mainNiceScroll.niceScroll(this.options);
            return this;
          },
          reposition: function() {
            this.$mainNiceScroll.getNiceScroll().resize();
            return this;
          },
          lock: function(val) {
            this.$mainNiceScroll.getNiceScroll()[0].locked = val;
          }
        }

        VT.NiceScroll = {
          init: function() {
            this.$niceScroll = VT.$page.find('.nicescroll');
            this.$niceScroll.each(function() {
              $(this).niceScroll($(this).data('nicescroll'));
            });
          },
          reposition: function() {
            this.$niceScroll.each(function() {
              $(this).getNiceScroll().resize();
            });
          }
        }

        VT.MainNiceScroll.init();
        VT.NiceScroll.init();

        // Force to rebuild the AdaptiveHeadline
        VT.AdaptiveHeadline && VT.AdaptiveHeadline.reposition();
      }

      // Booting offcanvas
      if (VT.$page.hasClass('with-offcanvas') && jVette) {
        VT.offCanvas = {
          init: function() {
            this.options = VT.$page.data('offcanvas');
            this.object = jVette(this.options);

            this.object
              .on('open', function() {
                VT.MainNiceScroll && VT.MainNiceScroll.lock(true);
              })
              .on('close', function() {
                VT.MainNiceScroll && VT.MainNiceScroll.lock(false);
              });


            this.$panels = $('.jv-panel');
            VT.$page.hasClass('with-nicescroll') && this.$panels.each(function() {
              $(this).children().length && $(this).niceScroll($(this).find('[data-jv-content]').eq(0).data('nicescroll'));
            });

            return this;
          },
          reposition: function() {
            VT.$page.hasClass('with-nicescroll') && this.$panels.each(function() {
              $(this).find('.block-content').getNiceScroll().resize();
            });
          }
        }

        VT.offCanvas.init();
      }

    })


    .on('scroll', function() {
      if (VT.$page.mode == 'desktop') {
        VT.scrollAnimated && VT.scrollAnimated.reposition();
      }
    })

    .on('resize', function() {

      VT.ResizeTimer && clearTimeout(VT.ResizeTimer);

      VT.ResizeTimer = setTimeout(function() {

        // Trully change window size
        // @performance for mobile as every scroll down will trigger resize!
        if (VT.$page.window !== $(window).innerWidth()) {
          // Initialize equalheight
          VT.equalheight && VT.equalheight.reposition();

          // Reinit Sticky header
          VT.sticky && VT.sticky.reinit();

          // Reposition Slick
          VT.slick && VT.slick.detectVisibility();

          // Record the new window width
          VT.$page.window = $(window).innerWidth();
        }

      }, 60);

    })

    .on('vtcore-maps-ready', function() {

      $('.property-tabbed-content .nav-tabs a')
        .on('click.resizemaps', function() {
          setTimeout(function() {

            var Maps = $('.property-tabbed-content').find('.googlemaps-instances');
            Maps
              .VTCoreResizeMaps();

            $.goMap = Maps.data('goMap');
            $.goMap.clearInfo();
          }, 600);
        });
    });


  $(document)
    .on('animsitionPageIn', function() {

      // Piggy backing to page ready event
      $(window).trigger('pageready');
    })

    // Fixing portfolio
    .on('layoutComplete', function() {
      VT.scrollAnimated && VT.scrollAnimated.init() && VT.scrollAnimated.reposition();
    })

    .on('ajaxComplete', function() {

      // Refresh content
      VT.scrollAnimated && VT.scrollAnimated.init() && VT.scrollAnimated.reposition();

      // Boot form eye candy
      if ($('#page.jvfloat').length) {
        VT.jvFloat();
      }

      // Reformat the main scroller
      VT.MainNiceScroll && VT.MainNiceScroll.reposition();

    })
    // Hacking to jvette to allow for per button select
    // different content on same panel
    .on('click', '[data-jv-trigger]', function(e) {

      e.preventDefault();

      var self = $(this);
      self.data('jv-source') && $('[data-jv-panel="' + self.data('jv-trigger') + '"]')
        .children()
        .hide()
        .filter('[data-jv-target="' + self.data('jv-source') + '"]')
        .show();

    })
    // Split search toggle button
    .on('click.property-split-advanced-toggle', '.property-split-search-toggle-button', function() {
      setTimeout(function() {
        $(window).trigger('scroll');
      }, 401)
    })
    .on('equalheight-reset', '.template-agents-custom-inline-photo', function() {
      $(this).removeClass('theme-initialized');
    })
    .on('equalheight-complete', '.template-agents-custom-inline-photo', function() {
      $(this).addClass('theme-initialized');
    });

 });
