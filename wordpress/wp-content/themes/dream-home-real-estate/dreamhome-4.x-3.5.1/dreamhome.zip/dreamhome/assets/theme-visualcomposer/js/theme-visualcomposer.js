/**
 * 
 * Integrating to VisualComposer
 * 
 * @author jason.xie@victheme.com
 */
(function ($) {

  $(window)
    .on('vc_ready', function() {

      // jQuery Slick Carousel
      // @note Dont allow the infinite mode at all cost!.
      //       infinite mode will create cloned item and broke the VC button!.
      window.InlineShortcodeView_vagentslisting = window.InlineShortcodeView.extend({
        changed: function () {
          this.$el.find('.slick-initialized').unslick();
          var data = this.$el.find('.slick-carousel').data('settings');
          data.vcMode = true;
          data.infinite = false;
          data.autoplay = false;

          $(this.$el).find('.slick-carousel').slick(data);
          return this;
        }
      });
    });

 })(window.jQuery);
