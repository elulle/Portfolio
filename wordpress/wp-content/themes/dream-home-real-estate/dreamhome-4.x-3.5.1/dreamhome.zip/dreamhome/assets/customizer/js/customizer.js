/**
 * Live preview js for customizer.
 *
 * This js script must be loaded via hook
 * customizer_preview_init action or
 * it wont work!.
 *
 * The assets dependencies are :
 * 1. jquery-deparam
 * 2. wp-gradientpicker
 *
 * must be loaded first before this script
 * to avoid missing function error.
 *
 * @author jason.xie@victheme.com
 * @see VTCore_Wordpress_Customizer_Element_Grid
 * @see VTCore_Wordpress_Customizer_Element_Hidden
 * @see VTCore_Wordpress_Customizer_Element_Gradient
 * @see VTCore_Wordpress_Form_WpGradient
 * @see VTCore_Zeus_Customizer_Factory
 * @see VTCore_Zeus_Schema_Color
 */
(function($) {

  var VTCoreCustomizerGrids = function () {}
  VTCoreCustomizerGrids.prototype = {
    init: function(target, key, value) {
      this.target = $(target);
      this.key = key;
      this.value = value;
      this.eMatch = false;
      this.cssMode = false;
      this.eMode = false;
      this.eSize = false;
      this.classes = false;

      return this;
    },
    updateValue: function(value) {
      this.value = value;
      return this;
    },
    getClass: function () {
      if (this.target.attr('class')) {
        this.classes = this.target.attr('class').split(' ');
      }
      return this;
    },
    cleanClass: function () {
      if (this.classes && this.cssMode) {
        var that = this;
        $.each(this.classes, function (delta, stringClasses) {
          if (stringClasses.indexOf(that.cssMode) != -1) {
            that.target.removeClass(stringClasses);
          }
        });
      }
      return this;
    },
    newClass: function () {
      if (this.cssMode && this.value) {
        this.target.addClass(this.cssMode + this.value);
      }
      return this;
    },
    reLayout: function () {
      if (this.target.parent().hasClass('js-isotope') && this.target.parent().data('isotope')) {
        this.target.parent().isotope('layout');
      }
      return this;
    },
    processPrefix: function () {
      if (this.key) {
        this.eMatch = this.key.replace('regions[', '').replace(/\]\[/g, '.').replace(']', '').split('.').reverse();
      }
      if (this.eMatch) {
        this.eSize = this.eMatch[0];
        this.eMode = this.eMatch[1];

        switch (this.eMode) {
          case 'columns':
          case 'push' :
          case 'pull' :
          case 'offset' :
            this.cssMode = 'col-';
            break;

          case 'hidden' :
            this.cssMode = 'hidden-';
            break;

          case 'visible' :
            this.cssMode = 'visible-';
            break;
        }

        switch (this.eSize) {
          case 'mobile' :
            this.cssMode += 'xs-';
            break;
          case 'tablet' :
            this.cssMode += 'sm-';
            break;
          case 'small' :
            this.cssMode += 'md-';
            break;
          case 'large' :
            this.cssMode += 'lg-';
            break;
        }

        switch (this.eMode) {
          case 'push' :
            this.cssMode += 'push-';
            break;
          case 'pull' :
            this.cssMode += 'pull-';
            break;
          case 'offset' :
            this.cssMode += 'offset-';
            break;
        }
      }

      return this;
    },
    process: function() {
      this.processPrefix().getClass().cleanClass().newClass().reLayout();
    }
  }

  var API = window.parent.wp.customize,
      Settings = API.settings.settings,
      Controls = API.settings.controls;

  // Initialize binding
  $.each(Settings, function(key, val) {

    // Force Refresh loaded schema when user change schema
    if (key == 'schema-active') {
      API(key, function(value) {

        value.bind(function (newval) {

          var url = window.ajaxurl || window.parent.wp.ajax.settings.url;

          // Refresh schema
          $.ajax({
            url: url,
            type: 'POST',
            cache: false,
            data: {
              action: 'color_customizer',
              colorSelects: newval
            },
            dataType: 'json',
            /**
             beforeSend: function (arr, $form, options) {
              //NoticeBox.fadeIn();
            },
             complete: function (arr, $form, options) {
              //NoticeBox.fadeOut();
            },
             **/
            success: function (response, status) {

              $.each(response, function (parent, arrays) {
                var key = 'schemas[color][' + parent + ']';
                $.each(arrays, function (child, newColor) {

                  if (child != 'selectors' && child != 'title' && child != 'description') {
                    var control = API.control.instance(key + '[' + child + ']');

                    if (typeof control != 'undefined'
                        && typeof control.setting != 'undefined') {

                      control.setting.set(newColor);

                      // Update the color picker
                      if (typeof control.container != 'undefined'
                          && typeof control.container.children().data('colorpicker') != 'undefined') {
                        control.container.children().data('colorpicker').setValue(newColor);
                      }

                    }

                  }
                });

                API.previewer.refresh();
              });

            }
          });

        });
      });
    }

    // Processing grids
    if (key.indexOf('regions[') != -1
        && typeof Controls[key] != 'undefined') {

      API(key, function(obj) {

        obj.bind(function (newval) {
          if (!obj.VTCoreGrid) {
            obj.VTCoreGrid = new VTCoreCustomizerGrids();
          }

          if (Controls[key]['pointer']
            && Controls[key]['pointer'].target) {

            var Grid = new VTCoreCustomizerGrids();
            Grid
              .init(Controls[key]['pointer'].target, key, newval)
              .process();

            Grid = null;
            delete(Grid);
          }
        });
      });
    }




    // Processing color schema items
    if (key.indexOf('schemas[color]') != -1) {

      var pointer = Controls[key]['pointer'],
          type = Controls[key]['type'];

      API(key, function(value) {
        value.bind(function(newval) {

          // Convert image to css valid value
          if (pointer.rules == 'background-image') {
            newval = 'url(' + newval + ')';
          }

          // Inject google fonts
          if (pointer.rules == 'font-family' && newval.indexOf(',') == -1) {
            var id = newval.split('+').join('-');
            if ($("head").find('#vtcore-customizer-' + id).length == 0) {
              $("head").append('<link id="vtcore-customizer-' + id + '" href="http://fonts.googleapis.com/css?family=' + newval + '&subset=latin,cyrillic-ext,cyrillic,greek-ext,greek,vietnamese,latin-ext" rel="stylesheet" type="text/css">"');
            }

            newval = '"' + newval.split('+').join(' ') + '"';
          }

          // Support for gradient + WpGradient object
          if (type == 'gradient') {

            var query = [];
            $.each($.parseJSON(newval), function(key, object) {
              query.push(object.name.replace('[gradient]', 'gradient') + '=' + encodeURIComponent(object.value));
            });

            // Depends on jquery-deparam assets
            query = $.fn.deparam(query.join('&'));

            if (typeof query.gradient != 'undefined') {
              // Depends on wp-gradientpicker assets
              $(pointer.target).VTCoreGradient(query.gradient);
            }
          }
          // Other elements
          else {
            $(pointer.target).css(pointer.rules, newval);
          }

        });

      });
    }

  });

})(jQuery);
