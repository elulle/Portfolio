/**
 * Javascript for bridging between the search
 * elements to wploop object
 */
(function($) {

  $(document)

    // Generic functions
    .on('ready.property', function() {
      $('html').addClass('js').removeClass('no-js');
    })

    // Fix the z-index problem on bootstrap dropdown element
    // such as bootstrap-select and bootstrap-datepicker
    .on('show.bs.dropdown hide.bs.dropdown', function(event) {

      if (!event.target || !event.type) {
        return;
      }

      var element = $(event.target);
      if (element.hasClass('js-datepicker') || element.hasClass('bootstrap-select')) {
        var propertyGroup = element.closest('.agents-search-group');
        if (propertyGroup.length) {
          switch (event.type) {
            case 'show' :
              propertyGroup.addClass('group-active');
              break;

            case 'hide' :
              propertyGroup.removeClass('group-active');
              break;
          }
        }
      }
    })

    // Wploop combined with search element
    .on('click.ajax-search', '[data-ajax-type="agents-search"]', function(e) {

      var self = $(this),
          target = $('[data-arrival="' + self.data('destination') + '"]'),
          pager = $('[data-ajax-type="pager"][data-destination="' + self.data('destination') + '"]');


      if (target.length) {
        e.preventDefault();
        target
          .data('paged', 1)
          .data('agents-search', $.param(self.closest('form').serializeArray(), true))
          .data('pagedContext', pager.data('context'))
          .trigger('doajax')
          .data('ajax-stop', true);

        $('html, body').animate({
          scrollTop: target.offset().top - ($(window).height() * 0.20)
        }, 2000);
      }

      // No valid target fallback to normal element
      else {
        return true;
      }
    })

    // Google Maps combined with search element
    .on('click.ajax-maps', '[data-ajax-type="agents-maps"]', function(e) {

      var self = $(this),
          target = $('[data-ajax-target="' + self.data('target') + '"]');

      if (target.length) {
        e.preventDefault();
        target
          .data('pager', self.data('pager'))
          .data('agents-search', $.param(self.closest('form').serializeArray(), true))
          .trigger('doajax')
          .data('ajax-stop', true);

        $('html, body').animate({
          scrollTop: target.offset().top - ($(window).height() * 0.20)
        }, 2000);

      }

    });

})(jQuery)