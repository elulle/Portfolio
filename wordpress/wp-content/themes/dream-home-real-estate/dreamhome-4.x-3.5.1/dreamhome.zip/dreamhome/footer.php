<?php
/**
 * Footer Templates
 * @author jason.xie@victheme.com
 */
?>

<?php get_sidebar('content_bottom'); ?>
<?php get_template_part('sidebar', 'postface'); ?>


<?php if (VTCore_Zeus_Utility::isActiveSidebar('footerone')
  || VTCore_Zeus_Utility::isActiveSidebar('footertwo')
  || VTCore_Zeus_Utility::isActiveSidebar('footerthree')
  || VTCore_Zeus_Utility::isActiveSidebar('footerfour')
) : ?>

  <footer id="footer" class="area inverse">
    <div class="container-fluid">
      <div class="row">


        <?php if (VTCore_Zeus_Utility::isActiveSidebar('footerone')) : ?>
          <div id="footer-one"
               class="region <?php echo VTCore_Zeus_Utility::getColumnSize('footerone'); ?>">
            <?php dynamic_sidebar('footerone'); ?>
          </div>
        <?php endif; ?>



        <?php if (VTCore_Zeus_Utility::isActiveSidebar('footertwo')) : ?>
          <div id="footer-two"
               class="region <?php echo VTCore_Zeus_Utility::getColumnSize('footertwo'); ?>">
            <?php dynamic_sidebar('footertwo'); ?>
          </div>
        <?php endif; ?>



        <?php if (VTCore_Zeus_Utility::isActiveSidebar('footerthree')) : ?>
          <div id="footer-three"
               class="region <?php echo VTCore_Zeus_Utility::getColumnSize('footerthree'); ?>">
            <?php dynamic_sidebar('footerthree'); ?>
          </div>
        <?php endif; ?>


        <?php if (VTCore_Zeus_Utility::isActiveSidebar('footerfour')) : ?>
          <div id="footer-four"
               class="region <?php echo VTCore_Zeus_Utility::getColumnSize('footerfour'); ?>">
            <?php dynamic_sidebar('footerfour'); ?>
          </div>
        <?php endif; ?>


        <?php if (VTCore_Zeus_Init::getFactory('features')->get('show.footer.fullfooter')) : ?>
          <div id="fullfooter"
               class="region col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center vertical-center">
            <div id="copyright"
                 class="region vertical-target <?php echo VTCore_Zeus_Utility::getColumnSize('copyright'); ?>"
                 data-vertical-offset="0">

              <p
                class="copyright"><?php echo VTCore_Zeus_Utility::getFooter('copyrighttext'); ?></p>
            </div>
          </div>
        <?php endif; ?>

      </div>
    </div>
  </footer>
<?php endif; ?>


</div>

<?php wp_footer(); ?>

</body>
</html>

