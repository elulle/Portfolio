<?php
/**
 * Main Comment Template
 *
 * @author jason.xie@victheme.com
 */
?>
<?php wp_enqueue_script("comment-reply"); ?>
<?php // Post got password required ?>
<?php if (post_password_required()) : ?>
  <div class="alert alert-info">
    <?php _e("This post is password protected. Enter the password to view comments.", 'dreamhome'); ?>
  </div>
  <?php return; ?>
<?php endif; ?>

<?php
$show = 'full';
if (is_singular('page')) {
  $show = 'page';
}
?>

<?php // Build the comments if user configured to do so.?>
<?php if (VTCore_Zeus_Init::getFactory('features')->get('show.' . $show . '.comments')) : ?>
  <section class="post-comment post-section clearfix">

    <?php // Commenting is open for user?>
    <?php if (have_comments()) : ?>

      <header>
        <h1 class="post-section-title">
          <?php echo __('Comments', 'dreamhome'); ?>
        </h1>
      </header>


      <ul class="media-list">
        <?php wp_list_comments(array(
          'style' => 'ul',
          'short_ping' => TRUE,
          'avatar_size' => 86,
          'format' => 'html5',
          'callback' => array('VTCore_Zeus_Utility', 'getComment'),
        ));
        ?>
      </ul>


      <?php if (get_comment_pages_count() > 1 && get_option('page_comments')) : ?>
        <nav id="comment-nav">
          <?php previous_comments_link('<span class="btn">' . __('Older comments', 'dreamhome') . '</span>'); ?>
          <?php next_comments_link('<span class="btn">' . __('Newer comments', 'dreamhome') . '</span>'); ?>
        </nav>
      <?php endif; ?>

    <?php endif; ?>

    <?php // Commenting is not open for user ?>
    <?php if (!comments_open()) : ?>
      <p class="alert alert-info">
        <?php echo __('Comments are closed', 'dreamhome'); ?>
      </p>
    <?php endif; ?>


  </section>
<?php endif; ?>

<?php // Display the comment form if configured by user to do so. ?>
<?php if (VTCore_Zeus_Init::getFactory('features')->get('show.' . $show . '.comment_form') && comments_open()) : ?>
  <section class="comment-form post-section clearfix">
    <header>
      <h1 class="post-section-title">
        <?php echo __('Comment Form', 'dreamhome'); ?>
      </h1>
    </header>

    <?php VTCore_Zeus_Utility::getCommentForm(array()); ?>

  </section>
<?php endif; ?>