DreamHome Premium Theme
===================

author : jason.xie @victheme.com

DreamHome is a premium theme made by VicTheme.com, for full
documentation please visit http://documentation.victheme.com/dreamhome


Update Log
==========

Version 1.0
- Initial pre-release version