<?php
/**
 * Dsidx single entry template
 *
 * @author jason.xie@victheme.com
 */

VTCore_Wordpress_Utility::loadAsset('theme-dsidx');

?>
<?php get_header(); ?>

  <div id="maincontent" class="area clearfix">
    <div class="container-fluid">
      <div class="row">

        <div id="content"
             class="region
			     <?php if (VTCore_Zeus_Utility::getSidebar('dsidx-page')) {
               echo VTCore_Zeus_Utility::getColumnSize('content');
             } ?>
			     with-sidebar-<?php echo VTCore_Zeus_Utility::getSidebar('dsidx-page'); ?>">

          <?php
          while (have_posts()) {
            // Build the single post entry using main loop
            the_post();
            get_template_part('templates/dsidx/page');
          }
          ?>
        </div>

        <?php
        // Build sidebar.
        if (VTCore_Zeus_Utility::getSidebar('dsidx-page') == 'right'
          || VTCore_Zeus_Utility::getSidebar('dsidx-page') == 'left'
        ) {
          get_sidebar('sidebar');
        }
        ?>

      </div>
    </div>
  </div>


<?php get_footer(); ?>