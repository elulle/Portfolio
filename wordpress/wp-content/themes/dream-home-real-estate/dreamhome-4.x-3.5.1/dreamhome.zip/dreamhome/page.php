<?php
/**
 * Default Page single template
 *
 * @author jason.xie@victheme.com
 */
?>
<?php get_header(); ?>

  <div id="maincontent" class="area clearfix">
    <div class="container-fluid">
      <div class="row">

        <div id="content"
             class="region
			     <?php if (VTCore_Zeus_Utility::getSidebar('page')) {
               echo VTCore_Zeus_Utility::getColumnSize('content');
             } ?>
			     with-sidebar-<?php echo VTCore_Zeus_Utility::getSidebar('page'); ?>"
          >

          <?php

          while (have_posts()) {

            // Build the single post entry using main loop
            the_post();
            get_template_part('templates/content/page', get_post_format());

            // Retrieves Pager
            $pager = VTCore_Zeus_Utility::getPostPager();
            if (!empty($pager)) {
              echo '<div class="page-links text-center">' . $pager . '</div>';
            }


            // Retrieves Comment if configured to do so.
            if (VTCore_Zeus_Init::getFactory('features')->get('show.page.comments') || VTCore_Zeus_Init::getFactory('features')->get('show.page.comment_form')) {
              comments_template();
            }

          }
          ?>
        </div>

        <?php
        // Build sidebar left.
        if (VTCore_Zeus_Utility::getSidebar('page') == 'right'
          || VTCore_Zeus_Utility::getSidebar('page') == 'left'
        ) {
          get_sidebar('sidebar');
        }
        ?>

      </div>
    </div>
  </div>


<?php get_footer(); ?>