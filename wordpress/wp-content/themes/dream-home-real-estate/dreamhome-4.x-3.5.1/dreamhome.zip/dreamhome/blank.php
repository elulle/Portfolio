<?php
/**
 * This template will be fired when
 * user selects page mode when displaying
 * the property archive, agents profile and
 * agents listing page.
 *
 * Basically this is just a blank template with
 * sidebars controlled by Page.
 *
 * @author jason.xie@victheme.com
 */
?>
<?php get_header(); ?>

  <div id="maincontent" class="area clearfix">
    <div class="container-fluid">
      <div class="row">

        <div id="content"
             class="region
			     <?php if (VTCore_Zeus_Utility::getSidebar('page')) {
               echo VTCore_Zeus_Utility::getColumnSize('content');
             } ?>
			     with-sidebar-<?php echo VTCore_Zeus_Utility::getSidebar('page'); ?>"
          >

          <?php

          while (have_posts()) {

            // Build the single post entry using main loop
            the_post();

            // Let victheme_property handles the content;
            the_content();

          }
          ?>
        </div>

        <?php
        // Build sidebar left.
        if (VTCore_Zeus_Utility::getSidebar('page') == 'right'
          || VTCore_Zeus_Utility::getSidebar('page') == 'left'
        ) {
          get_sidebar('sidebar');
        }
        ?>

      </div>
    </div>
  </div>


<?php get_footer(); ?>