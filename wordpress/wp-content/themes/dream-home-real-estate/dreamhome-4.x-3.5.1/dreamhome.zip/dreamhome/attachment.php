<?php
/**
 * Single Page For Post Post Type Templates
 *
 * @author jason.xie@victheme.com
 */
?>
<?php get_header(); ?>

  <div id="maincontent" class="area clearfix">
    <div class="container-fluid">
      <div class="row">

        <div id="content"
             class="region
			     <?php if (VTCore_Zeus_Utility::getSidebar('full')) {
               echo VTCore_Zeus_Utility::getColumnSize('content');
             } ?>
			     with-sidebar-<?php echo VTCore_Zeus_Utility::getSidebar('full'); ?>"
          >

          <?php

          while (have_posts()) {

            // Build the single post entry using main loop
            the_post();
            $type = array_shift(explode('/', $post->post_mime_type));

            get_template_part('templates/attachment/' . $type);

            // Retrieves Pager
            $pager = VTCore_Zeus_Utility::getPostPager();
            if (!empty($pager)) {
              echo '<div class="page-links text-center">' . $pager . '</div>';
            }


            // Build Author box if configured to do so.
            if (VTCore_Zeus_Init::getFactory('features')->get('show.full.author')) {
              echo '<section class="post post-section post-author clearfix">';
              echo '<h1 class="post-section-title">';
              echo __('About The Author', 'dreamhome');
              echo '</h1>';
              get_template_part('templates/content/author');
              echo '</section>';
            }


            // Retrieves Comment if configured to do so.
            if (VTCore_Zeus_Init::getFactory('features')->get('show.full.comments') || VTCore_Zeus_Init::getFactory('features')->get('show.full.comment_form')) {
              comments_template();
            }

          }
          ?>

        </div>

        <?php
        // Build sidebar.
        if (VTCore_Zeus_Utility::getSidebar('full') == 'right'
          || VTCore_Zeus_Utility::getSidebar('full') == 'left'
        ) {
          get_sidebar('sidebar');
        }
        ?>

      </div>
    </div>
  </div>

<?php get_footer(); ?>