<?php
/**
 * Main index.php
 * @author jason.xie@victheme.com
 */
?>
<?php get_header(); ?>

  <div id="maincontent" class="area clearfix">
    <div class="container-fluid">
      <div class="row">

        <div id="content"
             class="region
			      <?php if (VTCore_Zeus_Utility::getSidebar('teaser')) {
               echo VTCore_Zeus_Utility::getColumnSize('content');
             } ?>
			      <?php echo 'with-sidebar-' . VTCore_Zeus_Utility::getSidebar('teaser'); ?>">


          <?php

          // Build the sticky posts using WpLoop object
          // @see VTCore_Wordpress_Element WpLoop
          $sticky = get_option('sticky_posts', array());

          if (!empty($sticky) && is_home()) {

            rsort($sticky);

            $arguments = array(
              'id' => 'main-sticky',
              'queryArgs' => array(
                'post__in' => $sticky,
                'ignore_sticky_posts' => FALSE,
              ),
              'attributes' => array(
                'class' => array(
                  'clearfix',
                ),
              ),
              'ajax' => FALSE,
              'grids' => VTCore_Zeus_Init::getFactory('features')->get('options.blog.grids'),
              'template' => array(
                'items' => 'blog-sticky.php',
                'empty' => FALSE,
              ),
              'data' => array(
                'isotope-options' => array(
                  'itemSelector' => '.item',
                  'layoutMode' => 'fitRows',
                  'fitRows' => array(
                    'gutter' => array(
                      'width' => 0,
                      'height' => 60,
                    ),
                  ),
                  'resizeDelay' => 300,
                ),
              ),
              'show' => TRUE,
            );

            if (isset($stickyArgs)) {
              $arguments = VTCore_Utility::arrayMergeRecursiveDistinct($stickyArgs, $arguments);
            }

            if ($arguments['show']) {
              $stickyObject = new VTCore_Wordpress_Element_WpLoop($arguments);
            }
          }


          // Build the main loop using WpLoop Object
          // @see VTCore_Wordpress_Element WpLoop
          $arguments = array(
            'id' => 'main',
            'queryMain' => TRUE,
            'ajax' => TRUE,
            'attributes' => array(
              'class' => array(
                'id' => 'zeus-main-loop',
                'clearfix' => 'clearfix',
                'template' => 'template-' . VTCore_Zeus_Init::getFactory('features')->get('options.blog.teaser')
              ),
            ),
            'template' => array(
              'items' => VTCore_Zeus_Init::getFactory('features')->get('options.blog.teaser') . '.php',
              'empty' => 'blog-empty.php',
            ),
            'data' => array(
              'isotope-options' => array(
                'itemSelector' => '.item',
                'layoutMode' => 'fitRows',
                'fitRows' => array(
                  'equalheight' => TRUE,
                  'gutter' => array(
                    'width' => 0,
                    'height' => 0,
                  ),
                ),
                'resizeDelay' => 300,
              ),
            ),
            'grids' => VTCore_Zeus_Init::getFactory('features')->get('options.blog.grids'),
            'show' => TRUE,
          );

          if (isset($contentArgs)) {
            $arguments = VTCore_Utility::arrayMergeRecursiveDistinct($contentArgs, $arguments);
          }


          // Filtering sticky post from main loop
          if (!empty($sticky) && is_home()) {

            if ($arguments['queryMain']) {
              $wp_query->set('post__not_in', $sticky);
            }
            else {
              $arguments['queryArgs']['post__not_in'] = $sticky;
            }
          }

          if ($arguments['show']) {
            $loopObject = new VTCore_Wordpress_Element_WpLoop($arguments);
          }


          // Building the pager elements using WpLoop object
          // @see VTCore_Wordpress_Element WpLoop
          $arguments = array(
            'id' => $loopObject->getContext('id'),
            'query' => $loopObject->getContext('query'),
            'ajax' => TRUE,
            'mini' => FALSE,
            'prev_text' => __('&larr; Previous', 'dreamhome'),
            'next_text' => __('Next &rarr;', 'dreamhome'),
            'attributes' => array(
              'class' => array(
                'text-center',
              ),
            ),
            'show' => TRUE,
          );

          if (isset($pagerArgs)) {
            $arguments = VTCore_Utility::arrayMergeRecursiveDistinct($contentArgs, $arguments);
          }

          if ($arguments['show']) {
            $pagerObject = new VTCore_Wordpress_Element_WpPager($arguments);
          }

          // Rendering the objects
          if (isset($stickyObject)) {
            $stickyObject->render();
          }

          if (isset($loopObject)) {
            $loopObject->render();
          }

          if (isset($pagerObject)) {
            $pagerObject->render();
          }

          ?>
        </div>


        <?php
        // Build sidebar.
        if (VTCore_Zeus_Utility::getSidebar('teaser') == 'right'
          || VTCore_Zeus_Utility::getSidebar('teaser') == 'left'
        ) {

          get_sidebar('sidebar');
        }
        ?>


      </div>
    </div>
  </div>

<?php get_footer(); ?>