<?php
/**
 * Main template for building
 * the agents archive page
 *
 * The main loop can be configured
 * via victheme_agents configuration
 * page GUI.
 *
 * @author jason.xie@victheme.com
 */

  // Build default settings to be passed to sub template
  $user = new WP_User($wp_query->query_vars['author']);
  $user->agents = new VTCore_Agents_Entity_Agents($user->ID);
  $user->get('agents')
    ->loadMetaData()
    ->initializeFields()
    ->initializeAttributes();

  $config = new VTCore_Property_Config();
  $config->add('teasers.title', FALSE);
  $config->add('teasers.description', FALSE);
  $config->add('teasers.isotope', FALSE);
  $config->add('teasers.template', 'property-grid');
  $config->add('teasers.grids.columns', array(
    'mobile' => '6',
    'tablet' => '6',
    'small' => '4',
    'large' => '4',
  ));

  $contentArgs = array(
    'queryMain' => FALSE,
    'queryArgs' => array(
      'post_type' => 'property',
      'post_status' => 'publish',
      'author' => $user->ID,
    ),
  );

  // pager arguments
  $pagerArgs = array(
    'prev_text' => __('&larr; Previous', 'dreamhome'),
    'next_text' => __('Next &rarr;', 'dreamhome'),
    'attributes' => array(
      'class' => array(
        'text-center',
      ),
    ),
  );

?>
<?php get_header(); ?>

  <div id="maincontent" class="area clearfix">
    <div class="container-fluid">
      <div class="row">

        <div id="content"
             class="region
			      <?php if (VTCore_Zeus_Utility::getSidebar('agents_profile')) {
               echo VTCore_Zeus_Utility::getColumnSize('content');
             } ?>
			      <?php echo 'with-sidebar-' . VTCore_Zeus_Utility::getSidebar('agents_profile'); ?>">


          <?php

          // Load the main profile template
          if (VTCore_Zeus_Init::getFactory('features')->get('show.agents_profile.content')
            || VTCore_Zeus_Init::getFactory('features')->get('show.agents_profile.photo')
            || VTCore_Zeus_Init::getFactory('features')->get('show.agents_profile.info')
          ) {

            include VTCore_Wordpress_Utility::locateTemplate('agents-profile.php');
          }

          ?>

        </div>


        <?php
        // Build sidebar
        if (VTCore_Zeus_Utility::getSidebar('agents_profile') == 'right'
          || VTCore_Zeus_Utility::getSidebar('agents_profile') == 'left'
        ) {
          get_sidebar('sidebar');
        }
        ?>


      </div>
    </div>
  </div>

<?php
// Load the listing template
if (VTCore_Zeus_Init::getFactory('features')->get('show.agents_profile.listing')) {
  include VTCore_Wordpress_Utility::locateTemplate('agents-listing.php');
}
?>

<?php
// Load the contact template
if (VTCore_Zeus_Init::getFactory('features')->get('show.agents_profile.contact')
  || VTCore_Zeus_Init::getFactory('features')->get('show.agents_profile.maps')
) {
  include VTCore_Wordpress_Utility::locateTemplate('agents-contact.php');
}
?>


<?php get_footer(); ?>